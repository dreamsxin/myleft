--
-- phpBB Backup Script
-- Dump of tables for phpbb_
-- DATE : 30-10-2014 09:38:19 GMT
--
BEGIN TRANSACTION;
-- Table: phpbb_icons
DROP TABLE phpbb_icons;
DROP SEQUENCE phpbb_icons_seq;
CREATE SEQUENCE phpbb_icons_seq;
CREATE TABLE phpbb_icons(
  icons_id int4 DEFAULT nextval('phpbb_icons_seq'::regclass) NOT NULL, 
  icons_url varchar(255) DEFAULT ''::character varying NOT NULL, 
  icons_width int2 DEFAULT 0::smallint NOT NULL, 
  icons_height int2 DEFAULT 0::smallint NOT NULL, 
  icons_order int4 DEFAULT 0 NOT NULL, 
  display_on_posting int2 DEFAULT 1::smallint NOT NULL, 
  CONSTRAINT phpbb_icons_pkey PRIMARY KEY (icons_id), 
  CONSTRAINT phpbb_icons_display_on_posting_check CHECK (display_on_posting >= 0), 
  CONSTRAINT phpbb_icons_icons_order_check CHECK (icons_order >= 0), 
  CONSTRAINT phpbb_icons_icons_id_check CHECK (icons_id >= 0)
);
CREATE INDEX phpbb_icons_display_on_posting ON phpbb_icons (display_on_posting);

COPY phpbb_icons (icons_id, icons_url, icons_width, icons_height, icons_order, display_on_posting) FROM stdin;
1	misc/fire.gif	16	16	1	1
2	smile/redface.gif	16	16	9	1
3	smile/mrgreen.gif	16	16	10	1
4	misc/heart.gif	16	16	4	1
5	misc/star.gif	16	16	2	1
6	misc/radioactive.gif	16	16	3	1
7	misc/thinking.gif	16	16	5	1
8	smile/info.gif	16	16	8	1
9	smile/question.gif	16	16	6	1
10	smile/alert.gif	16	16	7	1
\.
SELECT SETVAL('phpbb_icons_seq',(select case when max(icons_id)>0 then max(icons_id)+1 else 1 end FROM phpbb_icons));
-- Table: phpbb_privmsgs
DROP TABLE phpbb_privmsgs;
DROP SEQUENCE phpbb_privmsgs_seq;
CREATE SEQUENCE phpbb_privmsgs_seq;
CREATE TABLE phpbb_privmsgs(
  msg_id int4 DEFAULT nextval('phpbb_privmsgs_seq'::regclass) NOT NULL, 
  root_level int4 DEFAULT 0 NOT NULL, 
  author_id int4 DEFAULT 0 NOT NULL, 
  icon_id int4 DEFAULT 0 NOT NULL, 
  author_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  message_time int4 DEFAULT 0 NOT NULL, 
  enable_bbcode int2 DEFAULT 1::smallint NOT NULL, 
  enable_smilies int2 DEFAULT 1::smallint NOT NULL, 
  enable_magic_url int2 DEFAULT 1::smallint NOT NULL, 
  enable_sig int2 DEFAULT 1::smallint NOT NULL, 
  message_subject varchar(255) DEFAULT ''::character varying NOT NULL, 
  message_text text DEFAULT ''::text NOT NULL, 
  message_edit_reason varchar(255) DEFAULT ''::character varying NOT NULL, 
  message_edit_user int4 DEFAULT 0 NOT NULL, 
  message_attachment int2 DEFAULT 0::smallint NOT NULL, 
  bbcode_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  bbcode_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  message_edit_time int4 DEFAULT 0 NOT NULL, 
  message_edit_count int2 DEFAULT 0::smallint NOT NULL, 
  to_address varchar(4000) DEFAULT ''::character varying NOT NULL, 
  bcc_address varchar(4000) DEFAULT ''::character varying NOT NULL, 
  message_reported int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_privmsgs_pkey PRIMARY KEY (msg_id), 
  CONSTRAINT phpbb_privmsgs_message_reported_check CHECK (message_reported >= 0), 
  CONSTRAINT phpbb_privmsgs_message_edit_count_check CHECK (message_edit_count >= 0), 
  CONSTRAINT phpbb_privmsgs_message_edit_time_check CHECK (message_edit_time >= 0), 
  CONSTRAINT phpbb_privmsgs_message_attachment_check CHECK (message_attachment >= 0), 
  CONSTRAINT phpbb_privmsgs_message_edit_user_check CHECK (message_edit_user >= 0), 
  CONSTRAINT phpbb_privmsgs_enable_sig_check CHECK (enable_sig >= 0), 
  CONSTRAINT phpbb_privmsgs_enable_magic_url_check CHECK (enable_magic_url >= 0), 
  CONSTRAINT phpbb_privmsgs_enable_smilies_check CHECK (enable_smilies >= 0), 
  CONSTRAINT phpbb_privmsgs_enable_bbcode_check CHECK (enable_bbcode >= 0), 
  CONSTRAINT phpbb_privmsgs_message_time_check CHECK (message_time >= 0), 
  CONSTRAINT phpbb_privmsgs_icon_id_check CHECK (icon_id >= 0), 
  CONSTRAINT phpbb_privmsgs_author_id_check CHECK (author_id >= 0), 
  CONSTRAINT phpbb_privmsgs_root_level_check CHECK (root_level >= 0), 
  CONSTRAINT phpbb_privmsgs_msg_id_check CHECK (msg_id >= 0)
);
CREATE INDEX phpbb_privmsgs_author_id ON phpbb_privmsgs (author_id);
CREATE INDEX phpbb_privmsgs_author_ip ON phpbb_privmsgs (author_ip);
CREATE INDEX phpbb_privmsgs_message_time ON phpbb_privmsgs (message_time);
CREATE INDEX phpbb_privmsgs_root_level ON phpbb_privmsgs (root_level);

COPY phpbb_privmsgs (msg_id, root_level, author_id, icon_id, author_ip, message_time, enable_bbcode, enable_smilies, enable_magic_url, enable_sig, message_subject, message_text, message_edit_reason, message_edit_user, message_attachment, bbcode_bitfield, bbcode_uid, message_edit_time, message_edit_count, to_address, bcc_address, message_reported) FROM stdin;
\.
SELECT SETVAL('phpbb_privmsgs_seq',(select case when max(msg_id)>0 then max(msg_id)+1 else 1 end FROM phpbb_privmsgs));
-- Table: phpbb_acl_users
DROP TABLE phpbb_acl_users;
CREATE TABLE phpbb_acl_users(
  user_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  auth_option_id int4 DEFAULT 0 NOT NULL, 
  auth_role_id int4 DEFAULT 0 NOT NULL, 
  auth_setting int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_acl_users_auth_role_id_check CHECK (auth_role_id >= 0), 
  CONSTRAINT phpbb_acl_users_auth_option_id_check CHECK (auth_option_id >= 0), 
  CONSTRAINT phpbb_acl_users_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_acl_users_user_id_check CHECK (user_id >= 0)
);
CREATE INDEX phpbb_acl_users_auth_option_id ON phpbb_acl_users (auth_option_id);
CREATE INDEX phpbb_acl_users_auth_role_id ON phpbb_acl_users (auth_role_id);
CREATE INDEX phpbb_acl_users_user_id ON phpbb_acl_users (user_id);

COPY phpbb_acl_users (user_id, forum_id, auth_option_id, auth_role_id, auth_setting) FROM stdin;
2	0	0	5	0
\.
-- Table: phpbb_smilies
DROP TABLE phpbb_smilies;
DROP SEQUENCE phpbb_smilies_seq;
CREATE SEQUENCE phpbb_smilies_seq;
CREATE TABLE phpbb_smilies(
  smiley_id int4 DEFAULT nextval('phpbb_smilies_seq'::regclass) NOT NULL, 
  code varchar(50) DEFAULT ''::character varying NOT NULL, 
  emotion varchar(50) DEFAULT ''::character varying NOT NULL, 
  smiley_url varchar(50) DEFAULT ''::character varying NOT NULL, 
  smiley_width int2 DEFAULT 0::smallint NOT NULL, 
  smiley_height int2 DEFAULT 0::smallint NOT NULL, 
  smiley_order int4 DEFAULT 0 NOT NULL, 
  display_on_posting int2 DEFAULT 1::smallint NOT NULL, 
  CONSTRAINT phpbb_smilies_pkey PRIMARY KEY (smiley_id), 
  CONSTRAINT phpbb_smilies_display_on_posting_check CHECK (display_on_posting >= 0), 
  CONSTRAINT phpbb_smilies_smiley_order_check CHECK (smiley_order >= 0), 
  CONSTRAINT phpbb_smilies_smiley_height_check CHECK (smiley_height >= 0), 
  CONSTRAINT phpbb_smilies_smiley_width_check CHECK (smiley_width >= 0), 
  CONSTRAINT phpbb_smilies_smiley_id_check CHECK (smiley_id >= 0)
);
CREATE INDEX phpbb_smilies_display_on_post ON phpbb_smilies (display_on_posting);

COPY phpbb_smilies (smiley_id, code, emotion, smiley_url, smiley_width, smiley_height, smiley_order, display_on_posting) FROM stdin;
1	:D	Very Happy	icon_e_biggrin.gif	15	17	1	1
2	:-D	Very Happy	icon_e_biggrin.gif	15	17	2	1
3	:grin:	Very Happy	icon_e_biggrin.gif	15	17	3	1
4	:)	Smile	icon_e_smile.gif	15	17	4	1
5	:-)	Smile	icon_e_smile.gif	15	17	5	1
6	:smile:	Smile	icon_e_smile.gif	15	17	6	1
7	;)	Wink	icon_e_wink.gif	15	17	7	1
8	;-)	Wink	icon_e_wink.gif	15	17	8	1
9	:wink:	Wink	icon_e_wink.gif	15	17	9	1
10	:(	Sad	icon_e_sad.gif	15	17	10	1
11	:-(	Sad	icon_e_sad.gif	15	17	11	1
12	:sad:	Sad	icon_e_sad.gif	15	17	12	1
13	:o	Surprised	icon_e_surprised.gif	15	17	13	1
14	:-o	Surprised	icon_e_surprised.gif	15	17	14	1
15	:eek:	Surprised	icon_e_surprised.gif	15	17	15	1
16	:shock:	Shocked	icon_eek.gif	15	17	16	1
17	:?	Confused	icon_e_confused.gif	15	17	17	1
18	:-?	Confused	icon_e_confused.gif	15	17	18	1
19	:???:	Confused	icon_e_confused.gif	15	17	19	1
20	8-)	Cool	icon_cool.gif	15	17	20	1
21	:cool:	Cool	icon_cool.gif	15	17	21	1
22	:lol:	Laughing	icon_lol.gif	15	17	22	1
23	:x	Mad	icon_mad.gif	15	17	23	1
24	:-x	Mad	icon_mad.gif	15	17	24	1
25	:mad:	Mad	icon_mad.gif	15	17	25	1
26	:P	Razz	icon_razz.gif	15	17	26	1
27	:-P	Razz	icon_razz.gif	15	17	27	1
28	:razz:	Razz	icon_razz.gif	15	17	28	1
29	:oops:	Embarrassed	icon_redface.gif	15	17	29	1
30	:cry:	Crying or Very Sad	icon_cry.gif	15	17	30	1
31	:evil:	Evil or Very Mad	icon_evil.gif	15	17	31	1
32	:twisted:	Twisted Evil	icon_twisted.gif	15	17	32	1
33	:roll:	Rolling Eyes	icon_rolleyes.gif	15	17	33	1
34	:!:	Exclamation	icon_exclaim.gif	15	17	34	1
35	:?:	Question	icon_question.gif	15	17	35	1
36	:idea:	Idea	icon_idea.gif	15	17	36	1
37	:arrow:	Arrow	icon_arrow.gif	15	17	37	1
38	:|	Neutral	icon_neutral.gif	15	17	38	1
39	:-|	Neutral	icon_neutral.gif	15	17	39	1
40	:mrgreen:	Mr. Green	icon_mrgreen.gif	15	17	40	1
41	:geek:	Geek	icon_e_geek.gif	17	17	41	1
42	:ugeek:	Uber Geek	icon_e_ugeek.gif	17	18	42	1
\.
SELECT SETVAL('phpbb_smilies_seq',(select case when max(smiley_id)>0 then max(smiley_id)+1 else 1 end FROM phpbb_smilies));
-- Table: phpbb_search_results
DROP TABLE phpbb_search_results;
CREATE TABLE phpbb_search_results(
  search_key varchar(32) DEFAULT ''::character varying NOT NULL, 
  search_time int4 DEFAULT 0 NOT NULL, 
  search_keywords text DEFAULT ''::text NOT NULL, 
  search_authors text DEFAULT ''::text NOT NULL, 
  CONSTRAINT phpbb_search_results_pkey PRIMARY KEY (search_key), 
  CONSTRAINT phpbb_search_results_search_time_check CHECK (search_time >= 0)
);
COPY phpbb_search_results (search_key, search_time, search_keywords, search_authors) FROM stdin;
\.
-- Table: phpbb_acl_roles_data
DROP TABLE phpbb_acl_roles_data;
CREATE TABLE phpbb_acl_roles_data(
  role_id int4 DEFAULT 0 NOT NULL, 
  auth_option_id int4 DEFAULT 0 NOT NULL, 
  auth_setting int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_acl_roles_data_pkey PRIMARY KEY (auth_option_id, role_id), 
  CONSTRAINT phpbb_acl_roles_data_auth_option_id_check CHECK (auth_option_id >= 0), 
  CONSTRAINT phpbb_acl_roles_data_role_id_check CHECK (role_id >= 0)
);
CREATE INDEX phpbb_acl_roles_data_ath_op_id ON phpbb_acl_roles_data (auth_option_id);

COPY phpbb_acl_roles_data (role_id, auth_option_id, auth_setting) FROM stdin;
1	46	1
1	48	1
1	49	1
1	50	1
1	52	1
1	53	1
1	54	1
1	58	1
1	59	1
1	60	1
1	61	1
1	62	1
1	63	1
1	64	1
1	65	1
1	66	1
1	69	1
1	71	1
1	73	1
1	74	1
1	75	1
1	76	1
1	82	1
1	83	1
1	84	1
1	85	1
1	86	1
1	87	1
2	46	1
2	49	1
2	50	1
2	59	1
2	60	1
2	61	1
2	62	1
2	69	1
2	74	1
2	82	1
2	85	1
2	86	1
3	46	1
3	49	1
3	50	1
3	52	1
3	63	1
3	64	1
3	65	1
3	75	1
3	82	1
3	83	1
3	85	1
3	86	1
4	46	1
4	47	1
4	48	1
4	49	1
4	50	1
4	51	1
4	52	1
4	53	1
4	54	1
4	55	1
4	56	1
4	57	1
4	58	1
4	59	1
4	60	1
4	61	1
4	62	1
4	63	1
4	64	1
4	65	1
4	66	1
4	67	1
4	68	1
4	69	1
4	70	1
4	71	1
4	72	1
4	73	1
4	74	1
4	75	1
4	76	1
4	77	1
4	78	1
4	79	1
4	80	1
4	81	1
4	82	1
4	83	1
4	84	1
4	85	1
4	86	1
4	87	1
5	88	1
5	89	1
5	90	1
5	91	1
5	92	1
5	93	1
5	94	1
5	95	1
5	96	1
5	97	1
5	98	1
5	99	1
5	100	1
5	101	1
5	102	1
5	103	1
5	104	1
5	105	1
5	106	1
5	107	1
5	108	1
5	109	1
5	110	1
5	111	1
5	112	1
5	113	1
5	114	1
5	115	1
5	116	1
5	117	1
5	118	1
5	119	1
5	120	1
5	121	1
6	88	1
6	89	1
6	90	1
6	91	1
6	92	1
6	95	1
6	96	1
6	97	1
6	98	1
6	100	1
6	101	1
6	102	1
6	103	1
6	104	1
6	105	1
6	106	1
6	107	1
6	110	1
6	111	1
6	112	1
6	113	1
6	114	1
6	115	1
6	116	1
6	117	1
6	118	1
6	119	1
6	121	1
7	88	1
7	90	1
7	91	1
7	92	1
7	95	1
7	96	1
7	97	1
7	98	1
7	103	1
7	104	1
7	105	1
7	106	1
7	109	1
7	110	1
7	111	1
7	112	1
7	113	1
7	118	1
7	119	1
7	121	1
8	88	1
8	90	1
8	91	1
8	92	1
8	95	1
8	97	1
8	98	1
8	119	1
8	121	1
8	100	0
8	101	0
8	113	0
8	118	0
9	88	1
9	91	1
9	92	1
9	95	1
9	96	1
9	97	1
9	98	1
9	103	1
9	104	1
9	105	1
9	106	1
9	109	1
9	110	1
9	111	1
9	112	1
9	113	1
9	118	1
9	119	1
9	121	1
9	90	0
10	32	1
10	33	1
10	34	1
10	35	1
10	36	1
10	37	1
10	38	1
10	39	1
10	40	1
10	41	1
10	42	1
10	43	1
10	44	1
10	45	1
11	32	1
11	33	1
11	35	1
11	36	1
11	37	1
11	38	1
11	39	1
11	40	1
11	41	1
11	42	1
11	43	1
11	45	1
12	32	1
12	35	1
12	36	1
12	37	1
12	41	1
12	43	1
13	32	1
13	33	1
13	36	1
14	1	1
14	2	1
14	3	1
14	4	1
14	5	1
14	6	1
14	7	1
14	8	1
14	9	1
14	10	1
14	11	1
14	12	1
14	13	1
14	14	1
14	15	1
14	16	1
14	17	1
14	18	1
14	19	1
14	20	1
14	21	1
14	22	1
14	23	1
14	24	1
14	25	1
14	26	1
14	27	1
14	28	1
14	29	1
14	30	1
14	31	1
15	1	1
15	3	1
15	4	1
15	5	1
15	6	1
15	7	1
15	8	1
15	9	1
15	11	1
15	13	1
15	14	1
15	15	1
15	17	1
15	18	1
15	19	1
15	20	1
15	21	1
15	22	1
15	23	1
15	24	1
15	25	1
15	27	1
15	29	1
15	30	1
15	31	1
16	1	0
17	1	1
17	7	1
17	14	1
17	19	1
17	20	1
17	23	1
17	27	1
18	1	1
18	4	1
18	7	1
18	8	1
18	9	1
18	13	1
18	14	1
18	15	1
18	17	1
18	18	1
18	19	1
18	20	1
18	21	1
18	22	1
18	23	1
18	24	1
18	25	1
18	27	1
18	29	1
18	31	1
19	1	1
19	7	1
19	14	1
19	19	1
19	20	1
20	1	1
20	3	1
20	4	1
20	7	1
20	8	1
20	9	1
20	13	1
20	14	1
20	17	1
20	18	1
20	19	1
20	20	1
20	21	1
20	22	1
20	23	1
20	24	1
20	25	1
20	27	1
20	29	1
20	31	1
20	15	0
21	1	1
21	3	1
21	4	1
21	5	1
21	6	1
21	7	1
21	8	1
21	9	1
21	11	1
21	13	1
21	14	1
21	15	1
21	16	1
21	17	1
21	18	1
21	19	1
21	20	1
21	21	1
21	22	1
21	23	1
21	24	1
21	25	1
21	27	1
21	29	1
21	30	1
21	31	1
22	1	1
22	4	1
22	7	1
22	8	1
22	9	1
22	13	1
22	14	1
22	15	1
22	16	1
22	17	1
22	18	1
22	19	1
22	20	1
22	21	1
22	22	1
22	23	1
22	24	1
22	25	1
22	27	1
22	29	1
22	31	1
23	96	0
23	100	0
23	101	0
23	118	0
24	15	0
\.
-- Table: phpbb_topics_posted
DROP TABLE phpbb_topics_posted;
CREATE TABLE phpbb_topics_posted(
  user_id int4 DEFAULT 0 NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  topic_posted int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_topics_posted_pkey PRIMARY KEY (topic_id, user_id), 
  CONSTRAINT phpbb_topics_posted_topic_posted_check CHECK (topic_posted >= 0), 
  CONSTRAINT phpbb_topics_posted_topic_id_check CHECK (topic_id >= 0), 
  CONSTRAINT phpbb_topics_posted_user_id_check CHECK (user_id >= 0)
);
COPY phpbb_topics_posted (user_id, topic_id, topic_posted) FROM stdin;
2	1	1
\.
-- Table: phpbb_sessions_keys
DROP TABLE phpbb_sessions_keys;
CREATE TABLE phpbb_sessions_keys(
  key_id char(32) DEFAULT ''::bpchar NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  last_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  last_login int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_sessions_keys_pkey PRIMARY KEY (key_id, user_id), 
  CONSTRAINT phpbb_sessions_keys_last_login_check CHECK (last_login >= 0), 
  CONSTRAINT phpbb_sessions_keys_user_id_check CHECK (user_id >= 0)
);
CREATE INDEX phpbb_sessions_keys_last_login ON phpbb_sessions_keys (last_login);

COPY phpbb_sessions_keys (key_id, user_id, last_ip, last_login) FROM stdin;
\.
-- Table: phpbb_zebra
DROP TABLE phpbb_zebra;
CREATE TABLE phpbb_zebra(
  user_id int4 DEFAULT 0 NOT NULL, 
  zebra_id int4 DEFAULT 0 NOT NULL, 
  friend int2 DEFAULT 0::smallint NOT NULL, 
  foe int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_zebra_pkey PRIMARY KEY (user_id, zebra_id), 
  CONSTRAINT phpbb_zebra_foe_check CHECK (foe >= 0), 
  CONSTRAINT phpbb_zebra_friend_check CHECK (friend >= 0), 
  CONSTRAINT phpbb_zebra_zebra_id_check CHECK (zebra_id >= 0), 
  CONSTRAINT phpbb_zebra_user_id_check CHECK (user_id >= 0)
);
COPY phpbb_zebra (user_id, zebra_id, friend, foe) FROM stdin;
\.
-- Table: phpbb_oauth_tokens
DROP TABLE phpbb_oauth_tokens;
CREATE TABLE phpbb_oauth_tokens(
  user_id int4 DEFAULT 0 NOT NULL, 
  session_id char(32) DEFAULT ''::bpchar NOT NULL, 
  provider varchar(255) DEFAULT ''::character varying NOT NULL, 
  oauth_token text DEFAULT ''::text NOT NULL, 
  CONSTRAINT phpbb_oauth_tokens_user_id_check CHECK (user_id >= 0)
);
CREATE INDEX phpbb_oauth_tokens_provider ON phpbb_oauth_tokens (provider);
CREATE INDEX phpbb_oauth_tokens_user_id ON phpbb_oauth_tokens (user_id);

COPY phpbb_oauth_tokens (user_id, session_id, provider, oauth_token) FROM stdin;
\.
-- Table: phpbb_attachments
DROP TABLE phpbb_attachments;
DROP SEQUENCE phpbb_attachments_seq;
CREATE SEQUENCE phpbb_attachments_seq;
CREATE TABLE phpbb_attachments(
  attach_id int4 DEFAULT nextval('phpbb_attachments_seq'::regclass) NOT NULL, 
  post_msg_id int4 DEFAULT 0 NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  in_message int2 DEFAULT 0::smallint NOT NULL, 
  poster_id int4 DEFAULT 0 NOT NULL, 
  is_orphan int2 DEFAULT 1::smallint NOT NULL, 
  physical_filename varchar(255) DEFAULT ''::character varying NOT NULL, 
  real_filename varchar(255) DEFAULT ''::character varying NOT NULL, 
  download_count int4 DEFAULT 0 NOT NULL, 
  attach_comment varchar(4000) DEFAULT ''::character varying NOT NULL, 
  extension varchar(100) DEFAULT ''::character varying NOT NULL, 
  mimetype varchar(100) DEFAULT ''::character varying NOT NULL, 
  filesize int4 DEFAULT 0 NOT NULL, 
  filetime int4 DEFAULT 0 NOT NULL, 
  thumbnail int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_attachments_pkey PRIMARY KEY (attach_id), 
  CONSTRAINT phpbb_attachments_thumbnail_check CHECK (thumbnail >= 0), 
  CONSTRAINT phpbb_attachments_filetime_check CHECK (filetime >= 0), 
  CONSTRAINT phpbb_attachments_filesize_check CHECK (filesize >= 0), 
  CONSTRAINT phpbb_attachments_download_count_check CHECK (download_count >= 0), 
  CONSTRAINT phpbb_attachments_is_orphan_check CHECK (is_orphan >= 0), 
  CONSTRAINT phpbb_attachments_poster_id_check CHECK (poster_id >= 0), 
  CONSTRAINT phpbb_attachments_in_message_check CHECK (in_message >= 0), 
  CONSTRAINT phpbb_attachments_topic_id_check CHECK (topic_id >= 0), 
  CONSTRAINT phpbb_attachments_post_msg_id_check CHECK (post_msg_id >= 0), 
  CONSTRAINT phpbb_attachments_attach_id_check CHECK (attach_id >= 0)
);
CREATE INDEX phpbb_attachments_filetime ON phpbb_attachments (filetime);
CREATE INDEX phpbb_attachments_is_orphan ON phpbb_attachments (is_orphan);
CREATE INDEX phpbb_attachments_post_msg_id ON phpbb_attachments (post_msg_id);
CREATE INDEX phpbb_attachments_poster_id ON phpbb_attachments (poster_id);
CREATE INDEX phpbb_attachments_topic_id ON phpbb_attachments (topic_id);

COPY phpbb_attachments (attach_id, post_msg_id, topic_id, in_message, poster_id, is_orphan, physical_filename, real_filename, download_count, attach_comment, extension, mimetype, filesize, filetime, thumbnail) FROM stdin;
\.
SELECT SETVAL('phpbb_attachments_seq',(select case when max(attach_id)>0 then max(attach_id)+1 else 1 end FROM phpbb_attachments));
-- Table: phpbb_lang
DROP TABLE phpbb_lang;
DROP SEQUENCE phpbb_lang_seq;
CREATE SEQUENCE phpbb_lang_seq;
CREATE TABLE phpbb_lang(
  lang_id int2 DEFAULT nextval('phpbb_lang_seq'::regclass) NOT NULL, 
  lang_iso varchar(30) DEFAULT ''::character varying NOT NULL, 
  lang_dir varchar(30) DEFAULT ''::character varying NOT NULL, 
  lang_english_name varchar(100) DEFAULT ''::character varying NOT NULL, 
  lang_local_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  lang_author varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_lang_pkey PRIMARY KEY (lang_id)
);
CREATE INDEX phpbb_lang_lang_iso ON phpbb_lang (lang_iso);

COPY phpbb_lang (lang_id, lang_iso, lang_dir, lang_english_name, lang_local_name, lang_author) FROM stdin;
1	en	en	British English	British English	phpBB Limited
\.
SELECT SETVAL('phpbb_lang_seq',(select case when max(lang_id)>0 then max(lang_id)+1 else 1 end FROM phpbb_lang));
-- Table: phpbb_disallow
DROP TABLE phpbb_disallow;
DROP SEQUENCE phpbb_disallow_seq;
CREATE SEQUENCE phpbb_disallow_seq;
CREATE TABLE phpbb_disallow(
  disallow_id int4 DEFAULT nextval('phpbb_disallow_seq'::regclass) NOT NULL, 
  disallow_username varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_disallow_pkey PRIMARY KEY (disallow_id), 
  CONSTRAINT phpbb_disallow_disallow_id_check CHECK (disallow_id >= 0)
);
COPY phpbb_disallow (disallow_id, disallow_username) FROM stdin;
\.
SELECT SETVAL('phpbb_disallow_seq',(select case when max(disallow_id)>0 then max(disallow_id)+1 else 1 end FROM phpbb_disallow));
CREATE DOMAIN varchar_ci as character varying(255) NOT NULL DEFAULT ''::character varying;
-- Table: phpbb_login_attempts
DROP TABLE phpbb_login_attempts;
CREATE TABLE phpbb_login_attempts(
  attempt_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  attempt_browser varchar(150) DEFAULT ''::character varying NOT NULL, 
  attempt_forwarded_for varchar(255) DEFAULT ''::character varying NOT NULL, 
  attempt_time int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  username varchar(255) DEFAULT '0'::character varying NOT NULL, 
  username_clean varchar_ci DEFAULT '0'::character varying NOT NULL, 
  CONSTRAINT phpbb_login_attempts_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_login_attempts_attempt_time_check CHECK (attempt_time >= 0)
);
CREATE INDEX phpbb_login_attempts_att_for ON phpbb_login_attempts (attempt_forwarded_for, attempt_time);
CREATE INDEX phpbb_login_attempts_att_ip ON phpbb_login_attempts (attempt_ip, attempt_time);
CREATE INDEX phpbb_login_attempts_att_time ON phpbb_login_attempts (attempt_time);
CREATE INDEX phpbb_login_attempts_user_id ON phpbb_login_attempts (user_id);

COPY phpbb_login_attempts (attempt_ip, attempt_browser, attempt_forwarded_for, attempt_time, user_id, username, username_clean) FROM stdin;
\.
-- Table: phpbb_notifications
DROP TABLE phpbb_notifications;
DROP SEQUENCE phpbb_notifications_seq;
CREATE SEQUENCE phpbb_notifications_seq;
CREATE TABLE phpbb_notifications(
  notification_id int4 DEFAULT nextval('phpbb_notifications_seq'::regclass) NOT NULL, 
  notification_type_id int2 DEFAULT 0::smallint NOT NULL, 
  item_id int4 DEFAULT 0 NOT NULL, 
  item_parent_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  notification_read int2 DEFAULT 0::smallint NOT NULL, 
  notification_time int4 DEFAULT 1 NOT NULL, 
  notification_data varchar(4000) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_notifications_pkey PRIMARY KEY (notification_id), 
  CONSTRAINT phpbb_notifications_notification_time_check CHECK (notification_time >= 0), 
  CONSTRAINT phpbb_notifications_notification_read_check CHECK (notification_read >= 0), 
  CONSTRAINT phpbb_notifications_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_notifications_item_parent_id_check CHECK (item_parent_id >= 0), 
  CONSTRAINT phpbb_notifications_item_id_check CHECK (item_id >= 0), 
  CONSTRAINT phpbb_notifications_notification_type_id_check CHECK (notification_type_id >= 0), 
  CONSTRAINT phpbb_notifications_notification_id_check CHECK (notification_id >= 0)
);
CREATE INDEX phpbb_notifications_item_ident ON phpbb_notifications (item_id, notification_type_id);
CREATE INDEX phpbb_notifications_user ON phpbb_notifications (notification_read, user_id);

COPY phpbb_notifications (notification_id, notification_type_id, item_id, item_parent_id, user_id, notification_read, notification_time, notification_data) FROM stdin;
\.
SELECT SETVAL('phpbb_notifications_seq',(select case when max(notification_id)>0 then max(notification_id)+1 else 1 end FROM phpbb_notifications));
-- Table: phpbb_acl_roles
DROP TABLE phpbb_acl_roles;
DROP SEQUENCE phpbb_acl_roles_seq;
CREATE SEQUENCE phpbb_acl_roles_seq;
CREATE TABLE phpbb_acl_roles(
  role_id int4 DEFAULT nextval('phpbb_acl_roles_seq'::regclass) NOT NULL, 
  role_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  role_description varchar(4000) DEFAULT ''::character varying NOT NULL, 
  role_type varchar(10) DEFAULT ''::character varying NOT NULL, 
  role_order int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_acl_roles_pkey PRIMARY KEY (role_id), 
  CONSTRAINT phpbb_acl_roles_role_order_check CHECK (role_order >= 0), 
  CONSTRAINT phpbb_acl_roles_role_id_check CHECK (role_id >= 0)
);
CREATE INDEX phpbb_acl_roles_role_order ON phpbb_acl_roles (role_order);
CREATE INDEX phpbb_acl_roles_role_type ON phpbb_acl_roles (role_type);

COPY phpbb_acl_roles (role_id, role_name, role_description, role_type, role_order) FROM stdin;
1	ROLE_ADMIN_STANDARD	ROLE_DESCRIPTION_ADMIN_STANDARD	a_	1
2	ROLE_ADMIN_FORUM	ROLE_DESCRIPTION_ADMIN_FORUM	a_	3
3	ROLE_ADMIN_USERGROUP	ROLE_DESCRIPTION_ADMIN_USERGROUP	a_	4
4	ROLE_ADMIN_FULL	ROLE_DESCRIPTION_ADMIN_FULL	a_	2
5	ROLE_USER_FULL	ROLE_DESCRIPTION_USER_FULL	u_	3
6	ROLE_USER_STANDARD	ROLE_DESCRIPTION_USER_STANDARD	u_	1
7	ROLE_USER_LIMITED	ROLE_DESCRIPTION_USER_LIMITED	u_	2
8	ROLE_USER_NOPM	ROLE_DESCRIPTION_USER_NOPM	u_	4
9	ROLE_USER_NOAVATAR	ROLE_DESCRIPTION_USER_NOAVATAR	u_	5
10	ROLE_MOD_FULL	ROLE_DESCRIPTION_MOD_FULL	m_	3
11	ROLE_MOD_STANDARD	ROLE_DESCRIPTION_MOD_STANDARD	m_	1
12	ROLE_MOD_SIMPLE	ROLE_DESCRIPTION_MOD_SIMPLE	m_	2
13	ROLE_MOD_QUEUE	ROLE_DESCRIPTION_MOD_QUEUE	m_	4
14	ROLE_FORUM_FULL	ROLE_DESCRIPTION_FORUM_FULL	f_	7
15	ROLE_FORUM_STANDARD	ROLE_DESCRIPTION_FORUM_STANDARD	f_	5
16	ROLE_FORUM_NOACCESS	ROLE_DESCRIPTION_FORUM_NOACCESS	f_	1
17	ROLE_FORUM_READONLY	ROLE_DESCRIPTION_FORUM_READONLY	f_	2
18	ROLE_FORUM_LIMITED	ROLE_DESCRIPTION_FORUM_LIMITED	f_	3
19	ROLE_FORUM_BOT	ROLE_DESCRIPTION_FORUM_BOT	f_	9
20	ROLE_FORUM_ONQUEUE	ROLE_DESCRIPTION_FORUM_ONQUEUE	f_	8
21	ROLE_FORUM_POLLS	ROLE_DESCRIPTION_FORUM_POLLS	f_	6
22	ROLE_FORUM_LIMITED_POLLS	ROLE_DESCRIPTION_FORUM_LIMITED_POLLS	f_	4
23	ROLE_USER_NEW_MEMBER	ROLE_DESCRIPTION_USER_NEW_MEMBER	u_	6
24	ROLE_FORUM_NEW_MEMBER	ROLE_DESCRIPTION_FORUM_NEW_MEMBER	f_	10
\.
SELECT SETVAL('phpbb_acl_roles_seq',(select case when max(role_id)>0 then max(role_id)+1 else 1 end FROM phpbb_acl_roles));
-- Table: phpbb_profile_fields
DROP TABLE phpbb_profile_fields;
DROP SEQUENCE phpbb_profile_fields_seq;
CREATE SEQUENCE phpbb_profile_fields_seq;
CREATE TABLE phpbb_profile_fields(
  field_id int4 DEFAULT nextval('phpbb_profile_fields_seq'::regclass) NOT NULL, 
  field_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  field_type varchar(100) DEFAULT ''::character varying NOT NULL, 
  field_ident varchar(20) DEFAULT ''::character varying NOT NULL, 
  field_length varchar(20) DEFAULT ''::character varying NOT NULL, 
  field_minlen varchar(255) DEFAULT ''::character varying NOT NULL, 
  field_maxlen varchar(255) DEFAULT ''::character varying NOT NULL, 
  field_novalue varchar(255) DEFAULT ''::character varying NOT NULL, 
  field_default_value varchar(255) DEFAULT ''::character varying NOT NULL, 
  field_validation varchar(64) DEFAULT ''::character varying NOT NULL, 
  field_required int2 DEFAULT 0::smallint NOT NULL, 
  field_show_on_reg int2 DEFAULT 0::smallint NOT NULL, 
  field_hide int2 DEFAULT 0::smallint NOT NULL, 
  field_no_view int2 DEFAULT 0::smallint NOT NULL, 
  field_active int2 DEFAULT 0::smallint NOT NULL, 
  field_order int4 DEFAULT 0 NOT NULL, 
  field_show_profile int2 DEFAULT 0::smallint NOT NULL, 
  field_show_on_vt int2 DEFAULT 0::smallint NOT NULL, 
  field_show_novalue int2 DEFAULT 0::smallint NOT NULL, 
  field_show_on_pm int2 DEFAULT 0::smallint NOT NULL, 
  field_show_on_ml int2 DEFAULT 0::smallint NOT NULL, 
  field_is_contact int2 DEFAULT 0::smallint NOT NULL, 
  field_contact_desc varchar(255) DEFAULT ''::character varying NOT NULL, 
  field_contact_url varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_profile_fields_pkey PRIMARY KEY (field_id), 
  CONSTRAINT phpbb_profile_fields_field_is_contact_check CHECK (field_is_contact >= 0), 
  CONSTRAINT phpbb_profile_fields_field_show_on_ml_check CHECK (field_show_on_ml >= 0), 
  CONSTRAINT phpbb_profile_fields_field_show_on_pm_check CHECK (field_show_on_pm >= 0), 
  CONSTRAINT phpbb_profile_fields_field_show_novalue_check CHECK (field_show_novalue >= 0), 
  CONSTRAINT phpbb_profile_fields_field_show_on_vt_check CHECK (field_show_on_vt >= 0), 
  CONSTRAINT phpbb_profile_fields_field_show_profile_check CHECK (field_show_profile >= 0), 
  CONSTRAINT phpbb_profile_fields_field_order_check CHECK (field_order >= 0), 
  CONSTRAINT phpbb_profile_fields_field_active_check CHECK (field_active >= 0), 
  CONSTRAINT phpbb_profile_fields_field_no_view_check CHECK (field_no_view >= 0), 
  CONSTRAINT phpbb_profile_fields_field_hide_check CHECK (field_hide >= 0), 
  CONSTRAINT phpbb_profile_fields_field_show_on_reg_check CHECK (field_show_on_reg >= 0), 
  CONSTRAINT phpbb_profile_fields_field_required_check CHECK (field_required >= 0), 
  CONSTRAINT phpbb_profile_fields_field_id_check CHECK (field_id >= 0)
);
CREATE INDEX phpbb_profile_fields_fld_ordr ON phpbb_profile_fields (field_order);
CREATE INDEX phpbb_profile_fields_fld_type ON phpbb_profile_fields (field_type);

COPY phpbb_profile_fields (field_id, field_name, field_type, field_ident, field_length, field_minlen, field_maxlen, field_novalue, field_default_value, field_validation, field_required, field_show_on_reg, field_hide, field_no_view, field_active, field_order, field_show_profile, field_show_on_vt, field_show_novalue, field_show_on_pm, field_show_on_ml, field_is_contact, field_contact_desc, field_contact_url) FROM stdin;
1	phpbb_location	profilefields.type.string	phpbb_location	20	2	100			.*	0	0	0	0	1	1	1	1	0	1	1	0		
2	phpbb_website	profilefields.type.url	phpbb_website	40	12	255				0	0	0	0	1	2	1	1	0	1	1	1	VISIT_WEBSITE	%s
3	phpbb_interests	profilefields.type.text	phpbb_interests	3|30	2	500			.*	0	0	0	0	0	3	1	0	0	0	0	0		
4	phpbb_occupation	profilefields.type.text	phpbb_occupation	3|30	2	500			.*	0	0	0	0	0	4	1	0	0	0	0	0		
5	phpbb_aol	profilefields.type.string	phpbb_aol	40	5	255			.*	0	0	0	0	0	5	1	1	0	1	1	1		
6	phpbb_icq	profilefields.type.string	phpbb_icq	20	3	15			[0-9]+	0	0	0	0	0	6	1	1	0	1	1	1	SEND_ICQ_MESSAGE	https://www.icq.com/people/%s/
7	phpbb_wlm	profilefields.type.string	phpbb_wlm	40	5	255			.*	0	0	0	0	0	7	1	1	0	1	1	1		
8	phpbb_yahoo	profilefields.type.string	phpbb_yahoo	40	5	255			.*	0	0	0	0	0	8	1	1	0	1	1	1	SEND_YIM_MESSAGE	http://edit.yahoo.com/config/send_webmesg?.target=%s&amp;.src=pg
9	phpbb_facebook	profilefields.type.string	phpbb_facebook	20	5	50			[w.]+	0	0	0	0	1	9	1	1	0	1	1	1	VIEW_FACEBOOK_PROFILE	http://facebook.com/%s/
10	phpbb_twitter	profilefields.type.string	phpbb_twitter	20	1	15			[w_]+	0	0	0	0	1	10	1	1	0	1	1	1	VIEW_TWITTER_PROFILE	http://twitter.com/%s
11	phpbb_skype	profilefields.type.string	phpbb_skype	20	6	32			[a-zA-Z][w.,-_]+	0	0	0	0	1	11	1	1	0	1	1	1	VIEW_SKYPE_PROFILE	skype:%s?userinfo
12	phpbb_youtube	profilefields.type.string	phpbb_youtube	20	3	60			[a-zA-Z][w.,-_]+	0	0	0	0	1	12	1	1	0	1	1	1	VIEW_YOUTUBE_CHANNEL	http://youtube.com/user/%s
13	phpbb_googleplus	profilefields.type.googleplus	phpbb_googleplus	20	3	255			[w]+	0	0	0	0	1	13	1	1	0	1	1	1	VIEW_GOOGLEPLUS_PROFILE	http://plus.google.com/%s
\.
SELECT SETVAL('phpbb_profile_fields_seq',(select case when max(field_id)>0 then max(field_id)+1 else 1 end FROM phpbb_profile_fields));
-- Table: phpbb_search_wordlist
DROP TABLE phpbb_search_wordlist;
DROP SEQUENCE phpbb_search_wordlist_seq;
CREATE SEQUENCE phpbb_search_wordlist_seq;
CREATE TABLE phpbb_search_wordlist(
  word_id int4 DEFAULT nextval('phpbb_search_wordlist_seq'::regclass) NOT NULL, 
  word_text varchar(255) DEFAULT ''::character varying NOT NULL, 
  word_common int2 DEFAULT 0::smallint NOT NULL, 
  word_count int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_search_wordlist_pkey PRIMARY KEY (word_id), 
  CONSTRAINT phpbb_search_wordlist_word_count_check CHECK (word_count >= 0), 
  CONSTRAINT phpbb_search_wordlist_word_common_check CHECK (word_common >= 0), 
  CONSTRAINT phpbb_search_wordlist_word_id_check CHECK (word_id >= 0)
);
CREATE INDEX phpbb_search_wordlist_wrd_cnt ON phpbb_search_wordlist (word_count);
CREATE UNIQUE INDEX phpbb_search_wordlist_wrd_txt ON phpbb_search_wordlist (word_text);

COPY phpbb_search_wordlist (word_id, word_text, word_common, word_count) FROM stdin;
1	this	0	1
2	example	0	1
3	post	0	1
4	your	0	1
6	installation	0	1
7	everything	0	1
8	seems	0	1
9	working	0	1
10	you	0	1
11	may	0	1
12	delete	0	1
13	like	0	1
14	and	0	1
15	continue	0	1
16	set	0	1
17	board	0	1
18	during	0	1
19	the	0	1
20	process	0	1
21	first	0	1
22	category	0	1
23	forum	0	1
24	are	0	1
25	assigned	0	1
26	appropriate	0	1
27	permissions	0	1
28	for	0	1
29	predefined	0	1
30	usergroups	0	1
31	administrators	0	1
32	bots	0	1
33	global	0	1
34	moderators	0	1
35	guests	0	1
36	registered	0	1
37	users	0	1
38	coppa	0	1
39	also	0	1
40	choose	0	1
41	not	0	1
42	forget	0	1
43	assign	0	1
44	all	0	1
45	these	0	1
46	new	0	1
47	categories	0	1
48	forums	0	1
49	create	0	1
50	recommended	0	1
51	rename	0	1
52	copy	0	1
53	from	0	1
54	while	0	1
55	creating	0	1
56	have	0	1
57	fun	0	1
58	welcome	0	1
5	phpbb3	0	2
\.
SELECT SETVAL('phpbb_search_wordlist_seq',(select case when max(word_id)>0 then max(word_id)+1 else 1 end FROM phpbb_search_wordlist));
-- Table: phpbb_sessions
DROP TABLE phpbb_sessions;
CREATE TABLE phpbb_sessions(
  session_id char(32) DEFAULT ''::bpchar NOT NULL, 
  session_user_id int4 DEFAULT 0 NOT NULL, 
  session_last_visit int4 DEFAULT 0 NOT NULL, 
  session_start int4 DEFAULT 0 NOT NULL, 
  session_time int4 DEFAULT 0 NOT NULL, 
  session_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  session_browser varchar(150) DEFAULT ''::character varying NOT NULL, 
  session_forwarded_for varchar(255) DEFAULT ''::character varying NOT NULL, 
  session_page varchar(255) DEFAULT ''::character varying NOT NULL, 
  session_viewonline int2 DEFAULT 1::smallint NOT NULL, 
  session_autologin int2 DEFAULT 0::smallint NOT NULL, 
  session_admin int2 DEFAULT 0::smallint NOT NULL, 
  session_forum_id int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_sessions_pkey PRIMARY KEY (session_id), 
  CONSTRAINT phpbb_sessions_session_forum_id_check CHECK (session_forum_id >= 0), 
  CONSTRAINT phpbb_sessions_session_admin_check CHECK (session_admin >= 0), 
  CONSTRAINT phpbb_sessions_session_autologin_check CHECK (session_autologin >= 0), 
  CONSTRAINT phpbb_sessions_session_viewonline_check CHECK (session_viewonline >= 0), 
  CONSTRAINT phpbb_sessions_session_time_check CHECK (session_time >= 0), 
  CONSTRAINT phpbb_sessions_session_start_check CHECK (session_start >= 0), 
  CONSTRAINT phpbb_sessions_session_last_visit_check CHECK (session_last_visit >= 0), 
  CONSTRAINT phpbb_sessions_session_user_id_check CHECK (session_user_id >= 0)
);
CREATE INDEX phpbb_sessions_session_fid ON phpbb_sessions (session_forum_id);
CREATE INDEX phpbb_sessions_session_time ON phpbb_sessions (session_time);
CREATE INDEX phpbb_sessions_session_user_id ON phpbb_sessions (session_user_id);

COPY phpbb_sessions (session_id, session_user_id, session_last_visit, session_start, session_time, session_ip, session_browser, session_forwarded_for, session_page, session_viewonline, session_autologin, session_admin, session_forum_id) FROM stdin;
79a14123cd737f4f2797385c79d75417	1	1414661761	1414661761	1414661761	42.156.139.31	YisouSpider		viewtopic.php?f=2&t=333	1	0	0	2
be2883c4da5322e6339be248e376d594	1	1414661762	1414661762	1414661762	42.156.137.31	YisouSpider		viewtopic.php?f=28&t=2246	1	0	0	28
d331c39d9b2bc73f27621b11274728dc	1	1414661763	1414661763	1414661763	42.120.161.31	YisouSpider		viewtopic.php?f=13&t=2121	1	0	0	13
0c74d2b7688f8cb24ba49c44e0e76e05	1	1414661765	1414661765	1414661765	42.156.138.31	YisouSpider		viewforum.php?f=20	1	0	0	20
75996b1c2ebfde80652730236c1fd860	1	1414661768	1414661768	1414661768	42.120.160.31	YisouSpider		viewtopic.php?f=38&t=417	1	0	0	38
095acc2213673437603e3ef02611bca7	1	1414661771	1414661771	1414661771	42.156.136.31	YisouSpider		viewtopic.php?f=26&t=3057	1	0	0	26
5734526f91a3fca44a1cb04af7b4c74f	1	1414661775	1414661775	1414661775	42.156.139.31	YisouSpider		viewforum.php?f=30	1	0	0	30
fdc362dff14b0d9e7b294763c68f5ca9	1	1414661780	1414661780	1414661780	42.156.137.31	YisouSpider		viewforum.php?f=18&start=25	1	0	0	18
7b4caeffc0d7f8a492a86b9c7dc8d330	1	1414661782	1414661782	1414661782	59.125.15.165	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:33.0) Gecko/20100101 Firefox/33.0		install/index.php?mode=install&sub=final	1	0	0	0
97b20498670c5a83305108e84b088bb6	1	1414661783	1414661783	1414661783	42.156.138.31	YisouSpider		viewtopic.php?p=10417	1	0	0	0
224587bd6d9fb2d7a3b9dd5d913b58ec	1	1414661783	1414661783	1414661783	42.120.161.31	YisouSpider		viewtopic.php?f=18&t=2525	1	0	0	18
2428d475470f8791ce9b87db641d0d05	1	1414661786	1414661786	1414661786	42.156.136.31	YisouSpider		viewtopic.php?p=4766	1	0	0	0
c0d194ace9618537a626dcea1d1a06bd	1	1414661786	1414661786	1414661786	42.120.160.31	YisouSpider		faq.php	1	0	0	0
ca617d662e04b319413c4864f03f3464	1	1414661786	1414661786	1414661786	42.156.139.31	YisouSpider		viewtopic.php?f=30&t=616	1	0	0	30
bde7313f5c996a9c4f289506365c0ad5	1	1414661791	1414661791	1414661791	42.120.161.31	YisouSpider		viewforum.php?f=1	1	0	0	1
4eea669a879b52eb340d4bd0950daad2	1	1414661791	1414661791	1414661791	42.156.137.31	YisouSpider		viewtopic.php?f=33&t=1365	1	0	0	33
00a0622e98409ee0f97d44c310f7b1d8	1	1414661795	1414661795	1414661795	42.156.138.31	YisouSpider		viewtopic.php?f=8&t=777	1	0	0	8
051622c667f74f1ac3563d0b2d8e05e9	1	1414661797	1414661797	1414661797	42.120.160.31	YisouSpider		viewtopic.php?f=32&t=1739	1	0	0	32
3165c6f40bc5ea96286ef13512dcc540	1	1414661812	1414661812	1414661812	42.156.136.31	YisouSpider		viewtopic.php?f=22&t=284	1	0	0	22
5ac7ac6da61352081f5e84b750bc1ee8	1	1414661812	1414661812	1414661812	42.156.139.31	YisouSpider		viewforum.php?f=5	1	0	0	5
5d1a38b15c09cad64690dfb9b2c6fc08	1	1414661814	1414661814	1414661814	42.156.137.31	YisouSpider		viewforum.php?f=25	1	0	0	25
a0d4359111881b90a0e5b8cb4394007e	1	1414661814	1414661814	1414661814	42.120.161.31	YisouSpider		viewtopic.php?p=10415	1	0	0	0
567210951f9b81e50c5536bd6263c8d8	1	1414661816	1414661816	1414661816	42.156.138.31	YisouSpider		viewtopic.php?f=34&t=3330	1	0	0	34
e3de34fca00d7c756fb277c3942bf4b3	1	1414661817	1414661817	1414661817	42.120.160.31	YisouSpider		viewtopic.php?f=28&t=3366	1	0	0	28
389165d2dcf64191cbabee4edb3fe41d	1	1414661821	1414661821	1414661821	42.156.136.31	YisouSpider		viewtopic.php?f=20&t=3297	1	0	0	20
c996ff18ee8b18dec03b9b206ead2762	1	1414661823	1414661823	1414661823	42.156.139.31	YisouSpider		viewtopic.php?p=4234	1	0	0	0
6248dcf3d4ba763198afee2022d3f5ca	1	1414661823	1414661823	1414661823	42.120.161.31	YisouSpider		viewforum.php?f=5	1	0	0	5
5e3880d8e26209e7dc892aa82477e1c1	1	1414661823	1414661823	1414661823	42.156.138.31	YisouSpider		viewforum.php?f=23	1	0	0	23
5b81729822bd4eedec6afedc7d726073	1	1414661823	1414661823	1414661823	42.156.137.31	YisouSpider		viewforum.php?f=25	1	0	0	25
8d2ed9ad0fa7a67538aa8cf68ede345d	1	1414661834	1414661834	1414661834	42.120.160.31	YisouSpider		viewforum.php?f=37	1	0	0	37
ce6abb469862999c997a97ebe75c5c06	1	1414661835	1414661835	1414661835	42.156.136.31	YisouSpider		viewtopic.php?f=22&t=2305	1	0	0	22
db7eea107012bec2674185b5866bf141	1	1414661851	1414661851	1414661851	42.156.139.31	YisouSpider		viewtopic.php?f=40&t=2753	1	0	0	40
a1e08357ea1d8a45c1aad10dfa8ddf15	1	1414661853	1414661853	1414661853	42.156.137.31	YisouSpider		viewtopic.php?f=29&t=3105	1	0	0	29
d704304dda62f4282c4b24209b5fc7ce	1	1414661855	1414661855	1414661855	42.120.161.31	YisouSpider		viewtopic.php?f=30&t=1852&view=print	1	0	0	30
8b3e1e70c74e03009ebf0f9714ae92c2	1	1414661857	1414661857	1414661857	42.156.138.31	YisouSpider		viewtopic.php?f=40&t=2598	1	0	0	40
df48f95ec25e02ccbb1746d3b930a939	1	1414661860	1414661860	1414661861	42.120.160.31	YisouSpider		viewtopic.php?f=15&t=652	1	0	0	15
1dbf5d677163650860a7f3c5402ef1ec	1	1414661861	1414661861	1414661862	42.156.136.31	YisouSpider		viewtopic.php?f=11&t=2376	1	0	0	11
f89d0be308d5d954963cd1340dfb5d6c	1	1414661863	1414661863	1414661863	42.156.139.31	YisouSpider		viewtopic.php?f=25&t=1963	1	0	0	25
05d82be75914e1ed629cfacb0d37beb2	1	1414661864	1414661864	1414661864	42.156.137.31	YisouSpider		viewtopic.php?f=42&t=2047	1	0	0	42
bcd5ff9354169f7f64b56912d2558477	1	1414661869	1414661869	1414661869	42.120.161.31	YisouSpider		viewforum.php?f=12	1	0	0	12
47858c5d8060d0cf6fb38a54b8d0eb4a	1	1414661877	1414661877	1414661877	42.156.138.31	YisouSpider		viewtopic.php?f=29&t=3275	1	0	0	29
5ffccb7314b3f98fcc477c2e56b9f23f	1	1414661882	1414661882	1414661882	42.156.136.31	YisouSpider		faq.php	1	0	0	0
d79c240d70009780370aef401d94759a	1	1414661882	1414661882	1414661882	42.120.160.31	YisouSpider		viewtopic.php?f=22&t=2288	1	0	0	22
e3185eb4ff9883d7de22807616eb7283	1	1414661887	1414661887	1414661887	42.156.139.31	YisouSpider		viewforum.php?f=18	1	0	0	18
99ad14b9e8858447abc095d59520ba82	1	1414661892	1414661892	1414661892	42.156.137.31	YisouSpider		viewtopic.php?f=3&t=561	1	0	0	3
184af8fbbf6d3a30c6b04b806a94297a	1	1414661892	1414661892	1414661892	42.120.161.31	YisouSpider		viewtopic.php?f=33&t=2557	1	0	0	33
290c76f3f098148d568009f9f2d875a9	1	1414661896	1414661896	1414661896	42.156.138.31	YisouSpider		viewtopic.php?f=11&t=80	1	0	0	11
0f2df1378d97036434b66224fbe1982d	1	1414661897	1414661897	1414661897	42.120.160.31	YisouSpider		viewtopic.php?f=22&t=1463	1	0	0	22
4e910f6b0237f99a35721fdd2050dfaf	1	1414661897	1414661897	1414661897	42.156.136.31	YisouSpider		viewtopic.php?f=32&t=1328	1	0	0	32
b63deeabd15655cda7abaeace6827712	1	1414661898	1414661898	1414661898	42.156.139.31	YisouSpider		viewforum.php?f=21	1	0	0	21
ae6501933bf113f20f96cb2966651edf	1	1414661899	1414661899	1414661899	42.156.137.31	YisouSpider		index.php	1	0	0	0
1230a1379ea997edef14f1435e8653cc	2	1414661782	1414661782	1414661899	59.125.15.165	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:33.0) Gecko/20100101 Firefox/33.0		adm/index.php?action=download&i=acp_database&mode=backup	1	0	1	0
\.
-- Table: phpbb_privmsgs_folder
DROP TABLE phpbb_privmsgs_folder;
DROP SEQUENCE phpbb_privmsgs_folder_seq;
CREATE SEQUENCE phpbb_privmsgs_folder_seq;
CREATE TABLE phpbb_privmsgs_folder(
  folder_id int4 DEFAULT nextval('phpbb_privmsgs_folder_seq'::regclass) NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  folder_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  pm_count int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_privmsgs_folder_pkey PRIMARY KEY (folder_id), 
  CONSTRAINT phpbb_privmsgs_folder_pm_count_check CHECK (pm_count >= 0), 
  CONSTRAINT phpbb_privmsgs_folder_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_privmsgs_folder_folder_id_check CHECK (folder_id >= 0)
);
CREATE INDEX phpbb_privmsgs_folder_user_id ON phpbb_privmsgs_folder (user_id);

COPY phpbb_privmsgs_folder (folder_id, user_id, folder_name, pm_count) FROM stdin;
\.
SELECT SETVAL('phpbb_privmsgs_folder_seq',(select case when max(folder_id)>0 then max(folder_id)+1 else 1 end FROM phpbb_privmsgs_folder));
-- Table: phpbb_styles
DROP TABLE phpbb_styles;
DROP SEQUENCE phpbb_styles_seq;
CREATE SEQUENCE phpbb_styles_seq;
CREATE TABLE phpbb_styles(
  style_id int4 DEFAULT nextval('phpbb_styles_seq'::regclass) NOT NULL, 
  style_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  style_copyright varchar(255) DEFAULT ''::character varying NOT NULL, 
  style_active int2 DEFAULT 1::smallint NOT NULL, 
  style_path varchar(100) DEFAULT ''::character varying NOT NULL, 
  bbcode_bitfield varchar(255) DEFAULT 'kNg='::character varying NOT NULL, 
  style_parent_id int4 DEFAULT 0 NOT NULL, 
  style_parent_tree varchar(8000) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_styles_pkey PRIMARY KEY (style_id), 
  CONSTRAINT phpbb_styles_style_parent_id_check CHECK (style_parent_id >= 0), 
  CONSTRAINT phpbb_styles_style_active_check CHECK (style_active >= 0), 
  CONSTRAINT phpbb_styles_style_id_check CHECK (style_id >= 0)
);
CREATE UNIQUE INDEX phpbb_styles_style_name ON phpbb_styles (style_name);

COPY phpbb_styles (style_id, style_name, style_copyright, style_active, style_path, bbcode_bitfield, style_parent_id, style_parent_tree) FROM stdin;
1	prosilver	&copy; phpBB Limited	1	prosilver	kNg=	0	
\.
SELECT SETVAL('phpbb_styles_seq',(select case when max(style_id)>0 then max(style_id)+1 else 1 end FROM phpbb_styles));
-- Table: phpbb_topics_watch
DROP TABLE phpbb_topics_watch;
CREATE TABLE phpbb_topics_watch(
  topic_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  notify_status int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_topics_watch_notify_status_check CHECK (notify_status >= 0), 
  CONSTRAINT phpbb_topics_watch_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_topics_watch_topic_id_check CHECK (topic_id >= 0)
);
CREATE INDEX phpbb_topics_watch_notify_stat ON phpbb_topics_watch (notify_status);
CREATE INDEX phpbb_topics_watch_topic_id ON phpbb_topics_watch (topic_id);
CREATE INDEX phpbb_topics_watch_user_id ON phpbb_topics_watch (user_id);

COPY phpbb_topics_watch (topic_id, user_id, notify_status) FROM stdin;
\.
-- Table: phpbb_forums_track
DROP TABLE phpbb_forums_track;
CREATE TABLE phpbb_forums_track(
  user_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  mark_time int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_forums_track_pkey PRIMARY KEY (forum_id, user_id), 
  CONSTRAINT phpbb_forums_track_mark_time_check CHECK (mark_time >= 0), 
  CONSTRAINT phpbb_forums_track_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_forums_track_user_id_check CHECK (user_id >= 0)
);
COPY phpbb_forums_track (user_id, forum_id, mark_time) FROM stdin;
\.
-- Table: phpbb_ranks
DROP TABLE phpbb_ranks;
DROP SEQUENCE phpbb_ranks_seq;
CREATE SEQUENCE phpbb_ranks_seq;
CREATE TABLE phpbb_ranks(
  rank_id int4 DEFAULT nextval('phpbb_ranks_seq'::regclass) NOT NULL, 
  rank_title varchar(255) DEFAULT ''::character varying NOT NULL, 
  rank_min int4 DEFAULT 0 NOT NULL, 
  rank_special int2 DEFAULT 0::smallint NOT NULL, 
  rank_image varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_ranks_pkey PRIMARY KEY (rank_id), 
  CONSTRAINT phpbb_ranks_rank_special_check CHECK (rank_special >= 0), 
  CONSTRAINT phpbb_ranks_rank_min_check CHECK (rank_min >= 0), 
  CONSTRAINT phpbb_ranks_rank_id_check CHECK (rank_id >= 0)
);
COPY phpbb_ranks (rank_id, rank_title, rank_min, rank_special, rank_image) FROM stdin;
1	Site Admin	0	1	
\.
SELECT SETVAL('phpbb_ranks_seq',(select case when max(rank_id)>0 then max(rank_id)+1 else 1 end FROM phpbb_ranks));
-- Table: phpbb_forums_access
DROP TABLE phpbb_forums_access;
CREATE TABLE phpbb_forums_access(
  forum_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  session_id char(32) DEFAULT ''::bpchar NOT NULL, 
  CONSTRAINT phpbb_forums_access_pkey PRIMARY KEY (forum_id, session_id, user_id), 
  CONSTRAINT phpbb_forums_access_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_forums_access_forum_id_check CHECK (forum_id >= 0)
);
COPY phpbb_forums_access (forum_id, user_id, session_id) FROM stdin;
\.
-- Table: phpbb_ext
DROP TABLE phpbb_ext;
CREATE TABLE phpbb_ext(
  ext_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  ext_active int2 DEFAULT 0::smallint NOT NULL, 
  ext_state varchar(8000) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_ext_ext_active_check CHECK (ext_active >= 0)
);
CREATE UNIQUE INDEX phpbb_ext_ext_name ON phpbb_ext (ext_name);

COPY phpbb_ext (ext_name, ext_active, ext_state) FROM stdin;
\.
-- Table: phpbb_profile_fields_data
DROP TABLE phpbb_profile_fields_data;
CREATE TABLE phpbb_profile_fields_data(
  user_id int4 DEFAULT 0 NOT NULL, 
  pf_phpbb_interests text DEFAULT ''::text NOT NULL, 
  pf_phpbb_occupation text DEFAULT ''::text NOT NULL, 
  pf_phpbb_location varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_icq varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_googleplus varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_youtube varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_twitter varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_facebook varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_skype varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_website varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_wlm varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_yahoo varchar(255) DEFAULT ''::character varying NOT NULL, 
  pf_phpbb_aol varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_profile_fields_data_pkey PRIMARY KEY (user_id), 
  CONSTRAINT phpbb_profile_fields_data_user_id_check CHECK (user_id >= 0)
);
COPY phpbb_profile_fields_data (user_id, pf_phpbb_interests, pf_phpbb_occupation, pf_phpbb_location, pf_phpbb_icq, pf_phpbb_googleplus, pf_phpbb_youtube, pf_phpbb_twitter, pf_phpbb_facebook, pf_phpbb_skype, pf_phpbb_website, pf_phpbb_wlm, pf_phpbb_yahoo, pf_phpbb_aol) FROM stdin;
\.
-- Table: phpbb_config
DROP TABLE phpbb_config;
CREATE TABLE phpbb_config(
  config_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  config_value varchar(255) DEFAULT ''::character varying NOT NULL, 
  is_dynamic int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_config_pkey PRIMARY KEY (config_name), 
  CONSTRAINT phpbb_config_is_dynamic_check CHECK (is_dynamic >= 0)
);
CREATE INDEX phpbb_config_is_dynamic ON phpbb_config (is_dynamic);

COPY phpbb_config (config_name, config_value, is_dynamic) FROM stdin;
active_sessions	0	0
allow_attachments	1	0
allow_autologin	1	0
allow_avatar	1	0
allow_avatar_gravatar	0	0
allow_avatar_local	0	0
allow_avatar_remote	0	0
allow_avatar_upload	1	0
allow_avatar_remote_upload	0	0
allow_bbcode	1	0
allow_birthdays	1	0
allow_bookmarks	1	0
allow_cdn	0	0
allow_emailreuse	0	0
allow_password_reset	1	0
allow_forum_notify	1	0
allow_live_searches	1	0
allow_mass_pm	1	0
allow_name_chars	USERNAME_CHARS_ANY	0
allow_namechange	0	0
allow_nocensors	0	0
allow_pm_attach	0	0
allow_pm_report	1	0
allow_post_flash	1	0
allow_post_links	1	0
allow_privmsg	1	0
allow_quick_reply	1	0
allow_sig	1	0
allow_sig_bbcode	1	0
allow_sig_flash	0	0
allow_sig_img	1	0
allow_sig_links	1	0
allow_sig_pm	1	0
allow_sig_smilies	1	0
allow_smilies	1	0
allow_topic_notify	1	0
assets_version	1	0
attachment_quota	52428800	0
auth_bbcode_pm	1	0
auth_flash_pm	0	0
auth_img_pm	1	0
auth_method	db	0
auth_smilies_pm	1	0
avatar_filesize	6144	0
avatar_gallery_path	images/avatars/gallery	0
avatar_max_height	90	0
avatar_max_width	90	0
avatar_min_height	20	0
avatar_min_width	20	0
avatar_path	images/avatars/upload	0
board_contact_name		0
board_email_form	0	0
board_email_sig	Thanks, The Management	0
board_hide_emails	1	0
browser_check	1	0
bump_interval	10	0
bump_type	d	0
cache_gc	7200	0
captcha_gd_foreground_noise	0	0
captcha_gd_x_grid	25	0
captcha_gd_y_grid	25	0
captcha_gd_wave	0	0
captcha_gd_3d_noise	1	0
captcha_gd_fonts	1	0
confirm_refresh	1	0
check_attachment_content	1	0
check_dnsbl	0	0
chg_passforce	0	0
contact_admin_form_enable	1	0
cookie_path	/	0
coppa_enable	0	0
coppa_fax		0
coppa_mail		0
database_gc	604800	0
display_last_edited	1	0
display_last_subject	1	0
display_order	0	0
edit_time	0	0
extension_force_unstable	0	0
delete_time	0	0
email_check_mx	1	0
email_function_name	mail	0
email_max_chunk_size	50	0
email_package_size	20	0
enable_confirm	1	0
enable_mod_rewrite	0	0
enable_pm_icons	1	0
enable_post_confirm	1	0
feed_enable	1	0
feed_http_auth	0	0
feed_limit_post	15	0
feed_limit_topic	10	0
feed_overall_forums	0	0
feed_overall	1	0
feed_forum	1	0
feed_topic	1	0
feed_topics_new	1	0
feed_topics_active	0	0
feed_item_statistics	1	0
flood_interval	15	0
form_token_lifetime	7200	0
form_token_mintime	0	0
form_token_sid_guests	1	0
forward_pm	1	0
forwarded_for_check	0	0
full_folder_action	2	0
fulltext_mysql_max_word_len	254	0
fulltext_mysql_min_word_len	4	0
fulltext_native_common_thres	5	0
fulltext_native_load_upd	1	0
fulltext_native_max_chars	14	0
fulltext_native_min_chars	3	0
fulltext_postgres_max_word_len	254	0
fulltext_postgres_min_word_len	4	0
fulltext_postgres_ts_name	simple	0
fulltext_sphinx_indexer_mem_limit	512	0
fulltext_sphinx_stopwords	0	0
gzip_compress	0	0
hot_threshold	25	0
icons_path	images/icons	0
img_create_thumbnail	0	0
img_display_inlined	1	0
img_link_height	0	0
img_link_width	0	0
img_max_height	0	0
img_max_thumb_width	400	0
img_max_width	0	0
img_min_thumb_filesize	12000	0
ip_check	3	0
ip_login_limit_max	50	0
ip_login_limit_time	21600	0
ip_login_limit_use_forwarded	0	0
jab_enable	0	0
board_contact	dreamsxin@qq.com	0
cookie_domain	myleftstudio.org	0
board_timezone	UTC	0
email_enable	1	0
cookie_secure	0	0
force_server_vars	0	0
avatar_salt	928eb4a076f704da9e9465dd5389e1cd	0
captcha_gd	1	0
cookie_name	phpbb3_39y21	0
board_index_text		0
board_disable	0	0
board_disable_msg		0
default_dateformat	D M d, Y g:i a	0
default_style	1	0
jab_host		0
jab_password		0
jab_package_size	20	0
jab_port	5222	0
jab_use_ssl	0	0
jab_username		0
ldap_base_dn		0
ldap_email		0
ldap_password		0
ldap_port		0
ldap_server		0
ldap_uid		0
ldap_user		0
ldap_user_filter		0
legend_sort_groupname	0	0
limit_load	0	0
limit_search_load	0	0
load_anon_lastread	0	0
load_birthdays	1	0
load_cpf_memberlist	1	0
load_cpf_pm	1	0
load_cpf_viewprofile	1	0
load_cpf_viewtopic	1	0
load_db_lastread	1	0
load_db_track	1	0
load_jquery_url	//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js	0
load_jumpbox	1	0
load_moderators	1	0
load_notifications	1	0
load_online	1	0
load_online_guests	1	0
load_online_time	5	0
load_onlinetrack	1	0
load_search	1	0
load_tplcompile	0	0
load_unreads_search	1	0
load_user_activity	1	0
max_attachments	3	0
max_attachments_pm	1	0
max_autologin_time	0	0
max_filesize	262144	0
max_filesize_pm	262144	0
max_login_attempts	3	0
max_name_chars	20	0
max_num_search_keywords	10	0
max_pass_chars	100	0
max_poll_options	10	0
max_post_chars	60000	0
max_post_font_size	200	0
max_post_img_height	0	0
max_post_img_width	0	0
max_post_smilies	0	0
max_post_urls	0	0
max_quote_depth	3	0
max_reg_attempts	5	0
max_sig_chars	255	0
max_sig_font_size	200	0
max_sig_img_height	0	0
max_sig_img_width	0	0
max_sig_smilies	0	0
max_sig_urls	5	0
min_name_chars	3	0
min_pass_chars	6	0
min_post_chars	1	0
min_search_author_chars	3	0
mime_triggers	body|head|html|img|plaintext|a href|pre|script|table|title	0
new_member_post_limit	3	0
new_member_group_default	0	0
pass_complex	PASS_TYPE_ANY	0
pm_edit_time	0	0
pm_max_boxes	4	0
pm_max_msgs	50	0
pm_max_recipients	0	0
posts_per_page	10	0
print_pm	1	0
queue_interval	60	0
ranks_path	images/ranks	0
read_notification_expire_days	30	0
read_notification_gc	86400	0
require_activation	0	0
referer_validation	1	0
search_block_size	250	0
search_gc	7200	0
search_interval	0	0
search_anonymous_interval	0	0
search_type	phpbbsearch\fulltext_native	0
search_store_results	1800	0
secure_allow_deny	1	0
secure_allow_empty_referer	1	0
secure_downloads	0	0
session_gc	3600	0
session_length	3600	0
smilies_path	images/smilies	0
smilies_per_page	50	0
smtp_port	25	0
teampage_memberships	1	0
teampage_forums	1	0
topics_per_page	25	0
tpl_allow_php	0	0
upload_icons_path	images/upload_icons	0
upload_path	files	0
use_system_cron	0	0
version	3.1.0	0
warnings_gc	14400	0
cache_last_gc	0	1
cron_lock	0	1
database_last_gc	0	1
last_queue_run	0	1
newest_user_colour	AA0000	1
newest_user_id	2	1
num_files	0	1
num_posts	1	1
num_topics	1	1
num_users	1	1
plupload_last_gc	0	1
read_notification_last_gc	0	1
record_online_date	0	1
record_online_users	0	1
search_indexing_state		1
search_last_gc	0	1
session_last_gc	0	1
upload_dir_size	0	1
warnings_last_gc	0	1
board_startdate	1414661761	0
sitename	御舟家園	0
rand_seed	dd346409c0c749c56421bf2e15b23720	1
img_imagick		0
server_name	myleftstudio.org	0
server_port	80	0
board_email	dreamsxin@qq.com	0
smtp_delivery	0	0
smtp_host		0
smtp_auth_method	PLAIN	0
smtp_username		0
smtp_password		0
script_path	/	0
server_protocol	http://	0
newest_username	myleftstudio	1
plupload_salt	ccc792091cf5234acd04dc3c305c436d	0
dbms_version	8.4.14 on x86_64-pc-linux-gnu, compiled by GCC gcc-4.5.real (Ubuntu/Linaro 4.5.2-8ubuntu4) 4.5.2, 64-bit	0
captcha_plugin	core.captcha.plugins.gd	0
site_desc	讓生活變得簡單	0
site_home_url		0
site_home_text		0
default_lang	en	0
override_user_style	0	0
warnings_expire_days	90	0
questionnaire_unique_id	1d1053ec20719730	0
rand_seed_last_update	1414661897	1
\.
-- Table: phpbb_user_group
DROP TABLE phpbb_user_group;
CREATE TABLE phpbb_user_group(
  group_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  group_leader int2 DEFAULT 0::smallint NOT NULL, 
  user_pending int2 DEFAULT 1::smallint NOT NULL, 
  CONSTRAINT phpbb_user_group_user_pending_check CHECK (user_pending >= 0), 
  CONSTRAINT phpbb_user_group_group_leader_check CHECK (group_leader >= 0), 
  CONSTRAINT phpbb_user_group_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_user_group_group_id_check CHECK (group_id >= 0)
);
CREATE INDEX phpbb_user_group_group_id ON phpbb_user_group (group_id);
CREATE INDEX phpbb_user_group_group_leader ON phpbb_user_group (group_leader);
CREATE INDEX phpbb_user_group_user_id ON phpbb_user_group (user_id);

COPY phpbb_user_group (group_id, user_id, group_leader, user_pending) FROM stdin;
1	1	0	0
2	2	0	0
4	2	0	0
5	2	1	0
6	3	0	0
6	4	0	0
6	5	0	0
6	6	0	0
6	7	0	0
6	8	0	0
6	9	0	0
6	10	0	0
6	11	0	0
6	12	0	0
6	13	0	0
6	14	0	0
6	15	0	0
6	16	0	0
6	17	0	0
6	18	0	0
6	19	0	0
6	20	0	0
6	21	0	0
6	22	0	0
6	23	0	0
6	24	0	0
6	25	0	0
6	26	0	0
6	27	0	0
6	28	0	0
6	29	0	0
6	30	0	0
6	31	0	0
6	32	0	0
6	33	0	0
6	34	0	0
6	35	0	0
6	36	0	0
6	37	0	0
6	38	0	0
6	39	0	0
6	40	0	0
6	41	0	0
6	42	0	0
6	43	0	0
6	44	0	0
6	45	0	0
6	46	0	0
6	47	0	0
\.
-- Table: phpbb_profile_lang
DROP TABLE phpbb_profile_lang;
CREATE TABLE phpbb_profile_lang(
  field_id int4 DEFAULT 0 NOT NULL, 
  lang_id int4 DEFAULT 0 NOT NULL, 
  lang_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  lang_explain varchar(4000) DEFAULT ''::character varying NOT NULL, 
  lang_default_value varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_profile_lang_pkey PRIMARY KEY (field_id, lang_id), 
  CONSTRAINT phpbb_profile_lang_lang_id_check CHECK (lang_id >= 0), 
  CONSTRAINT phpbb_profile_lang_field_id_check CHECK (field_id >= 0)
);
COPY phpbb_profile_lang (field_id, lang_id, lang_name, lang_explain, lang_default_value) FROM stdin;
1	1	LOCATION		
2	1	WEBSITE		
3	1	INTERESTS		
4	1	OCCUPATION		
5	1	AOL		
6	1	ICQ		
7	1	WLM		
8	1	YAHOO		
9	1	FACEBOOK		
10	1	TWITTER		
11	1	SKYPE		
12	1	YOUTUBE		
13	1	GOOGLEPLUS		
\.
-- Table: phpbb_moderator_cache
DROP TABLE phpbb_moderator_cache;
CREATE TABLE phpbb_moderator_cache(
  forum_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  username varchar(255) DEFAULT ''::character varying NOT NULL, 
  group_id int4 DEFAULT 0 NOT NULL, 
  group_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  display_on_index int2 DEFAULT 1::smallint NOT NULL, 
  CONSTRAINT phpbb_moderator_cache_display_on_index_check CHECK (display_on_index >= 0), 
  CONSTRAINT phpbb_moderator_cache_group_id_check CHECK (group_id >= 0), 
  CONSTRAINT phpbb_moderator_cache_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_moderator_cache_forum_id_check CHECK (forum_id >= 0)
);
CREATE INDEX phpbb_moderator_cache_disp_idx ON phpbb_moderator_cache (display_on_index);
CREATE INDEX phpbb_moderator_cache_forum_id ON phpbb_moderator_cache (forum_id);

COPY phpbb_moderator_cache (forum_id, user_id, username, group_id, group_name, display_on_index) FROM stdin;
\.
-- Table: phpbb_warnings
DROP TABLE phpbb_warnings;
DROP SEQUENCE phpbb_warnings_seq;
CREATE SEQUENCE phpbb_warnings_seq;
CREATE TABLE phpbb_warnings(
  warning_id int4 DEFAULT nextval('phpbb_warnings_seq'::regclass) NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  post_id int4 DEFAULT 0 NOT NULL, 
  log_id int4 DEFAULT 0 NOT NULL, 
  warning_time int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_warnings_pkey PRIMARY KEY (warning_id), 
  CONSTRAINT phpbb_warnings_warning_time_check CHECK (warning_time >= 0), 
  CONSTRAINT phpbb_warnings_log_id_check CHECK (log_id >= 0), 
  CONSTRAINT phpbb_warnings_post_id_check CHECK (post_id >= 0), 
  CONSTRAINT phpbb_warnings_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_warnings_warning_id_check CHECK (warning_id >= 0)
);
COPY phpbb_warnings (warning_id, user_id, post_id, log_id, warning_time) FROM stdin;
\.
SELECT SETVAL('phpbb_warnings_seq',(select case when max(warning_id)>0 then max(warning_id)+1 else 1 end FROM phpbb_warnings));
-- Table: phpbb_log
DROP TABLE phpbb_log;
DROP SEQUENCE phpbb_log_seq;
CREATE SEQUENCE phpbb_log_seq;
CREATE TABLE phpbb_log(
  log_id int4 DEFAULT nextval('phpbb_log_seq'::regclass) NOT NULL, 
  log_type int2 DEFAULT 0::smallint NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  reportee_id int4 DEFAULT 0 NOT NULL, 
  log_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  log_time int4 DEFAULT 0 NOT NULL, 
  log_operation varchar(4000) DEFAULT ''::character varying NOT NULL, 
  log_data text DEFAULT ''::text NOT NULL, 
  CONSTRAINT phpbb_log_pkey PRIMARY KEY (log_id), 
  CONSTRAINT phpbb_log_log_time_check CHECK (log_time >= 0), 
  CONSTRAINT phpbb_log_reportee_id_check CHECK (reportee_id >= 0), 
  CONSTRAINT phpbb_log_topic_id_check CHECK (topic_id >= 0), 
  CONSTRAINT phpbb_log_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_log_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_log_log_id_check CHECK (log_id >= 0)
);
CREATE INDEX phpbb_log_forum_id ON phpbb_log (forum_id);
CREATE INDEX phpbb_log_log_type ON phpbb_log (log_type);
CREATE INDEX phpbb_log_reportee_id ON phpbb_log (reportee_id);
CREATE INDEX phpbb_log_topic_id ON phpbb_log (topic_id);
CREATE INDEX phpbb_log_user_id ON phpbb_log (user_id);

COPY phpbb_log (log_id, log_type, user_id, forum_id, topic_id, reportee_id, log_ip, log_time, log_operation, log_data) FROM stdin;
1	0	2	0	0	0	59.125.15.165	1414661783	LOG_INSTALL_INSTALLED	a:1:{i:0;s:5:\"3.1.0\";}
2	0	2	0	0	0	59.125.15.165	1414661851	LOG_CONFIG_SETTINGS	
\.
SELECT SETVAL('phpbb_log_seq',(select case when max(log_id)>0 then max(log_id)+1 else 1 end FROM phpbb_log));
-- Table: phpbb_poll_options
DROP TABLE phpbb_poll_options;
CREATE TABLE phpbb_poll_options(
  poll_option_id int2 DEFAULT 0::smallint NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  poll_option_text varchar(4000) DEFAULT ''::character varying NOT NULL, 
  poll_option_total int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_poll_options_poll_option_total_check CHECK (poll_option_total >= 0), 
  CONSTRAINT phpbb_poll_options_topic_id_check CHECK (topic_id >= 0)
);
CREATE INDEX phpbb_poll_options_poll_opt_id ON phpbb_poll_options (poll_option_id);
CREATE INDEX phpbb_poll_options_topic_id ON phpbb_poll_options (topic_id);

COPY phpbb_poll_options (poll_option_id, topic_id, poll_option_text, poll_option_total) FROM stdin;
\.
-- Table: phpbb_bookmarks
DROP TABLE phpbb_bookmarks;
CREATE TABLE phpbb_bookmarks(
  topic_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_bookmarks_pkey PRIMARY KEY (topic_id, user_id), 
  CONSTRAINT phpbb_bookmarks_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_bookmarks_topic_id_check CHECK (topic_id >= 0)
);
COPY phpbb_bookmarks (topic_id, user_id) FROM stdin;
\.
-- Table: phpbb_search_wordmatch
DROP TABLE phpbb_search_wordmatch;
CREATE TABLE phpbb_search_wordmatch(
  post_id int4 DEFAULT 0 NOT NULL, 
  word_id int4 DEFAULT 0 NOT NULL, 
  title_match int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_search_wordmatch_title_match_check CHECK (title_match >= 0), 
  CONSTRAINT phpbb_search_wordmatch_word_id_check CHECK (word_id >= 0), 
  CONSTRAINT phpbb_search_wordmatch_post_id_check CHECK (post_id >= 0)
);
CREATE INDEX phpbb_search_wordmatch_post_id ON phpbb_search_wordmatch (post_id);
CREATE UNIQUE INDEX phpbb_search_wordmatch_un_mtch ON phpbb_search_wordmatch (post_id, title_match, word_id);
CREATE INDEX phpbb_search_wordmatch_word_id ON phpbb_search_wordmatch (word_id);

COPY phpbb_search_wordmatch (post_id, word_id, title_match) FROM stdin;
1	1	0
1	2	0
1	3	0
1	4	0
1	5	0
1	6	0
1	7	0
1	8	0
1	9	0
1	10	0
1	11	0
1	12	0
1	13	0
1	14	0
1	15	0
1	16	0
1	17	0
1	18	0
1	19	0
1	20	0
1	21	0
1	22	0
1	23	0
1	24	0
1	25	0
1	26	0
1	27	0
1	28	0
1	29	0
1	30	0
1	31	0
1	32	0
1	33	0
1	34	0
1	35	0
1	36	0
1	37	0
1	38	0
1	39	0
1	40	0
1	41	0
1	42	0
1	43	0
1	44	0
1	45	0
1	46	0
1	47	0
1	48	0
1	49	0
1	50	0
1	51	0
1	52	0
1	53	0
1	54	0
1	55	0
1	56	0
1	57	0
1	58	1
1	5	1
\.
-- Table: phpbb_config_text
DROP TABLE phpbb_config_text;
CREATE TABLE phpbb_config_text(
  config_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  config_value text DEFAULT ''::text NOT NULL, 
  CONSTRAINT phpbb_config_text_pkey PRIMARY KEY (config_name)
);
COPY phpbb_config_text (config_name, config_value) FROM stdin;
contact_admin_info	
contact_admin_info_uid	
contact_admin_info_bitfield	
contact_admin_info_flags	7
\.
-- Table: phpbb_forums
DROP TABLE phpbb_forums;
DROP SEQUENCE phpbb_forums_seq;
CREATE SEQUENCE phpbb_forums_seq;
CREATE TABLE phpbb_forums(
  forum_id int4 DEFAULT nextval('phpbb_forums_seq'::regclass) NOT NULL, 
  parent_id int4 DEFAULT 0 NOT NULL, 
  left_id int4 DEFAULT 0 NOT NULL, 
  right_id int4 DEFAULT 0 NOT NULL, 
  forum_parents text DEFAULT ''::text NOT NULL, 
  forum_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_desc varchar(4000) DEFAULT ''::character varying NOT NULL, 
  forum_desc_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_desc_options int4 DEFAULT 7 NOT NULL, 
  forum_desc_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  forum_link varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_password varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_style int4 DEFAULT 0 NOT NULL, 
  forum_image varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_rules varchar(4000) DEFAULT ''::character varying NOT NULL, 
  forum_rules_link varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_rules_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_rules_options int4 DEFAULT 7 NOT NULL, 
  forum_rules_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  forum_topics_per_page int2 DEFAULT 0::smallint NOT NULL, 
  forum_type int2 DEFAULT 0::smallint NOT NULL, 
  forum_status int2 DEFAULT 0::smallint NOT NULL, 
  forum_last_post_id int4 DEFAULT 0 NOT NULL, 
  forum_last_poster_id int4 DEFAULT 0 NOT NULL, 
  forum_last_post_subject varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_last_post_time int4 DEFAULT 0 NOT NULL, 
  forum_last_poster_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  forum_last_poster_colour varchar(6) DEFAULT ''::character varying NOT NULL, 
  forum_flags int2 DEFAULT 32::smallint NOT NULL, 
  display_on_index int2 DEFAULT 1::smallint NOT NULL, 
  enable_indexing int2 DEFAULT 1::smallint NOT NULL, 
  enable_icons int2 DEFAULT 1::smallint NOT NULL, 
  enable_prune int2 DEFAULT 0::smallint NOT NULL, 
  prune_next int4 DEFAULT 0 NOT NULL, 
  prune_days int4 DEFAULT 0 NOT NULL, 
  prune_viewed int4 DEFAULT 0 NOT NULL, 
  prune_freq int4 DEFAULT 0 NOT NULL, 
  display_subforum_list int2 DEFAULT 1::smallint NOT NULL, 
  forum_options int4 DEFAULT 0 NOT NULL, 
  forum_posts_approved int4 DEFAULT 0 NOT NULL, 
  forum_posts_unapproved int4 DEFAULT 0 NOT NULL, 
  forum_posts_softdeleted int4 DEFAULT 0 NOT NULL, 
  forum_topics_approved int4 DEFAULT 0 NOT NULL, 
  forum_topics_unapproved int4 DEFAULT 0 NOT NULL, 
  forum_topics_softdeleted int4 DEFAULT 0 NOT NULL, 
  enable_shadow_prune int2 DEFAULT 0::smallint NOT NULL, 
  prune_shadow_days int4 DEFAULT 7 NOT NULL, 
  prune_shadow_freq int4 DEFAULT 1 NOT NULL, 
  prune_shadow_next int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_forums_pkey PRIMARY KEY (forum_id), 
  CONSTRAINT phpbb_forums_prune_shadow_freq_check CHECK (prune_shadow_freq >= 0), 
  CONSTRAINT phpbb_forums_prune_shadow_days_check CHECK (prune_shadow_days >= 0), 
  CONSTRAINT phpbb_forums_enable_shadow_prune_check CHECK (enable_shadow_prune >= 0), 
  CONSTRAINT phpbb_forums_forum_topics_softdeleted_check CHECK (forum_topics_softdeleted >= 0), 
  CONSTRAINT phpbb_forums_forum_topics_unapproved_check CHECK (forum_topics_unapproved >= 0), 
  CONSTRAINT phpbb_forums_forum_topics_approved_check CHECK (forum_topics_approved >= 0), 
  CONSTRAINT phpbb_forums_forum_posts_softdeleted_check CHECK (forum_posts_softdeleted >= 0), 
  CONSTRAINT phpbb_forums_forum_posts_unapproved_check CHECK (forum_posts_unapproved >= 0), 
  CONSTRAINT phpbb_forums_forum_posts_approved_check CHECK (forum_posts_approved >= 0), 
  CONSTRAINT phpbb_forums_forum_options_check CHECK (forum_options >= 0), 
  CONSTRAINT phpbb_forums_display_subforum_list_check CHECK (display_subforum_list >= 0), 
  CONSTRAINT phpbb_forums_prune_freq_check CHECK (prune_freq >= 0), 
  CONSTRAINT phpbb_forums_prune_viewed_check CHECK (prune_viewed >= 0), 
  CONSTRAINT phpbb_forums_prune_days_check CHECK (prune_days >= 0), 
  CONSTRAINT phpbb_forums_prune_next_check CHECK (prune_next >= 0), 
  CONSTRAINT phpbb_forums_enable_prune_check CHECK (enable_prune >= 0), 
  CONSTRAINT phpbb_forums_enable_icons_check CHECK (enable_icons >= 0), 
  CONSTRAINT phpbb_forums_enable_indexing_check CHECK (enable_indexing >= 0), 
  CONSTRAINT phpbb_forums_display_on_index_check CHECK (display_on_index >= 0), 
  CONSTRAINT phpbb_forums_forum_last_post_time_check CHECK (forum_last_post_time >= 0), 
  CONSTRAINT phpbb_forums_forum_last_poster_id_check CHECK (forum_last_poster_id >= 0), 
  CONSTRAINT phpbb_forums_forum_last_post_id_check CHECK (forum_last_post_id >= 0), 
  CONSTRAINT phpbb_forums_forum_rules_options_check CHECK (forum_rules_options >= 0), 
  CONSTRAINT phpbb_forums_forum_style_check CHECK (forum_style >= 0), 
  CONSTRAINT phpbb_forums_forum_desc_options_check CHECK (forum_desc_options >= 0), 
  CONSTRAINT phpbb_forums_right_id_check CHECK (right_id >= 0), 
  CONSTRAINT phpbb_forums_left_id_check CHECK (left_id >= 0), 
  CONSTRAINT phpbb_forums_parent_id_check CHECK (parent_id >= 0), 
  CONSTRAINT phpbb_forums_forum_id_check CHECK (forum_id >= 0)
);
CREATE INDEX phpbb_forums_forum_lastpost_id ON phpbb_forums (forum_last_post_id);
CREATE INDEX phpbb_forums_left_right_id ON phpbb_forums (left_id, right_id);

COPY phpbb_forums (forum_id, parent_id, left_id, right_id, forum_parents, forum_name, forum_desc, forum_desc_bitfield, forum_desc_options, forum_desc_uid, forum_link, forum_password, forum_style, forum_image, forum_rules, forum_rules_link, forum_rules_bitfield, forum_rules_options, forum_rules_uid, forum_topics_per_page, forum_type, forum_status, forum_last_post_id, forum_last_poster_id, forum_last_post_subject, forum_last_post_time, forum_last_poster_name, forum_last_poster_colour, forum_flags, display_on_index, enable_indexing, enable_icons, enable_prune, prune_next, prune_days, prune_viewed, prune_freq, display_subforum_list, forum_options, forum_posts_approved, forum_posts_unapproved, forum_posts_softdeleted, forum_topics_approved, forum_topics_unapproved, forum_topics_softdeleted, enable_shadow_prune, prune_shadow_days, prune_shadow_freq, prune_shadow_next) FROM stdin;
1	0	1	4		Your first category			7				0					7		0	0	0	1	2		1414661761	myleftstudio	AA0000	32	1	1	1	0	0	0	0	0	1	0	0	0	0	0	0	0	0	7	1	0
2	1	2	3		Your first forum	Description of your first forum.		7				0					7		0	1	0	1	2	Welcome to phpBB3	1414661761	myleftstudio	AA0000	48	1	1	1	0	0	0	0	0	1	0	1	0	0	1	0	0	0	7	1	0
\.
SELECT SETVAL('phpbb_forums_seq',(select case when max(forum_id)>0 then max(forum_id)+1 else 1 end FROM phpbb_forums));
-- Table: phpbb_poll_votes
DROP TABLE phpbb_poll_votes;
CREATE TABLE phpbb_poll_votes(
  topic_id int4 DEFAULT 0 NOT NULL, 
  poll_option_id int2 DEFAULT 0::smallint NOT NULL, 
  vote_user_id int4 DEFAULT 0 NOT NULL, 
  vote_user_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_poll_votes_vote_user_id_check CHECK (vote_user_id >= 0), 
  CONSTRAINT phpbb_poll_votes_topic_id_check CHECK (topic_id >= 0)
);
CREATE INDEX phpbb_poll_votes_topic_id ON phpbb_poll_votes (topic_id);
CREATE INDEX phpbb_poll_votes_vote_user_id ON phpbb_poll_votes (vote_user_id);
CREATE INDEX phpbb_poll_votes_vote_user_ip ON phpbb_poll_votes (vote_user_ip);

COPY phpbb_poll_votes (topic_id, poll_option_id, vote_user_id, vote_user_ip) FROM stdin;
\.
-- Table: phpbb_acl_groups
DROP TABLE phpbb_acl_groups;
CREATE TABLE phpbb_acl_groups(
  group_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  auth_option_id int4 DEFAULT 0 NOT NULL, 
  auth_role_id int4 DEFAULT 0 NOT NULL, 
  auth_setting int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_acl_groups_auth_role_id_check CHECK (auth_role_id >= 0), 
  CONSTRAINT phpbb_acl_groups_auth_option_id_check CHECK (auth_option_id >= 0), 
  CONSTRAINT phpbb_acl_groups_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_acl_groups_group_id_check CHECK (group_id >= 0)
);
CREATE INDEX phpbb_acl_groups_auth_opt_id ON phpbb_acl_groups (auth_option_id);
CREATE INDEX phpbb_acl_groups_auth_role_id ON phpbb_acl_groups (auth_role_id);
CREATE INDEX phpbb_acl_groups_group_id ON phpbb_acl_groups (group_id);

COPY phpbb_acl_groups (group_id, forum_id, auth_option_id, auth_role_id, auth_setting) FROM stdin;
1	0	88	0	1
1	0	97	0	1
1	0	115	0	1
5	0	0	5	0
5	0	0	1	0
2	0	0	6	0
3	0	0	6	0
4	0	0	5	0
4	0	0	10	0
1	1	0	17	0
2	1	0	17	0
3	1	0	17	0
6	1	0	17	0
1	2	0	17	0
2	2	0	15	0
3	2	0	15	0
4	2	0	21	0
5	2	0	14	0
5	2	0	10	0
6	2	0	19	0
7	0	0	23	0
7	2	0	24	0
\.
-- Table: phpbb_confirm
DROP TABLE phpbb_confirm;
CREATE TABLE phpbb_confirm(
  confirm_id char(32) DEFAULT ''::bpchar NOT NULL, 
  session_id char(32) DEFAULT ''::bpchar NOT NULL, 
  confirm_type int2 DEFAULT 0::smallint NOT NULL, 
  code varchar(8) DEFAULT ''::character varying NOT NULL, 
  seed int4 DEFAULT 0 NOT NULL, 
  attempts int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_confirm_pkey PRIMARY KEY (confirm_id, session_id), 
  CONSTRAINT phpbb_confirm_attempts_check CHECK (attempts >= 0), 
  CONSTRAINT phpbb_confirm_seed_check CHECK (seed >= 0)
);
CREATE INDEX phpbb_confirm_confirm_type ON phpbb_confirm (confirm_type);

COPY phpbb_confirm (confirm_id, session_id, confirm_type, code, seed, attempts) FROM stdin;
\.
-- Table: phpbb_reports_reasons
DROP TABLE phpbb_reports_reasons;
DROP SEQUENCE phpbb_reports_reasons_seq;
CREATE SEQUENCE phpbb_reports_reasons_seq;
CREATE TABLE phpbb_reports_reasons(
  reason_id int2 DEFAULT nextval('phpbb_reports_reasons_seq'::regclass) NOT NULL, 
  reason_title varchar(255) DEFAULT ''::character varying NOT NULL, 
  reason_description text DEFAULT ''::text NOT NULL, 
  reason_order int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_reports_reasons_pkey PRIMARY KEY (reason_id), 
  CONSTRAINT phpbb_reports_reasons_reason_order_check CHECK (reason_order >= 0), 
  CONSTRAINT phpbb_reports_reasons_reason_id_check CHECK (reason_id >= 0)
);
COPY phpbb_reports_reasons (reason_id, reason_title, reason_description, reason_order) FROM stdin;
1	warez	The post contains links to illegal or pirated software.	1
2	spam	The reported post has the only purpose to advertise for a website or another product.	2
3	off_topic	The reported post is off topic.	3
4	other	The reported post does not fit into any other category, please use the further information field.	4
\.
SELECT SETVAL('phpbb_reports_reasons_seq',(select case when max(reason_id)>0 then max(reason_id)+1 else 1 end FROM phpbb_reports_reasons));
-- Table: phpbb_banlist
DROP TABLE phpbb_banlist;
DROP SEQUENCE phpbb_banlist_seq;
CREATE SEQUENCE phpbb_banlist_seq;
CREATE TABLE phpbb_banlist(
  ban_id int4 DEFAULT nextval('phpbb_banlist_seq'::regclass) NOT NULL, 
  ban_userid int4 DEFAULT 0 NOT NULL, 
  ban_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  ban_email varchar(100) DEFAULT ''::character varying NOT NULL, 
  ban_start int4 DEFAULT 0 NOT NULL, 
  ban_end int4 DEFAULT 0 NOT NULL, 
  ban_exclude int2 DEFAULT 0::smallint NOT NULL, 
  ban_reason varchar(255) DEFAULT ''::character varying NOT NULL, 
  ban_give_reason varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_banlist_pkey PRIMARY KEY (ban_id), 
  CONSTRAINT phpbb_banlist_ban_exclude_check CHECK (ban_exclude >= 0), 
  CONSTRAINT phpbb_banlist_ban_end_check CHECK (ban_end >= 0), 
  CONSTRAINT phpbb_banlist_ban_start_check CHECK (ban_start >= 0), 
  CONSTRAINT phpbb_banlist_ban_userid_check CHECK (ban_userid >= 0), 
  CONSTRAINT phpbb_banlist_ban_id_check CHECK (ban_id >= 0)
);
CREATE INDEX phpbb_banlist_ban_email ON phpbb_banlist (ban_email, ban_exclude);
CREATE INDEX phpbb_banlist_ban_end ON phpbb_banlist (ban_end);
CREATE INDEX phpbb_banlist_ban_ip ON phpbb_banlist (ban_exclude, ban_ip);
CREATE INDEX phpbb_banlist_ban_user ON phpbb_banlist (ban_exclude, ban_userid);

COPY phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email, ban_start, ban_end, ban_exclude, ban_reason, ban_give_reason) FROM stdin;
\.
SELECT SETVAL('phpbb_banlist_seq',(select case when max(ban_id)>0 then max(ban_id)+1 else 1 end FROM phpbb_banlist));
-- Table: phpbb_posts
DROP TABLE phpbb_posts;
DROP SEQUENCE phpbb_posts_seq;
CREATE SEQUENCE phpbb_posts_seq;
CREATE TABLE phpbb_posts(
  post_id int4 DEFAULT nextval('phpbb_posts_seq'::regclass) NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  poster_id int4 DEFAULT 0 NOT NULL, 
  icon_id int4 DEFAULT 0 NOT NULL, 
  poster_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  post_time int4 DEFAULT 0 NOT NULL, 
  post_reported int2 DEFAULT 0::smallint NOT NULL, 
  enable_bbcode int2 DEFAULT 1::smallint NOT NULL, 
  enable_smilies int2 DEFAULT 1::smallint NOT NULL, 
  enable_magic_url int2 DEFAULT 1::smallint NOT NULL, 
  enable_sig int2 DEFAULT 1::smallint NOT NULL, 
  post_username varchar(255) DEFAULT ''::character varying NOT NULL, 
  post_subject varchar(255) DEFAULT ''::character varying NOT NULL, 
  post_text text DEFAULT ''::text NOT NULL, 
  post_checksum varchar(32) DEFAULT ''::character varying NOT NULL, 
  post_attachment int2 DEFAULT 0::smallint NOT NULL, 
  bbcode_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  bbcode_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  post_postcount int2 DEFAULT 1::smallint NOT NULL, 
  post_edit_time int4 DEFAULT 0 NOT NULL, 
  post_edit_reason varchar(255) DEFAULT ''::character varying NOT NULL, 
  post_edit_user int4 DEFAULT 0 NOT NULL, 
  post_edit_count int2 DEFAULT 0::smallint NOT NULL, 
  post_edit_locked int2 DEFAULT 0::smallint NOT NULL, 
  post_visibility int2 DEFAULT 0::smallint NOT NULL, 
  post_delete_time int4 DEFAULT 0 NOT NULL, 
  post_delete_reason varchar(255) DEFAULT ''::character varying NOT NULL, 
  post_delete_user int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_posts_pkey PRIMARY KEY (post_id), 
  CONSTRAINT phpbb_posts_post_delete_user_check CHECK (post_delete_user >= 0), 
  CONSTRAINT phpbb_posts_post_delete_time_check CHECK (post_delete_time >= 0), 
  CONSTRAINT phpbb_posts_post_edit_locked_check CHECK (post_edit_locked >= 0), 
  CONSTRAINT phpbb_posts_post_edit_count_check CHECK (post_edit_count >= 0), 
  CONSTRAINT phpbb_posts_post_edit_user_check CHECK (post_edit_user >= 0), 
  CONSTRAINT phpbb_posts_post_edit_time_check CHECK (post_edit_time >= 0), 
  CONSTRAINT phpbb_posts_post_postcount_check CHECK (post_postcount >= 0), 
  CONSTRAINT phpbb_posts_post_attachment_check CHECK (post_attachment >= 0), 
  CONSTRAINT phpbb_posts_enable_sig_check CHECK (enable_sig >= 0), 
  CONSTRAINT phpbb_posts_enable_magic_url_check CHECK (enable_magic_url >= 0), 
  CONSTRAINT phpbb_posts_enable_smilies_check CHECK (enable_smilies >= 0), 
  CONSTRAINT phpbb_posts_enable_bbcode_check CHECK (enable_bbcode >= 0), 
  CONSTRAINT phpbb_posts_post_reported_check CHECK (post_reported >= 0), 
  CONSTRAINT phpbb_posts_post_time_check CHECK (post_time >= 0), 
  CONSTRAINT phpbb_posts_icon_id_check CHECK (icon_id >= 0), 
  CONSTRAINT phpbb_posts_poster_id_check CHECK (poster_id >= 0), 
  CONSTRAINT phpbb_posts_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_posts_topic_id_check CHECK (topic_id >= 0), 
  CONSTRAINT phpbb_posts_post_id_check CHECK (post_id >= 0)
);
CREATE INDEX phpbb_posts_forum_id ON phpbb_posts (forum_id);
CREATE INDEX phpbb_posts_post_username ON phpbb_posts (post_username);
CREATE INDEX phpbb_posts_post_visibility ON phpbb_posts (post_visibility);
CREATE INDEX phpbb_posts_poster_id ON phpbb_posts (poster_id);
CREATE INDEX phpbb_posts_poster_ip ON phpbb_posts (poster_ip);
CREATE INDEX phpbb_posts_tid_post_time ON phpbb_posts (post_time, topic_id);
CREATE INDEX phpbb_posts_topic_id ON phpbb_posts (topic_id);

COPY phpbb_posts (post_id, topic_id, forum_id, poster_id, icon_id, poster_ip, post_time, post_reported, enable_bbcode, enable_smilies, enable_magic_url, enable_sig, post_username, post_subject, post_text, post_checksum, post_attachment, bbcode_bitfield, bbcode_uid, post_postcount, post_edit_time, post_edit_reason, post_edit_user, post_edit_count, post_edit_locked, post_visibility, post_delete_time, post_delete_reason, post_delete_user) FROM stdin;
1	1	2	2	0	59.125.15.165	1414661761	0	1	1	1	1		Welcome to phpBB3	This is an example post in your phpBB3 installation. Everything seems to be working. You may delete this post if you like and continue to set up your board. During the installation process your first category and your first forum are assigned an appropriate set of permissions for the predefined usergroups administrators, bots, global moderators, guests, registered users and registered COPPA users. If you also choose to delete your first category and your first forum, do not forget to assign permissions for all these usergroups for all new categories and forums you create. It is recommended to rename your first category and your first forum and copy permissions from these while creating new categories and forums. Have fun!	5dd683b17f641daf84c040bfefc58ce9	0			1	0		0	0	0	1	0		0
\.
SELECT SETVAL('phpbb_posts_seq',(select case when max(post_id)>0 then max(post_id)+1 else 1 end FROM phpbb_posts));
-- Table: phpbb_privmsgs_to
DROP TABLE phpbb_privmsgs_to;
CREATE TABLE phpbb_privmsgs_to(
  msg_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  author_id int4 DEFAULT 0 NOT NULL, 
  pm_deleted int2 DEFAULT 0::smallint NOT NULL, 
  pm_new int2 DEFAULT 1::smallint NOT NULL, 
  pm_unread int2 DEFAULT 1::smallint NOT NULL, 
  pm_replied int2 DEFAULT 0::smallint NOT NULL, 
  pm_marked int2 DEFAULT 0::smallint NOT NULL, 
  pm_forwarded int2 DEFAULT 0::smallint NOT NULL, 
  folder_id int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_privmsgs_to_pm_forwarded_check CHECK (pm_forwarded >= 0), 
  CONSTRAINT phpbb_privmsgs_to_pm_marked_check CHECK (pm_marked >= 0), 
  CONSTRAINT phpbb_privmsgs_to_pm_replied_check CHECK (pm_replied >= 0), 
  CONSTRAINT phpbb_privmsgs_to_pm_unread_check CHECK (pm_unread >= 0), 
  CONSTRAINT phpbb_privmsgs_to_pm_new_check CHECK (pm_new >= 0), 
  CONSTRAINT phpbb_privmsgs_to_pm_deleted_check CHECK (pm_deleted >= 0), 
  CONSTRAINT phpbb_privmsgs_to_author_id_check CHECK (author_id >= 0), 
  CONSTRAINT phpbb_privmsgs_to_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_privmsgs_to_msg_id_check CHECK (msg_id >= 0)
);
CREATE INDEX phpbb_privmsgs_to_author_id ON phpbb_privmsgs_to (author_id);
CREATE INDEX phpbb_privmsgs_to_msg_id ON phpbb_privmsgs_to (msg_id);
CREATE INDEX phpbb_privmsgs_to_usr_flder_id ON phpbb_privmsgs_to (folder_id, user_id);

COPY phpbb_privmsgs_to (msg_id, user_id, author_id, pm_deleted, pm_new, pm_unread, pm_replied, pm_marked, pm_forwarded, folder_id) FROM stdin;
\.
-- Table: phpbb_extension_groups
DROP TABLE phpbb_extension_groups;
DROP SEQUENCE phpbb_extension_groups_seq;
CREATE SEQUENCE phpbb_extension_groups_seq;
CREATE TABLE phpbb_extension_groups(
  group_id int4 DEFAULT nextval('phpbb_extension_groups_seq'::regclass) NOT NULL, 
  group_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  cat_id int2 DEFAULT 0::smallint NOT NULL, 
  allow_group int2 DEFAULT 0::smallint NOT NULL, 
  download_mode int2 DEFAULT 1::smallint NOT NULL, 
  upload_icon varchar(255) DEFAULT ''::character varying NOT NULL, 
  max_filesize int4 DEFAULT 0 NOT NULL, 
  allowed_forums varchar(8000) DEFAULT ''::character varying NOT NULL, 
  allow_in_pm int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_extension_groups_pkey PRIMARY KEY (group_id), 
  CONSTRAINT phpbb_extension_groups_allow_in_pm_check CHECK (allow_in_pm >= 0), 
  CONSTRAINT phpbb_extension_groups_max_filesize_check CHECK (max_filesize >= 0), 
  CONSTRAINT phpbb_extension_groups_download_mode_check CHECK (download_mode >= 0), 
  CONSTRAINT phpbb_extension_groups_allow_group_check CHECK (allow_group >= 0), 
  CONSTRAINT phpbb_extension_groups_group_id_check CHECK (group_id >= 0)
);
COPY phpbb_extension_groups (group_id, group_name, cat_id, allow_group, download_mode, upload_icon, max_filesize, allowed_forums, allow_in_pm) FROM stdin;
1	IMAGES	1	1	1		0		0
2	ARCHIVES	0	1	1		0		0
3	PLAIN_TEXT	0	0	1		0		0
4	DOCUMENTS	0	0	1		0		0
5	REAL_MEDIA	3	0	1		0		0
6	WINDOWS_MEDIA	2	0	1		0		0
7	FLASH_FILES	5	0	1		0		0
8	QUICKTIME_MEDIA	6	0	1		0		0
9	DOWNLOADABLE_FILES	0	0	1		0		0
\.
SELECT SETVAL('phpbb_extension_groups_seq',(select case when max(group_id)>0 then max(group_id)+1 else 1 end FROM phpbb_extension_groups));
-- Table: phpbb_oauth_accounts
DROP TABLE phpbb_oauth_accounts;
CREATE TABLE phpbb_oauth_accounts(
  user_id int4 DEFAULT 0 NOT NULL, 
  provider varchar(255) DEFAULT ''::character varying NOT NULL, 
  oauth_provider_id varchar(4000) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_oauth_accounts_pkey PRIMARY KEY (provider, user_id), 
  CONSTRAINT phpbb_oauth_accounts_user_id_check CHECK (user_id >= 0)
);
COPY phpbb_oauth_accounts (user_id, provider, oauth_provider_id) FROM stdin;
\.
-- Table: phpbb_words
DROP TABLE phpbb_words;
DROP SEQUENCE phpbb_words_seq;
CREATE SEQUENCE phpbb_words_seq;
CREATE TABLE phpbb_words(
  word_id int4 DEFAULT nextval('phpbb_words_seq'::regclass) NOT NULL, 
  word varchar(255) DEFAULT ''::character varying NOT NULL, 
  replacement varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_words_pkey PRIMARY KEY (word_id), 
  CONSTRAINT phpbb_words_word_id_check CHECK (word_id >= 0)
);
COPY phpbb_words (word_id, word, replacement) FROM stdin;
\.
SELECT SETVAL('phpbb_words_seq',(select case when max(word_id)>0 then max(word_id)+1 else 1 end FROM phpbb_words));
-- Table: phpbb_profile_fields_lang
DROP TABLE phpbb_profile_fields_lang;
CREATE TABLE phpbb_profile_fields_lang(
  field_id int4 DEFAULT 0 NOT NULL, 
  lang_id int4 DEFAULT 0 NOT NULL, 
  option_id int4 DEFAULT 0 NOT NULL, 
  field_type varchar(100) DEFAULT ''::character varying NOT NULL, 
  lang_value varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_profile_fields_lang_pkey PRIMARY KEY (field_id, lang_id, option_id), 
  CONSTRAINT phpbb_profile_fields_lang_option_id_check CHECK (option_id >= 0), 
  CONSTRAINT phpbb_profile_fields_lang_lang_id_check CHECK (lang_id >= 0), 
  CONSTRAINT phpbb_profile_fields_lang_field_id_check CHECK (field_id >= 0)
);
COPY phpbb_profile_fields_lang (field_id, lang_id, option_id, field_type, lang_value) FROM stdin;
\.
-- Table: phpbb_topics_track
DROP TABLE phpbb_topics_track;
CREATE TABLE phpbb_topics_track(
  user_id int4 DEFAULT 0 NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  mark_time int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_topics_track_pkey PRIMARY KEY (topic_id, user_id), 
  CONSTRAINT phpbb_topics_track_mark_time_check CHECK (mark_time >= 0), 
  CONSTRAINT phpbb_topics_track_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_topics_track_topic_id_check CHECK (topic_id >= 0), 
  CONSTRAINT phpbb_topics_track_user_id_check CHECK (user_id >= 0)
);
CREATE INDEX phpbb_topics_track_forum_id ON phpbb_topics_track (forum_id);
CREATE INDEX phpbb_topics_track_topic_id ON phpbb_topics_track (topic_id);

COPY phpbb_topics_track (user_id, topic_id, forum_id, mark_time) FROM stdin;
\.
-- Table: phpbb_reports
DROP TABLE phpbb_reports;
DROP SEQUENCE phpbb_reports_seq;
CREATE SEQUENCE phpbb_reports_seq;
CREATE TABLE phpbb_reports(
  report_id int4 DEFAULT nextval('phpbb_reports_seq'::regclass) NOT NULL, 
  reason_id int2 DEFAULT 0::smallint NOT NULL, 
  post_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  user_notify int2 DEFAULT 0::smallint NOT NULL, 
  report_closed int2 DEFAULT 0::smallint NOT NULL, 
  report_time int4 DEFAULT 0 NOT NULL, 
  report_text text DEFAULT ''::text NOT NULL, 
  pm_id int4 DEFAULT 0 NOT NULL, 
  reported_post_enable_bbcode int2 DEFAULT 1::smallint NOT NULL, 
  reported_post_enable_smilies int2 DEFAULT 1::smallint NOT NULL, 
  reported_post_enable_magic_url int2 DEFAULT 1::smallint NOT NULL, 
  reported_post_text text DEFAULT ''::text NOT NULL, 
  reported_post_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  reported_post_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_reports_pkey PRIMARY KEY (report_id), 
  CONSTRAINT phpbb_reports_reported_post_enable_magic_url_check CHECK (reported_post_enable_magic_url >= 0), 
  CONSTRAINT phpbb_reports_reported_post_enable_smilies_check CHECK (reported_post_enable_smilies >= 0), 
  CONSTRAINT phpbb_reports_reported_post_enable_bbcode_check CHECK (reported_post_enable_bbcode >= 0), 
  CONSTRAINT phpbb_reports_pm_id_check CHECK (pm_id >= 0), 
  CONSTRAINT phpbb_reports_report_time_check CHECK (report_time >= 0), 
  CONSTRAINT phpbb_reports_report_closed_check CHECK (report_closed >= 0), 
  CONSTRAINT phpbb_reports_user_notify_check CHECK (user_notify >= 0), 
  CONSTRAINT phpbb_reports_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_reports_post_id_check CHECK (post_id >= 0), 
  CONSTRAINT phpbb_reports_reason_id_check CHECK (reason_id >= 0), 
  CONSTRAINT phpbb_reports_report_id_check CHECK (report_id >= 0)
);
CREATE INDEX phpbb_reports_pm_id ON phpbb_reports (pm_id);
CREATE INDEX phpbb_reports_post_id ON phpbb_reports (post_id);

COPY phpbb_reports (report_id, reason_id, post_id, user_id, user_notify, report_closed, report_time, report_text, pm_id, reported_post_enable_bbcode, reported_post_enable_smilies, reported_post_enable_magic_url, reported_post_text, reported_post_uid, reported_post_bitfield) FROM stdin;
\.
SELECT SETVAL('phpbb_reports_seq',(select case when max(report_id)>0 then max(report_id)+1 else 1 end FROM phpbb_reports));
-- Table: phpbb_drafts
DROP TABLE phpbb_drafts;
DROP SEQUENCE phpbb_drafts_seq;
CREATE SEQUENCE phpbb_drafts_seq;
CREATE TABLE phpbb_drafts(
  draft_id int4 DEFAULT nextval('phpbb_drafts_seq'::regclass) NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  topic_id int4 DEFAULT 0 NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  save_time int4 DEFAULT 0 NOT NULL, 
  draft_subject varchar(255) DEFAULT ''::character varying NOT NULL, 
  draft_message text DEFAULT ''::text NOT NULL, 
  CONSTRAINT phpbb_drafts_pkey PRIMARY KEY (draft_id), 
  CONSTRAINT phpbb_drafts_save_time_check CHECK (save_time >= 0), 
  CONSTRAINT phpbb_drafts_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_drafts_topic_id_check CHECK (topic_id >= 0), 
  CONSTRAINT phpbb_drafts_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_drafts_draft_id_check CHECK (draft_id >= 0)
);
CREATE INDEX phpbb_drafts_save_time ON phpbb_drafts (save_time);

COPY phpbb_drafts (draft_id, user_id, topic_id, forum_id, save_time, draft_subject, draft_message) FROM stdin;
\.
SELECT SETVAL('phpbb_drafts_seq',(select case when max(draft_id)>0 then max(draft_id)+1 else 1 end FROM phpbb_drafts));
-- Table: phpbb_modules
DROP TABLE phpbb_modules;
DROP SEQUENCE phpbb_modules_seq;
CREATE SEQUENCE phpbb_modules_seq;
CREATE TABLE phpbb_modules(
  module_id int4 DEFAULT nextval('phpbb_modules_seq'::regclass) NOT NULL, 
  module_enabled int2 DEFAULT 1::smallint NOT NULL, 
  module_display int2 DEFAULT 1::smallint NOT NULL, 
  module_basename varchar(255) DEFAULT ''::character varying NOT NULL, 
  module_class varchar(10) DEFAULT ''::character varying NOT NULL, 
  parent_id int4 DEFAULT 0 NOT NULL, 
  left_id int4 DEFAULT 0 NOT NULL, 
  right_id int4 DEFAULT 0 NOT NULL, 
  module_langname varchar(255) DEFAULT ''::character varying NOT NULL, 
  module_mode varchar(255) DEFAULT ''::character varying NOT NULL, 
  module_auth varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_modules_pkey PRIMARY KEY (module_id), 
  CONSTRAINT phpbb_modules_right_id_check CHECK (right_id >= 0), 
  CONSTRAINT phpbb_modules_left_id_check CHECK (left_id >= 0), 
  CONSTRAINT phpbb_modules_parent_id_check CHECK (parent_id >= 0), 
  CONSTRAINT phpbb_modules_module_display_check CHECK (module_display >= 0), 
  CONSTRAINT phpbb_modules_module_enabled_check CHECK (module_enabled >= 0), 
  CONSTRAINT phpbb_modules_module_id_check CHECK (module_id >= 0)
);
CREATE INDEX phpbb_modules_class_left_id ON phpbb_modules (left_id, module_class);
CREATE INDEX phpbb_modules_left_right_id ON phpbb_modules (left_id, right_id);
CREATE INDEX phpbb_modules_module_enabled ON phpbb_modules (module_enabled);

COPY phpbb_modules (module_id, module_enabled, module_display, module_basename, module_class, parent_id, left_id, right_id, module_langname, module_mode, module_auth) FROM stdin;
4	1	1		acp	1	44	51	ACP_CLIENT_COMMUNICATION		
53	1	1	acp_board	acp	4	45	46	ACP_AUTH_SETTINGS	auth	acl_a_server
54	1	1	acp_board	acp	4	47	48	ACP_EMAIL_SETTINGS	email	acl_a_server
5	1	1		acp	1	52	65	ACP_SERVER_CONFIGURATION		
55	1	1	acp_board	acp	5	53	54	ACP_COOKIE_SETTINGS	cookie	acl_a_server
56	1	1	acp_board	acp	5	55	56	ACP_SERVER_SETTINGS	server	acl_a_server
57	1	1	acp_board	acp	5	57	58	ACP_SECURITY_SETTINGS	security	acl_a_server
58	1	1	acp_board	acp	5	59	60	ACP_LOAD_SETTINGS	load	acl_a_server
7	1	1		acp	6	68	73	ACP_MANAGE_FORUMS		
1	1	1		acp	0	1	66	ACP_CAT_GENERAL		
9	1	1		acp	0	87	114	ACP_CAT_POSTING		
10	1	1		acp	9	88	101	ACP_MESSAGES		
6	1	1		acp	0	67	86	ACP_CAT_FORUMS		
8	1	1		acp	6	74	85	ACP_FORUM_BASED_PERMISSIONS		
80	1	1	acp_main	acp	1	2	3	ACP_INDEX	main	
3	1	1		acp	1	18	43	ACP_BOARD_CONFIGURATION		
33	1	1	acp_attachments	acp	3	19	20	ACP_ATTACHMENT_SETTINGS	attach	acl_a_attach
43	1	1	acp_board	acp	3	21	22	ACP_BOARD_SETTINGS	settings	acl_a_board
44	1	1	acp_board	acp	3	23	24	ACP_BOARD_FEATURES	features	acl_a_board
45	1	1	acp_board	acp	3	25	26	ACP_AVATAR_SETTINGS	avatar	acl_a_board
46	1	1	acp_board	acp	3	27	28	ACP_MESSAGE_SETTINGS	message	acl_a_board
48	1	1	acp_board	acp	3	29	30	ACP_POST_SETTINGS	post	acl_a_board
50	1	1	acp_board	acp	3	31	32	ACP_SIGNATURE_SETTINGS	signature	acl_a_board
74	1	1	acp_jabber	acp	4	49	50	ACP_JABBER_SETTINGS	settings	acl_a_jabber
114	1	1	acp_search	acp	5	61	62	ACP_SEARCH_SETTINGS	settings	acl_a_search
116	1	1	acp_send_statistics	acp	5	63	64	ACP_SEND_STATISTICS	send_statistics	acl_a_server
2	1	1		acp	1	4	17	ACP_QUICK_ACCESS		
132	1	1	acp_users	acp	2	5	6	ACP_MANAGE_USERS	overview	acl_a_user
133	1	1	acp_groups	acp	2	7	8	ACP_GROUPS_MANAGE	manage	acl_a_group
134	1	1	acp_forums	acp	2	9	10	ACP_MANAGE_FORUMS	manage	acl_a_forum
51	1	1	acp_board	acp	3	33	34	ACP_FEED_SETTINGS	feed	acl_a_board
52	1	1	acp_board	acp	3	35	36	ACP_REGISTER_SETTINGS	registration	acl_a_board
110	1	1	acp_prune	acp	7	71	72	ACP_PRUNE_FORUMS	forums	acl_a_prune
140	1	1	acp_permissions	acp	8	79	80	ACP_FORUM_MODERATORS	setting_mod_local	acl_a_mauth && (acl_a_authusers || acl_a_authgroups)
42	1	1	acp_bbcodes	acp	10	89	90	ACP_BBCODES	bbcodes	acl_a_bbcode
47	1	1	acp_board	acp	10	91	92	ACP_MESSAGE_SETTINGS	message	acl_a_board
49	1	1	acp_board	acp	10	93	94	ACP_POST_SETTINGS	post	acl_a_board
71	1	1	acp_icons	acp	10	95	96	ACP_ICONS	icons	acl_a_icons
72	1	1	acp_icons	acp	10	97	98	ACP_SMILIES	smilies	acl_a_icons
131	1	1	acp_words	acp	10	99	100	ACP_WORDS	words	acl_a_words
11	1	1		acp	9	102	113	ACP_ATTACHMENTS		
34	1	1	acp_attachments	acp	11	103	104	ACP_ATTACHMENT_SETTINGS	attach	acl_a_attach
35	1	1	acp_attachments	acp	11	105	106	ACP_MANAGE_EXTENSIONS	extensions	acl_a_attach
36	1	1	acp_attachments	acp	11	107	108	ACP_EXTENSION_GROUPS	ext_groups	acl_a_attach
37	1	1	acp_attachments	acp	11	109	110	ACP_ORPHAN_ATTACHMENTS	orphan	acl_a_attach
38	1	1	acp_attachments	acp	11	111	112	ACP_MANAGE_ATTACHMENTS	manage	acl_a_attach
12	1	1		acp	0	115	172	ACP_CAT_USERGROUP		
13	1	1		acp	12	116	151	ACP_CAT_USERS		
73	1	1	acp_inactive	acp	13	117	118	ACP_INACTIVE_USERS	list	acl_a_user
120	1	1	acp_users	acp	13	119	120	ACP_MANAGE_USERS	overview	acl_a_user
94	1	1	acp_permissions	acp	13	121	122	ACP_USERS_PERMISSIONS	setting_user_global	acl_a_authusers && (acl_a_aauth || acl_a_mauth || acl_a_uauth)
96	1	1	acp_permissions	acp	13	123	124	ACP_USERS_FORUM_PERMISSIONS	setting_user_local	acl_a_authusers && (acl_a_mauth || acl_a_fauth)
109	1	1	acp_profile	acp	13	125	126	ACP_CUSTOM_PROFILE_FIELDS	profile	acl_a_profile
111	1	1	acp_prune	acp	13	127	128	ACP_PRUNE_USERS	users	acl_a_userdel
123	1	0	acp_users	acp	13	135	136	ACP_USER_PROFILE	profile	acl_a_user
124	1	0	acp_users	acp	13	137	138	ACP_USER_PREFS	prefs	acl_a_user
135	1	1	acp_logs	acp	2	11	12	ACP_MOD_LOGS	mod	acl_a_viewlogs
136	1	1	acp_bots	acp	2	13	14	ACP_BOTS	bots	acl_a_bots
60	1	1	acp_captcha	acp	3	37	38	ACP_VC_SETTINGS	visual	acl_a_board
61	1	0	acp_captcha	acp	3	39	40	ACP_VC_CAPTCHA_DISPLAY	img	acl_a_board
62	1	1	acp_contact	acp	3	41	42	ACP_CONTACT_SETTINGS	contact	acl_a_board
68	1	1	acp_forums	acp	7	69	70	ACP_MANAGE_FORUMS	manage	acl_a_forum
137	1	1	acp_php_info	acp	2	15	16	ACP_PHP_INFO	info	acl_a_phpinfo
138	1	1	acp_permissions	acp	8	75	76	ACP_FORUM_PERMISSIONS	setting_forum_local	acl_a_fauth && (acl_a_authusers || acl_a_authgroups)
139	1	1	acp_permissions	acp	8	77	78	ACP_FORUM_PERMISSIONS_COPY	setting_forum_copy	acl_a_fauth && acl_a_authusers && acl_a_authgroups && acl_a_mauth
112	1	1	acp_ranks	acp	13	129	130	ACP_MANAGE_RANKS	ranks	acl_a_ranks
121	1	0	acp_users	acp	13	131	132	ACP_USER_FEEDBACK	feedback	acl_a_user
122	1	0	acp_users	acp	13	133	134	ACP_USER_WARNINGS	warnings	acl_a_user
129	1	0	acp_users	acp	13	147	148	ACP_USER_PERM	perm	acl_a_user && acl_a_viewauth
97	1	1	acp_permissions	acp	17	179	180	ACP_GROUPS_PERMISSIONS	setting_group_global	acl_a_authgroups && (acl_a_aauth || acl_a_mauth || acl_a_uauth)
101	1	1	acp_permissions	acp	17	181	182	ACP_ADMINISTRATORS	setting_admin_global	acl_a_aauth && (acl_a_authusers || acl_a_authgroups)
102	1	1	acp_permissions	acp	17	183	184	ACP_GLOBAL_MODERATORS	setting_mod_global	acl_a_mauth && (acl_a_authusers || acl_a_authgroups)
90	1	1	acp_permissions	acp	18	187	188	ACP_FORUM_PERMISSIONS	setting_forum_local	acl_a_fauth && (acl_a_authusers || acl_a_authgroups)
91	1	1	acp_permissions	acp	18	189	190	ACP_FORUM_PERMISSIONS_COPY	setting_forum_copy	acl_a_fauth && acl_a_authusers && acl_a_authgroups && acl_a_mauth
92	1	1	acp_permissions	acp	18	191	192	ACP_FORUM_MODERATORS	setting_mod_local	acl_a_mauth && (acl_a_authusers || acl_a_authgroups)
118	1	1	acp_styles	acp	22	231	232	ACP_STYLES_INSTALL	install	acl_a_styles
24	1	1		acp	21	234	237	ACP_LANGUAGE		
75	1	1	acp_language	acp	24	235	236	ACP_LANGUAGE_PACKS	lang_packs	acl_a_language
25	1	1		acp	0	239	258	ACP_CAT_MAINTENANCE		
26	1	1		acp	25	240	249	ACP_FORUM_LOGS		
76	1	1	acp_logs	acp	26	241	242	ACP_ADMIN_LOGS	admin	acl_a_viewlogs
77	1	1	acp_logs	acp	26	243	244	ACP_MOD_LOGS	mod	acl_a_viewlogs
78	1	1	acp_logs	acp	26	245	246	ACP_USERS_LOGS	users	acl_a_viewlogs
79	1	1	acp_logs	acp	26	247	248	ACP_CRITICAL_LOGS	critical	acl_a_viewlogs
27	1	1		acp	25	250	257	ACP_CAT_DATABASE		
63	1	1	acp_database	acp	27	251	252	ACP_BACKUP	backup	acl_a_backup
64	1	1	acp_database	acp	27	253	254	ACP_RESTORE	restore	acl_a_backup
115	1	1	acp_search	acp	27	255	256	ACP_SEARCH_INDEX	index	acl_a_search
28	1	1		acp	0	259	282	ACP_CAT_SYSTEM		
29	1	1		acp	28	260	263	ACP_AUTOMATION		
119	1	1	acp_update	acp	29	261	262	ACP_VERSION_CHECK	version_check	acl_a_board
30	1	1		acp	28	264	273	ACP_GENERAL_TASKS		
59	1	1	acp_bots	acp	30	265	266	ACP_BOTS	bots	acl_a_bots
141	1	1	acp_permissions	acp	8	81	82	ACP_USERS_FORUM_PERMISSIONS	setting_user_local	acl_a_authusers && (acl_a_mauth || acl_a_fauth)
125	1	0	acp_users	acp	13	139	140	ACP_USER_AVATAR	avatar	acl_a_user
126	1	0	acp_users	acp	13	141	142	ACP_USER_RANK	rank	acl_a_user
127	1	0	acp_users	acp	13	143	144	ACP_USER_SIG	sig	acl_a_user
128	1	0	acp_users	acp	13	145	146	ACP_USER_GROUPS	groups	acl_a_user && acl_a_group
130	1	0	acp_users	acp	13	149	150	ACP_USER_ATTACH	attach	acl_a_user
14	1	1		acp	12	152	161	ACP_GROUPS		
69	1	1	acp_groups	acp	14	153	154	ACP_GROUPS_MANAGE	manage	acl_a_group
70	1	1	acp_groups	acp	14	155	156	ACP_GROUPS_POSITION	position	acl_a_group
98	1	1	acp_permissions	acp	14	157	158	ACP_GROUPS_PERMISSIONS	setting_group_global	acl_a_authgroups && (acl_a_aauth || acl_a_mauth || acl_a_uauth)
100	1	1	acp_permissions	acp	14	159	160	ACP_GROUPS_FORUM_PERMISSIONS	setting_group_local	acl_a_authgroups && (acl_a_mauth || acl_a_fauth)
15	1	1		acp	12	162	171	ACP_USER_SECURITY		
39	1	1	acp_ban	acp	15	163	164	ACP_BAN_EMAILS	email	acl_a_ban
40	1	1	acp_ban	acp	15	165	166	ACP_BAN_IPS	ip	acl_a_ban
41	1	1	acp_ban	acp	15	167	168	ACP_BAN_USERNAMES	user	acl_a_ban
65	1	1	acp_disallow	acp	15	169	170	ACP_DISALLOW_USERNAMES	usernames	acl_a_names
16	1	1		acp	0	173	222	ACP_CAT_PERMISSIONS		
88	1	1	acp_permissions	acp	16	174	175	ACP_PERMISSIONS	intro	acl_a_authusers || acl_a_authgroups || acl_a_viewauth
17	1	1		acp	16	176	185	ACP_GLOBAL_PERMISSIONS		
93	1	1	acp_permissions	acp	17	177	178	ACP_USERS_PERMISSIONS	setting_user_global	acl_a_authusers && (acl_a_aauth || acl_a_mauth || acl_a_uauth)
18	1	1		acp	16	186	197	ACP_FORUM_BASED_PERMISSIONS		
95	1	1	acp_permissions	acp	18	193	194	ACP_USERS_FORUM_PERMISSIONS	setting_user_local	acl_a_authusers && (acl_a_mauth || acl_a_fauth)
99	1	1	acp_permissions	acp	18	195	196	ACP_GROUPS_FORUM_PERMISSIONS	setting_group_local	acl_a_authgroups && (acl_a_mauth || acl_a_fauth)
19	1	1		acp	16	198	207	ACP_PERMISSION_ROLES		
84	1	1	acp_permission_roles	acp	19	199	200	ACP_ADMIN_ROLES	admin_roles	acl_a_roles && acl_a_aauth
85	1	1	acp_permission_roles	acp	19	201	202	ACP_USER_ROLES	user_roles	acl_a_roles && acl_a_uauth
86	1	1	acp_permission_roles	acp	19	203	204	ACP_MOD_ROLES	mod_roles	acl_a_roles && acl_a_mauth
87	1	1	acp_permission_roles	acp	19	205	206	ACP_FORUM_ROLES	forum_roles	acl_a_roles && acl_a_fauth
20	1	1		acp	16	208	221	ACP_PERMISSION_MASKS		
89	1	0	acp_permissions	acp	20	209	210	ACP_PERMISSION_TRACE	trace	acl_a_viewauth
103	1	1	acp_permissions	acp	20	211	212	ACP_VIEW_ADMIN_PERMISSIONS	view_admin_global	acl_a_viewauth
104	1	1	acp_permissions	acp	20	213	214	ACP_VIEW_USER_PERMISSIONS	view_user_global	acl_a_viewauth
105	1	1	acp_permissions	acp	20	215	216	ACP_VIEW_GLOBAL_MOD_PERMISSIONS	view_mod_global	acl_a_viewauth
106	1	1	acp_permissions	acp	20	217	218	ACP_VIEW_FORUM_MOD_PERMISSIONS	view_mod_local	acl_a_viewauth
107	1	1	acp_permissions	acp	20	219	220	ACP_VIEW_FORUM_PERMISSIONS	view_forum_local	acl_a_viewauth
21	1	1		acp	0	223	238	ACP_CAT_CUSTOMISE		
23	1	1		acp	21	224	227	ACP_EXTENSION_MANAGEMENT		
67	1	1	acp_extensions	acp	23	225	226	ACP_EXTENSIONS	main	acl_a_extensions
22	1	1		acp	21	228	233	ACP_STYLE_MANAGEMENT		
117	1	1	acp_styles	acp	22	229	230	ACP_STYLES	style	acl_a_styles
66	1	1	acp_email	acp	30	267	268	ACP_MASS_EMAIL	email	acl_a_email && cfg_email_enable
108	1	1	acp_php_info	acp	30	269	270	ACP_PHP_INFO	info	acl_a_phpinfo
113	1	1	acp_reasons	acp	30	271	272	ACP_MANAGE_REASONS	main	acl_a_reasons
31	1	1		acp	28	274	281	ACP_MODULE_MANAGEMENT		
81	1	1	acp_modules	acp	31	275	276	ACP	acp	acl_a_modules
82	1	1	acp_modules	acp	31	277	278	UCP	ucp	acl_a_modules
83	1	1	acp_modules	acp	31	279	280	MCP	mcp	acl_a_modules
32	1	1		acp	0	283	284	ACP_CAT_DOT_MODS		
142	1	1	acp_permissions	acp	8	83	84	ACP_GROUPS_FORUM_PERMISSIONS	setting_group_local	acl_a_authgroups && (acl_a_mauth || acl_a_fauth)
156	1	1	mcp_main	mcp	143	2	3	MCP_MAIN_FRONT	front	
157	1	1	mcp_main	mcp	143	4	5	MCP_MAIN_FORUM_VIEW	forum_view	acl_m_,$id
158	1	1	mcp_main	mcp	143	6	7	MCP_MAIN_TOPIC_VIEW	topic_view	acl_m_,$id
143	1	1		mcp	0	1	10	MCP_MAIN		
159	1	1	mcp_main	mcp	143	8	9	MCP_MAIN_POST_DETAILS	post_details	acl_m_,$id || (!$id && aclf_m_)
144	1	1		mcp	0	11	22	MCP_QUEUE		
146	1	1		mcp	0	37	42	MCP_NOTES		
160	1	1	mcp_notes	mcp	146	38	39	MCP_NOTES_FRONT	front	
161	1	1	mcp_notes	mcp	146	40	41	MCP_NOTES_USER	user_notes	
145	1	1		mcp	0	23	36	MCP_REPORTS		
165	1	1	mcp_queue	mcp	144	12	13	MCP_QUEUE_UNAPPROVED_TOPICS	unapproved_topics	aclf_m_approve
166	1	1	mcp_queue	mcp	144	14	15	MCP_QUEUE_UNAPPROVED_POSTS	unapproved_posts	aclf_m_approve
167	1	1	mcp_queue	mcp	144	16	17	MCP_QUEUE_DELETED_TOPICS	deleted_topics	aclf_m_approve
168	1	1	mcp_queue	mcp	144	18	19	MCP_QUEUE_DELETED_POSTS	deleted_posts	aclf_m_approve
169	1	1	mcp_queue	mcp	144	20	21	MCP_QUEUE_APPROVE_DETAILS	approve_details	acl_m_approve,$id || (!$id && aclf_m_approve)
173	1	1	mcp_warn	mcp	147	44	45	MCP_WARN_FRONT	front	aclf_m_warn
174	1	1	mcp_warn	mcp	147	46	47	MCP_WARN_LIST	list	aclf_m_warn
175	1	1	mcp_warn	mcp	147	48	49	MCP_WARN_USER	warn_user	aclf_m_warn
148	1	1		mcp	0	53	60	MCP_LOGS		
153	1	1	mcp_logs	mcp	148	54	55	MCP_LOGS_FRONT	front	acl_m_ || aclf_m_
154	1	1	mcp_logs	mcp	148	56	57	MCP_LOGS_FORUM_VIEW	forum_logs	acl_m_,$id
155	1	1	mcp_logs	mcp	148	58	59	MCP_LOGS_TOPIC_VIEW	topic_logs	acl_m_,$id
149	1	1		mcp	0	61	68	MCP_BAN		
150	1	1	mcp_ban	mcp	149	62	63	MCP_BAN_USERNAMES	user	acl_m_ban
151	1	1	mcp_ban	mcp	149	64	65	MCP_BAN_IPS	ip	acl_m_ban
152	1	1	mcp_ban	mcp	149	66	67	MCP_BAN_EMAILS	email	acl_m_ban
147	1	1		mcp	0	43	52	MCP_WARN		
176	1	1	mcp_warn	mcp	147	50	51	MCP_WARN_POST	warn_post	acl_m_warn && acl_f_read,$id
164	1	1	mcp_pm_reports	mcp	145	34	35	MCP_PM_REPORT_DETAILS	pm_report_details	aclf_m_report
163	1	1	mcp_pm_reports	mcp	145	32	33	MCP_PM_REPORTS_CLOSED	pm_reports_closed	aclf_m_report
162	1	1	mcp_pm_reports	mcp	145	30	31	MCP_PM_REPORTS_OPEN	pm_reports	aclf_m_report
170	1	1	mcp_reports	mcp	145	24	25	MCP_REPORTS_OPEN	reports	aclf_m_report
171	1	1	mcp_reports	mcp	145	26	27	MCP_REPORTS_CLOSED	reports_closed	aclf_m_report
172	1	1	mcp_reports	mcp	145	28	29	MCP_REPORT_DETAILS	report_details	acl_m_report,$id || (!$id && aclf_m_report)
177	1	1		ucp	0	1	14	UCP_MAIN		
192	1	1	ucp_notifications	ucp	177	12	13	UCP_NOTIFICATION_LIST	notification_list	
179	1	1		ucp	0	29	38	UCP_PREFS		
180	1	1	ucp_pm	ucp	0	39	48	UCP_PM		
193	1	0	ucp_pm	ucp	180	40	41	UCP_PM_VIEW	view	cfg_allow_privmsg
194	1	1	ucp_pm	ucp	180	42	43	UCP_PM_COMPOSE	compose	cfg_allow_privmsg
195	1	1	ucp_pm	ucp	180	44	45	UCP_PM_DRAFTS	drafts	cfg_allow_privmsg
196	1	1	ucp_pm	ucp	180	46	47	UCP_PM_OPTIONS	options	cfg_allow_privmsg
181	1	1		ucp	0	49	54	UCP_USERGROUPS		
185	1	1	ucp_groups	ucp	181	50	51	UCP_USERGROUPS_MEMBER	membership	
178	1	1		ucp	0	15	28	UCP_PROFILE		
183	1	1	ucp_attachments	ucp	177	10	11	UCP_MAIN_ATTACHMENTS	attachments	acl_u_attach
187	1	1	ucp_main	ucp	177	2	3	UCP_MAIN_FRONT	front	
188	1	1	ucp_main	ucp	177	4	5	UCP_MAIN_SUBSCRIBED	subscribed	
189	1	1	ucp_main	ucp	177	6	7	UCP_MAIN_BOOKMARKS	bookmarks	cfg_allow_bookmarks
190	1	1	ucp_main	ucp	177	8	9	UCP_MAIN_DRAFTS	drafts	
191	1	1	ucp_notifications	ucp	179	36	37	UCP_NOTIFICATION_OPTIONS	notification_options	
197	1	1	ucp_prefs	ucp	179	30	31	UCP_PREFS_PERSONAL	personal	
198	1	1	ucp_prefs	ucp	179	32	33	UCP_PREFS_POST	post	
199	1	1	ucp_prefs	ucp	179	34	35	UCP_PREFS_VIEW	view	
184	1	1	ucp_auth_link	ucp	178	26	27	UCP_AUTH_LINK_MANAGE	auth_link	authmethod_oauth
200	1	1	ucp_profile	ucp	178	16	17	UCP_PROFILE_PROFILE_INFO	profile_info	acl_u_chgprofileinfo
186	1	1	ucp_groups	ucp	181	52	53	UCP_USERGROUPS_MANAGE	manage	
205	1	1	ucp_zebra	ucp	182	56	57	UCP_ZEBRA_FRIENDS	friends	
182	1	1		ucp	0	55	60	UCP_ZEBRA		
206	1	1	ucp_zebra	ucp	182	58	59	UCP_ZEBRA_FOES	foes	
201	1	1	ucp_profile	ucp	178	18	19	UCP_PROFILE_SIGNATURE	signature	acl_u_sig
202	1	1	ucp_profile	ucp	178	20	21	UCP_PROFILE_AVATAR	avatar	cfg_allow_avatar
203	1	1	ucp_profile	ucp	178	22	23	UCP_PROFILE_REG_DETAILS	reg_details	
204	1	1	ucp_profile	ucp	178	24	25	UCP_PROFILE_AUTOLOGIN_KEYS	autologin_keys	
\.
SELECT SETVAL('phpbb_modules_seq',(select case when max(module_id)>0 then max(module_id)+1 else 1 end FROM phpbb_modules));
-- Table: phpbb_users
DROP TABLE phpbb_users;
DROP SEQUENCE phpbb_users_seq;
CREATE SEQUENCE phpbb_users_seq;
CREATE TABLE phpbb_users(
  user_id int4 DEFAULT nextval('phpbb_users_seq'::regclass) NOT NULL, 
  user_type int2 DEFAULT 0::smallint NOT NULL, 
  group_id int4 DEFAULT 3 NOT NULL, 
  user_permissions text DEFAULT ''::text NOT NULL, 
  user_perm_from int4 DEFAULT 0 NOT NULL, 
  user_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  user_regdate int4 DEFAULT 0 NOT NULL, 
  username varchar_ci DEFAULT ''::character varying NOT NULL, 
  username_clean varchar_ci DEFAULT ''::character varying NOT NULL, 
  user_password varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_passchg int4 DEFAULT 0 NOT NULL, 
  user_email varchar(100) DEFAULT ''::character varying NOT NULL, 
  user_email_hash int8 DEFAULT 0::bigint NOT NULL, 
  user_birthday varchar(10) DEFAULT ''::character varying NOT NULL, 
  user_lastvisit int4 DEFAULT 0 NOT NULL, 
  user_lastmark int4 DEFAULT 0 NOT NULL, 
  user_lastpost_time int4 DEFAULT 0 NOT NULL, 
  user_lastpage varchar(200) DEFAULT ''::character varying NOT NULL, 
  user_last_confirm_key varchar(10) DEFAULT ''::character varying NOT NULL, 
  user_last_search int4 DEFAULT 0 NOT NULL, 
  user_warnings int2 DEFAULT 0::smallint NOT NULL, 
  user_last_warning int4 DEFAULT 0 NOT NULL, 
  user_login_attempts int2 DEFAULT 0::smallint NOT NULL, 
  user_inactive_reason int2 DEFAULT 0::smallint NOT NULL, 
  user_inactive_time int4 DEFAULT 0 NOT NULL, 
  user_posts int4 DEFAULT 0 NOT NULL, 
  user_lang varchar(30) DEFAULT ''::character varying NOT NULL, 
  user_timezone varchar(100) DEFAULT ''::character varying NOT NULL, 
  user_dateformat varchar(30) DEFAULT 'd M Y H:i'::character varying NOT NULL, 
  user_style int4 DEFAULT 0 NOT NULL, 
  user_rank int4 DEFAULT 0 NOT NULL, 
  user_colour varchar(6) DEFAULT ''::character varying NOT NULL, 
  user_new_privmsg int4 DEFAULT 0 NOT NULL, 
  user_unread_privmsg int4 DEFAULT 0 NOT NULL, 
  user_last_privmsg int4 DEFAULT 0 NOT NULL, 
  user_message_rules int2 DEFAULT 0::smallint NOT NULL, 
  user_full_folder int4 DEFAULT (-3) NOT NULL, 
  user_emailtime int4 DEFAULT 0 NOT NULL, 
  user_topic_show_days int2 DEFAULT 0::smallint NOT NULL, 
  user_topic_sortby_type varchar(1) DEFAULT 't'::character varying NOT NULL, 
  user_topic_sortby_dir varchar(1) DEFAULT 'd'::character varying NOT NULL, 
  user_post_show_days int2 DEFAULT 0::smallint NOT NULL, 
  user_post_sortby_type varchar(1) DEFAULT 't'::character varying NOT NULL, 
  user_post_sortby_dir varchar(1) DEFAULT 'a'::character varying NOT NULL, 
  user_notify int2 DEFAULT 0::smallint NOT NULL, 
  user_notify_pm int2 DEFAULT 1::smallint NOT NULL, 
  user_notify_type int2 DEFAULT 0::smallint NOT NULL, 
  user_allow_pm int2 DEFAULT 1::smallint NOT NULL, 
  user_allow_viewonline int2 DEFAULT 1::smallint NOT NULL, 
  user_allow_viewemail int2 DEFAULT 1::smallint NOT NULL, 
  user_allow_massemail int2 DEFAULT 1::smallint NOT NULL, 
  user_options int4 DEFAULT 230271 NOT NULL, 
  user_avatar varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_avatar_type varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_avatar_width int2 DEFAULT 0::smallint NOT NULL, 
  user_avatar_height int2 DEFAULT 0::smallint NOT NULL, 
  user_sig text DEFAULT ''::text NOT NULL, 
  user_sig_bbcode_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  user_sig_bbcode_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_jabber varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_actkey varchar(32) DEFAULT ''::character varying NOT NULL, 
  user_newpasswd varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_form_salt varchar(32) DEFAULT ''::character varying NOT NULL, 
  user_new int2 DEFAULT 1::smallint NOT NULL, 
  user_reminded int2 DEFAULT 0::smallint NOT NULL, 
  user_reminded_time int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_users_pkey PRIMARY KEY (user_id), 
  CONSTRAINT phpbb_users_user_reminded_time_check CHECK (user_reminded_time >= 0), 
  CONSTRAINT phpbb_users_user_new_check CHECK (user_new >= 0), 
  CONSTRAINT phpbb_users_user_avatar_height_check CHECK (user_avatar_height >= 0), 
  CONSTRAINT phpbb_users_user_avatar_width_check CHECK (user_avatar_width >= 0), 
  CONSTRAINT phpbb_users_user_options_check CHECK (user_options >= 0), 
  CONSTRAINT phpbb_users_user_allow_massemail_check CHECK (user_allow_massemail >= 0), 
  CONSTRAINT phpbb_users_user_allow_viewemail_check CHECK (user_allow_viewemail >= 0), 
  CONSTRAINT phpbb_users_user_allow_viewonline_check CHECK (user_allow_viewonline >= 0), 
  CONSTRAINT phpbb_users_user_allow_pm_check CHECK (user_allow_pm >= 0), 
  CONSTRAINT phpbb_users_user_notify_pm_check CHECK (user_notify_pm >= 0), 
  CONSTRAINT phpbb_users_user_notify_check CHECK (user_notify >= 0), 
  CONSTRAINT phpbb_users_user_post_show_days_check CHECK (user_post_show_days >= 0), 
  CONSTRAINT phpbb_users_user_topic_show_days_check CHECK (user_topic_show_days >= 0), 
  CONSTRAINT phpbb_users_user_emailtime_check CHECK (user_emailtime >= 0), 
  CONSTRAINT phpbb_users_user_message_rules_check CHECK (user_message_rules >= 0), 
  CONSTRAINT phpbb_users_user_last_privmsg_check CHECK (user_last_privmsg >= 0), 
  CONSTRAINT phpbb_users_user_rank_check CHECK (user_rank >= 0), 
  CONSTRAINT phpbb_users_user_style_check CHECK (user_style >= 0), 
  CONSTRAINT phpbb_users_user_posts_check CHECK (user_posts >= 0), 
  CONSTRAINT phpbb_users_user_inactive_time_check CHECK (user_inactive_time >= 0), 
  CONSTRAINT phpbb_users_user_last_warning_check CHECK (user_last_warning >= 0), 
  CONSTRAINT phpbb_users_user_last_search_check CHECK (user_last_search >= 0), 
  CONSTRAINT phpbb_users_user_lastpost_time_check CHECK (user_lastpost_time >= 0), 
  CONSTRAINT phpbb_users_user_lastmark_check CHECK (user_lastmark >= 0), 
  CONSTRAINT phpbb_users_user_lastvisit_check CHECK (user_lastvisit >= 0), 
  CONSTRAINT phpbb_users_user_passchg_check CHECK (user_passchg >= 0), 
  CONSTRAINT phpbb_users_user_regdate_check CHECK (user_regdate >= 0), 
  CONSTRAINT phpbb_users_user_perm_from_check CHECK (user_perm_from >= 0), 
  CONSTRAINT phpbb_users_group_id_check CHECK (group_id >= 0), 
  CONSTRAINT phpbb_users_user_id_check CHECK (user_id >= 0)
);
CREATE INDEX phpbb_users_user_birthday ON phpbb_users (user_birthday);
CREATE INDEX phpbb_users_user_email_hash ON phpbb_users (user_email_hash);
CREATE INDEX phpbb_users_user_type ON phpbb_users (user_type);
CREATE UNIQUE INDEX phpbb_users_username_clean ON phpbb_users (username_clean);

COPY phpbb_users (user_id, user_type, group_id, user_permissions, user_perm_from, user_ip, user_regdate, username, username_clean, user_password, user_passchg, user_email, user_email_hash, user_birthday, user_lastvisit, user_lastmark, user_lastpost_time, user_lastpage, user_last_confirm_key, user_last_search, user_warnings, user_last_warning, user_login_attempts, user_inactive_reason, user_inactive_time, user_posts, user_lang, user_timezone, user_dateformat, user_style, user_rank, user_colour, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_message_rules, user_full_folder, user_emailtime, user_topic_show_days, user_topic_sortby_type, user_topic_sortby_dir, user_post_show_days, user_post_sortby_type, user_post_sortby_dir, user_notify, user_notify_pm, user_notify_type, user_allow_pm, user_allow_viewonline, user_allow_viewemail, user_allow_massemail, user_options, user_avatar, user_avatar_type, user_avatar_width, user_avatar_height, user_sig, user_sig_bbcode_uid, user_sig_bbcode_bitfield, user_jabber, user_actkey, user_newpasswd, user_form_salt, user_new, user_reminded, user_reminded_time) FROM stdin;
9	2	6		0		1414661778	Exabot [Bot]	exabot [bot]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							00ca38529d02c79f	0	0	0
10	2	6		0		1414661778	FAST Enterprise [Crawler]	fast enterprise [crawler]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							152baada2c87e3f8	0	0	0
11	2	6		0		1414661778	FAST WebCrawler [Crawler]	fast webcrawler [crawler]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							2d6422dc61511d5f	0	0	0
12	2	6		0		1414661778	Francis [Bot]	francis [bot]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							1b47d3421961f090	0	0	0
27	2	6		0		1414661780	MSNbot Media	msnbot media		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							1e961a12440ce10b	0	0	0
3	2	6		0		1414661777	AdsBot [Google]	adsbot [google]		1414661777		0		0	1414661777	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							3804dc692e4237a1	0	0	0
4	2	6		0		1414661777	Alexa [Bot]	alexa [bot]		1414661777		0		0	1414661777	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							f152bd8c266e5f57	0	0	0
5	2	6		0		1414661778	Alta Vista [Bot]	alta vista [bot]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							3ce6fa3030b1a8f0	0	0	0
6	2	6		0		1414661778	Ask Jeeves [Bot]	ask jeeves [bot]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							6487d6e10308d8fb	0	0	0
7	2	6		0		1414661778	Baidu [Spider]	baidu [spider]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							bd8900371165ec1c	0	0	0
8	2	6		0		1414661778	Bing [Bot]	bing [bot]		1414661778		0		0	1414661778	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							0ab0c51e833ce52b	0	0	0
13	2	6		0		1414661779	Gigabot [Bot]	gigabot [bot]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							53f5b6ac4fdccb74	0	0	0
14	2	6		0		1414661779	Google Adsense [Bot]	google adsense [bot]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							00269ad8c070c953	0	0	0
15	2	6		0		1414661779	Google Desktop	google desktop		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							8356fca98e4d9902	0	0	0
16	2	6		0		1414661779	Google Feedfetcher	google feedfetcher		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							7b9c601649664db2	0	0	0
17	2	6		0		1414661779	Google [Bot]	google [bot]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							60d532ea41ae416d	0	0	0
18	2	6		0		1414661779	Heise IT-Markt [Crawler]	heise it-markt [crawler]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							f87b4b184bec1890	0	0	0
19	2	6		0		1414661779	Heritrix [Crawler]	heritrix [crawler]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							9a8ad69775631e75	0	0	0
20	2	6		0		1414661779	IBM Research [Bot]	ibm research [bot]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							639d1fb399630c52	0	0	0
21	2	6		0		1414661779	ICCrawler - ICjobs	iccrawler - icjobs		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							8b143540e037c610	0	0	0
22	2	6		0		1414661779	ichiro [Crawler]	ichiro [crawler]		1414661779		0		0	1414661779	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							e89437c261e79853	0	0	0
23	2	6		0		1414661780	Majestic-12 [Bot]	majestic-12 [bot]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							f8f5d869e89bffae	0	0	0
24	2	6		0		1414661780	Metager [Bot]	metager [bot]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							78e4ded8974f59a0	0	0	0
25	2	6		0		1414661780	MSN NewsBlogs	msn newsblogs		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							156352ecd6859e23	0	0	0
26	2	6		0		1414661780	MSN [Bot]	msn [bot]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							417d937ad8e72d01	0	0	0
28	2	6		0		1414661780	Nutch [Bot]	nutch [bot]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							f5ca1145bdc17772	0	0	0
29	2	6		0		1414661780	Online link [Validator]	online link [validator]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							95705b97d989061f	0	0	0
30	2	6		0		1414661780	psbot [Picsearch]	psbot [picsearch]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							f7b83cc3f3c0406e	0	0	0
31	2	6		0		1414661780	Sensis [Crawler]	sensis [crawler]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							1a6a58af146b1141	0	0	0
32	2	6		0		1414661780	SEO Crawler	seo crawler		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							7721bf696531abbe	0	0	0
33	2	6		0		1414661780	Seoma [Crawler]	seoma [crawler]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							1c39c5833ce7a6d9	0	0	0
34	2	6		0		1414661780	SEOSearch [Crawler]	seosearch [crawler]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							4c8bf8f22754e8be	0	0	0
35	2	6		0		1414661780	Snappy [Bot]	snappy [bot]		1414661780		0		0	1414661780	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							f85dd2d3079daefc	0	0	0
36	2	6		0		1414661781	Steeler [Crawler]	steeler [crawler]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							1c0a2db60efe668c	0	0	0
37	2	6		0		1414661781	Telekom [Bot]	telekom [bot]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							60a0791e2f52f64f	0	0	0
38	2	6		0		1414661781	TurnitinBot [Bot]	turnitinbot [bot]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							6102af572782f738	0	0	0
39	2	6		0		1414661781	Voyager [Bot]	voyager [bot]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							67fda3f959832fca	0	0	0
40	2	6		0		1414661781	W3 [Sitesearch]	w3 [sitesearch]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							d84c79ddeff2eb31	0	0	0
41	2	6		0		1414661781	W3C [Linkcheck]	w3c [linkcheck]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							637f26c59ff0e0a4	0	0	0
42	2	6		0		1414661781	W3C [Validator]	w3c [validator]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							e7c85baeb5c7cd6e	0	0	0
43	2	6		0		1414661781	YaCy [Bot]	yacy [bot]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							8160d9dc061bcc53	0	0	0
44	2	6		0		1414661781	Yahoo MMCrawler [Bot]	yahoo mmcrawler [bot]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							21544d6285ec6eab	0	0	0
45	2	6		0		1414661781	Yahoo Slurp [Bot]	yahoo slurp [bot]		1414661781		0		0	1414661781	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							804bd8bee8884785	0	0	0
46	2	6		0		1414661782	Yahoo [Bot]	yahoo [bot]		1414661782		0		0	1414661782	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							dbac033aab186ac4	0	0	0
47	2	6		0		1414661782	YahooSeeker [Bot]	yahooseeker [bot]		1414661782		0		0	1414661782	0			0	0	0	0	0	0	0	en	UTC	D M d, Y g:i a	1	0	9E8DA7	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	0	1	1	0	230271			0	0							fce5b5b5c87ecf1e	0	0	0
1	2	1	00000000000w27wrgg\ni1cjyo000000\ni1cjyo000000	0		1414661761	Anonymous	anonymous		0		0		0	0	0			0	0	0	0	0	0	0	en		d M Y H:i	1	0		0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	1	1	1	0	230271			0	0							9d316916eb4d5186	1	0	0
2	3	5	zik0zjzik0zjzik0zc\ni1cjyo000000\nzik0zjzi8sg0	0	59.125.15.165	1414661761	myleftstudio	myleftstudio	$2y$10$lL8dhlPPU00g4ehmY3IM6.7N06JyLqMDmzIFwY2t78ntTos9Dt4.i	0	dreamsxin@qq.com	400698557016		0	0	0			0	0	0	0	0	0	1	en		D M d, Y g:i a	1	1	AA0000	0	0	0	0	-3	0	0	t	d	0	t	a	0	1	0	1	1	1	1	230271			0	0							2e4c37d6a2b3e2f2	1	0	0
\.
SELECT SETVAL('phpbb_users_seq',(select case when max(user_id)>0 then max(user_id)+1 else 1 end FROM phpbb_users));
-- Table: phpbb_notification_types
DROP TABLE phpbb_notification_types;
DROP SEQUENCE phpbb_notification_types_seq;
CREATE SEQUENCE phpbb_notification_types_seq;
CREATE TABLE phpbb_notification_types(
  notification_type_id int2 DEFAULT nextval('phpbb_notification_types_seq'::regclass) NOT NULL, 
  notification_type_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  notification_type_enabled int2 DEFAULT 1::smallint NOT NULL, 
  CONSTRAINT phpbb_notification_types_pkey PRIMARY KEY (notification_type_id), 
  CONSTRAINT phpbb_notification_types_notification_type_enabled_check CHECK (notification_type_enabled >= 0), 
  CONSTRAINT phpbb_notification_types_notification_type_id_check CHECK (notification_type_id >= 0)
);
CREATE UNIQUE INDEX phpbb_notification_types_type ON phpbb_notification_types (notification_type_name);

COPY phpbb_notification_types (notification_type_id, notification_type_name, notification_type_enabled) FROM stdin;
\.
SELECT SETVAL('phpbb_notification_types_seq',(select case when max(notification_type_id)>0 then max(notification_type_id)+1 else 1 end FROM phpbb_notification_types));
-- Table: phpbb_sitelist
DROP TABLE phpbb_sitelist;
DROP SEQUENCE phpbb_sitelist_seq;
CREATE SEQUENCE phpbb_sitelist_seq;
CREATE TABLE phpbb_sitelist(
  site_id int4 DEFAULT nextval('phpbb_sitelist_seq'::regclass) NOT NULL, 
  site_ip varchar(40) DEFAULT ''::character varying NOT NULL, 
  site_hostname varchar(255) DEFAULT ''::character varying NOT NULL, 
  ip_exclude int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_sitelist_pkey PRIMARY KEY (site_id), 
  CONSTRAINT phpbb_sitelist_ip_exclude_check CHECK (ip_exclude >= 0), 
  CONSTRAINT phpbb_sitelist_site_id_check CHECK (site_id >= 0)
);
COPY phpbb_sitelist (site_id, site_ip, site_hostname, ip_exclude) FROM stdin;
\.
SELECT SETVAL('phpbb_sitelist_seq',(select case when max(site_id)>0 then max(site_id)+1 else 1 end FROM phpbb_sitelist));
-- Table: phpbb_forums_watch
DROP TABLE phpbb_forums_watch;
CREATE TABLE phpbb_forums_watch(
  forum_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  notify_status int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_forums_watch_notify_status_check CHECK (notify_status >= 0), 
  CONSTRAINT phpbb_forums_watch_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_forums_watch_forum_id_check CHECK (forum_id >= 0)
);
CREATE INDEX phpbb_forums_watch_forum_id ON phpbb_forums_watch (forum_id);
CREATE INDEX phpbb_forums_watch_notify_stat ON phpbb_forums_watch (notify_status);
CREATE INDEX phpbb_forums_watch_user_id ON phpbb_forums_watch (user_id);

COPY phpbb_forums_watch (forum_id, user_id, notify_status) FROM stdin;
\.
-- Table: phpbb_privmsgs_rules
DROP TABLE phpbb_privmsgs_rules;
DROP SEQUENCE phpbb_privmsgs_rules_seq;
CREATE SEQUENCE phpbb_privmsgs_rules_seq;
CREATE TABLE phpbb_privmsgs_rules(
  rule_id int4 DEFAULT nextval('phpbb_privmsgs_rules_seq'::regclass) NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  rule_check int4 DEFAULT 0 NOT NULL, 
  rule_connection int4 DEFAULT 0 NOT NULL, 
  rule_string varchar(255) DEFAULT ''::character varying NOT NULL, 
  rule_user_id int4 DEFAULT 0 NOT NULL, 
  rule_group_id int4 DEFAULT 0 NOT NULL, 
  rule_action int4 DEFAULT 0 NOT NULL, 
  rule_folder_id int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_privmsgs_rules_pkey PRIMARY KEY (rule_id), 
  CONSTRAINT phpbb_privmsgs_rules_rule_action_check CHECK (rule_action >= 0), 
  CONSTRAINT phpbb_privmsgs_rules_rule_group_id_check CHECK (rule_group_id >= 0), 
  CONSTRAINT phpbb_privmsgs_rules_rule_user_id_check CHECK (rule_user_id >= 0), 
  CONSTRAINT phpbb_privmsgs_rules_rule_connection_check CHECK (rule_connection >= 0), 
  CONSTRAINT phpbb_privmsgs_rules_rule_check_check CHECK (rule_check >= 0), 
  CONSTRAINT phpbb_privmsgs_rules_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_privmsgs_rules_rule_id_check CHECK (rule_id >= 0)
);
CREATE INDEX phpbb_privmsgs_rules_user_id ON phpbb_privmsgs_rules (user_id);

COPY phpbb_privmsgs_rules (rule_id, user_id, rule_check, rule_connection, rule_string, rule_user_id, rule_group_id, rule_action, rule_folder_id) FROM stdin;
\.
SELECT SETVAL('phpbb_privmsgs_rules_seq',(select case when max(rule_id)>0 then max(rule_id)+1 else 1 end FROM phpbb_privmsgs_rules));
-- Table: phpbb_teampage
DROP TABLE phpbb_teampage;
DROP SEQUENCE phpbb_teampage_seq;
CREATE SEQUENCE phpbb_teampage_seq;
CREATE TABLE phpbb_teampage(
  teampage_id int4 DEFAULT nextval('phpbb_teampage_seq'::regclass) NOT NULL, 
  group_id int4 DEFAULT 0 NOT NULL, 
  teampage_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  teampage_position int4 DEFAULT 0 NOT NULL, 
  teampage_parent int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_teampage_pkey PRIMARY KEY (teampage_id), 
  CONSTRAINT phpbb_teampage_teampage_parent_check CHECK (teampage_parent >= 0), 
  CONSTRAINT phpbb_teampage_teampage_position_check CHECK (teampage_position >= 0), 
  CONSTRAINT phpbb_teampage_group_id_check CHECK (group_id >= 0), 
  CONSTRAINT phpbb_teampage_teampage_id_check CHECK (teampage_id >= 0)
);
COPY phpbb_teampage (teampage_id, group_id, teampage_name, teampage_position, teampage_parent) FROM stdin;
1	5		1	0
2	4		2	0
\.
SELECT SETVAL('phpbb_teampage_seq',(select case when max(teampage_id)>0 then max(teampage_id)+1 else 1 end FROM phpbb_teampage));
-- Table: phpbb_extensions
DROP TABLE phpbb_extensions;
DROP SEQUENCE phpbb_extensions_seq;
CREATE SEQUENCE phpbb_extensions_seq;
CREATE TABLE phpbb_extensions(
  extension_id int4 DEFAULT nextval('phpbb_extensions_seq'::regclass) NOT NULL, 
  group_id int4 DEFAULT 0 NOT NULL, 
  extension varchar(100) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_extensions_pkey PRIMARY KEY (extension_id), 
  CONSTRAINT phpbb_extensions_group_id_check CHECK (group_id >= 0), 
  CONSTRAINT phpbb_extensions_extension_id_check CHECK (extension_id >= 0)
);
COPY phpbb_extensions (extension_id, group_id, extension) FROM stdin;
1	1	gif
2	1	png
3	1	jpeg
4	1	jpg
5	1	tif
6	1	tiff
7	1	tga
8	2	gtar
9	2	gz
10	2	tar
11	2	zip
12	2	rar
13	2	ace
14	2	torrent
15	2	tgz
16	2	bz2
17	2	7z
18	3	txt
19	3	c
20	3	h
21	3	cpp
22	3	hpp
23	3	diz
24	3	csv
25	3	ini
26	3	log
27	3	js
28	3	xml
29	4	xls
30	4	xlsx
31	4	xlsm
32	4	xlsb
33	4	doc
34	4	docx
35	4	docm
36	4	dot
37	4	dotx
38	4	dotm
39	4	pdf
40	4	ai
41	4	ps
42	4	ppt
43	4	pptx
44	4	pptm
45	4	odg
46	4	odp
47	4	ods
48	4	odt
49	4	rtf
50	5	rm
51	5	ram
52	6	wma
53	6	wmv
54	7	swf
55	8	mov
56	8	m4v
57	8	m4a
58	8	mp4
59	8	3gp
60	8	3g2
61	8	qt
62	9	mpeg
63	9	mpg
64	9	mp3
65	9	ogg
66	9	ogm
\.
SELECT SETVAL('phpbb_extensions_seq',(select case when max(extension_id)>0 then max(extension_id)+1 else 1 end FROM phpbb_extensions));
-- Table: phpbb_user_notifications
DROP TABLE phpbb_user_notifications;
CREATE TABLE phpbb_user_notifications(
  item_type varchar(255) DEFAULT ''::character varying NOT NULL, 
  item_id int4 DEFAULT 0 NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  method varchar(255) DEFAULT ''::character varying NOT NULL, 
  notify int2 DEFAULT 1::smallint NOT NULL, 
  CONSTRAINT phpbb_user_notifications_notify_check CHECK (notify >= 0), 
  CONSTRAINT phpbb_user_notifications_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_user_notifications_item_id_check CHECK (item_id >= 0)
);
COPY phpbb_user_notifications (item_type, item_id, user_id, method, notify) FROM stdin;
notification.type.post	0	2		1
notification.type.post	0	2	notification.method.email	1
notification.type.topic	0	2		1
notification.type.topic	0	2	notification.method.email	1
notification.type.post	0	3		1
notification.type.post	0	3	notification.method.email	1
notification.type.topic	0	3		1
notification.type.topic	0	3	notification.method.email	1
notification.type.post	0	4		1
notification.type.post	0	4	notification.method.email	1
notification.type.topic	0	4		1
notification.type.topic	0	4	notification.method.email	1
notification.type.post	0	5		1
notification.type.post	0	5	notification.method.email	1
notification.type.topic	0	5		1
notification.type.topic	0	5	notification.method.email	1
notification.type.post	0	6		1
notification.type.post	0	6	notification.method.email	1
notification.type.topic	0	6		1
notification.type.topic	0	6	notification.method.email	1
notification.type.post	0	7		1
notification.type.post	0	7	notification.method.email	1
notification.type.topic	0	7		1
notification.type.topic	0	7	notification.method.email	1
notification.type.post	0	8		1
notification.type.post	0	8	notification.method.email	1
notification.type.topic	0	8		1
notification.type.topic	0	8	notification.method.email	1
notification.type.post	0	9		1
notification.type.post	0	9	notification.method.email	1
notification.type.topic	0	9		1
notification.type.topic	0	9	notification.method.email	1
notification.type.post	0	10		1
notification.type.post	0	10	notification.method.email	1
notification.type.topic	0	10		1
notification.type.topic	0	10	notification.method.email	1
notification.type.post	0	11		1
notification.type.post	0	11	notification.method.email	1
notification.type.topic	0	11		1
notification.type.topic	0	11	notification.method.email	1
notification.type.post	0	12		1
notification.type.post	0	12	notification.method.email	1
notification.type.topic	0	12		1
notification.type.topic	0	12	notification.method.email	1
notification.type.post	0	13		1
notification.type.post	0	13	notification.method.email	1
notification.type.topic	0	13		1
notification.type.topic	0	13	notification.method.email	1
notification.type.post	0	14		1
notification.type.post	0	14	notification.method.email	1
notification.type.topic	0	14		1
notification.type.topic	0	14	notification.method.email	1
notification.type.post	0	15		1
notification.type.post	0	15	notification.method.email	1
notification.type.topic	0	15		1
notification.type.topic	0	15	notification.method.email	1
notification.type.post	0	16		1
notification.type.post	0	16	notification.method.email	1
notification.type.topic	0	16		1
notification.type.topic	0	16	notification.method.email	1
notification.type.post	0	17		1
notification.type.post	0	17	notification.method.email	1
notification.type.topic	0	17		1
notification.type.topic	0	17	notification.method.email	1
notification.type.post	0	18		1
notification.type.post	0	18	notification.method.email	1
notification.type.topic	0	18		1
notification.type.topic	0	18	notification.method.email	1
notification.type.post	0	19		1
notification.type.post	0	19	notification.method.email	1
notification.type.topic	0	19		1
notification.type.topic	0	19	notification.method.email	1
notification.type.post	0	20		1
notification.type.post	0	20	notification.method.email	1
notification.type.topic	0	20		1
notification.type.topic	0	20	notification.method.email	1
notification.type.post	0	21		1
notification.type.post	0	21	notification.method.email	1
notification.type.topic	0	21		1
notification.type.topic	0	21	notification.method.email	1
notification.type.post	0	22		1
notification.type.post	0	22	notification.method.email	1
notification.type.topic	0	22		1
notification.type.topic	0	22	notification.method.email	1
notification.type.post	0	23		1
notification.type.post	0	23	notification.method.email	1
notification.type.topic	0	23		1
notification.type.topic	0	23	notification.method.email	1
notification.type.post	0	24		1
notification.type.post	0	24	notification.method.email	1
notification.type.topic	0	24		1
notification.type.topic	0	24	notification.method.email	1
notification.type.post	0	25		1
notification.type.post	0	25	notification.method.email	1
notification.type.topic	0	25		1
notification.type.topic	0	25	notification.method.email	1
notification.type.post	0	26		1
notification.type.post	0	26	notification.method.email	1
notification.type.topic	0	26		1
notification.type.topic	0	26	notification.method.email	1
notification.type.post	0	27		1
notification.type.post	0	27	notification.method.email	1
notification.type.topic	0	27		1
notification.type.topic	0	27	notification.method.email	1
notification.type.post	0	28		1
notification.type.post	0	28	notification.method.email	1
notification.type.topic	0	28		1
notification.type.topic	0	28	notification.method.email	1
notification.type.post	0	29		1
notification.type.post	0	29	notification.method.email	1
notification.type.topic	0	29		1
notification.type.topic	0	29	notification.method.email	1
notification.type.post	0	30		1
notification.type.post	0	30	notification.method.email	1
notification.type.topic	0	30		1
notification.type.topic	0	30	notification.method.email	1
notification.type.post	0	31		1
notification.type.post	0	31	notification.method.email	1
notification.type.topic	0	31		1
notification.type.topic	0	31	notification.method.email	1
notification.type.post	0	32		1
notification.type.post	0	32	notification.method.email	1
notification.type.topic	0	32		1
notification.type.topic	0	32	notification.method.email	1
notification.type.post	0	33		1
notification.type.post	0	33	notification.method.email	1
notification.type.topic	0	33		1
notification.type.topic	0	33	notification.method.email	1
notification.type.post	0	34		1
notification.type.post	0	34	notification.method.email	1
notification.type.topic	0	34		1
notification.type.topic	0	34	notification.method.email	1
notification.type.post	0	35		1
notification.type.post	0	35	notification.method.email	1
notification.type.topic	0	35		1
notification.type.topic	0	35	notification.method.email	1
notification.type.post	0	36		1
notification.type.post	0	36	notification.method.email	1
notification.type.topic	0	36		1
notification.type.topic	0	36	notification.method.email	1
notification.type.post	0	37		1
notification.type.post	0	37	notification.method.email	1
notification.type.topic	0	37		1
notification.type.topic	0	37	notification.method.email	1
notification.type.post	0	38		1
notification.type.post	0	38	notification.method.email	1
notification.type.topic	0	38		1
notification.type.topic	0	38	notification.method.email	1
notification.type.post	0	39		1
notification.type.post	0	39	notification.method.email	1
notification.type.topic	0	39		1
notification.type.topic	0	39	notification.method.email	1
notification.type.post	0	40		1
notification.type.post	0	40	notification.method.email	1
notification.type.topic	0	40		1
notification.type.topic	0	40	notification.method.email	1
notification.type.post	0	41		1
notification.type.post	0	41	notification.method.email	1
notification.type.topic	0	41		1
notification.type.topic	0	41	notification.method.email	1
notification.type.post	0	42		1
notification.type.post	0	42	notification.method.email	1
notification.type.topic	0	42		1
notification.type.topic	0	42	notification.method.email	1
notification.type.post	0	43		1
notification.type.post	0	43	notification.method.email	1
notification.type.topic	0	43		1
notification.type.topic	0	43	notification.method.email	1
notification.type.post	0	44		1
notification.type.post	0	44	notification.method.email	1
notification.type.topic	0	44		1
notification.type.topic	0	44	notification.method.email	1
notification.type.post	0	45		1
notification.type.post	0	45	notification.method.email	1
notification.type.topic	0	45		1
notification.type.topic	0	45	notification.method.email	1
notification.type.post	0	46		1
notification.type.post	0	46	notification.method.email	1
notification.type.topic	0	46		1
notification.type.topic	0	46	notification.method.email	1
notification.type.post	0	47		1
notification.type.post	0	47	notification.method.email	1
notification.type.topic	0	47		1
notification.type.topic	0	47	notification.method.email	1
\.
-- Table: phpbb_bbcodes
DROP TABLE phpbb_bbcodes;
CREATE TABLE phpbb_bbcodes(
  bbcode_id int2 DEFAULT 0::smallint NOT NULL, 
  bbcode_tag varchar(16) DEFAULT ''::character varying NOT NULL, 
  bbcode_helpline varchar(255) DEFAULT ''::character varying NOT NULL, 
  display_on_posting int2 DEFAULT 0::smallint NOT NULL, 
  bbcode_match varchar(4000) DEFAULT ''::character varying NOT NULL, 
  bbcode_tpl text DEFAULT ''::text NOT NULL, 
  first_pass_match text DEFAULT ''::text NOT NULL, 
  first_pass_replace text DEFAULT ''::text NOT NULL, 
  second_pass_match text DEFAULT ''::text NOT NULL, 
  second_pass_replace text DEFAULT ''::text NOT NULL, 
  CONSTRAINT phpbb_bbcodes_pkey PRIMARY KEY (bbcode_id), 
  CONSTRAINT phpbb_bbcodes_display_on_posting_check CHECK (display_on_posting >= 0), 
  CONSTRAINT phpbb_bbcodes_bbcode_id_check CHECK (bbcode_id >= 0)
);
CREATE INDEX phpbb_bbcodes_display_on_post ON phpbb_bbcodes (display_on_posting);

COPY phpbb_bbcodes (bbcode_id, bbcode_tag, bbcode_helpline, display_on_posting, bbcode_match, bbcode_tpl, first_pass_match, first_pass_replace, second_pass_match, second_pass_replace) FROM stdin;
\.
-- Table: phpbb_bots
DROP TABLE phpbb_bots;
DROP SEQUENCE phpbb_bots_seq;
CREATE SEQUENCE phpbb_bots_seq;
CREATE TABLE phpbb_bots(
  bot_id int4 DEFAULT nextval('phpbb_bots_seq'::regclass) NOT NULL, 
  bot_active int2 DEFAULT 1::smallint NOT NULL, 
  bot_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  user_id int4 DEFAULT 0 NOT NULL, 
  bot_agent varchar(255) DEFAULT ''::character varying NOT NULL, 
  bot_ip varchar(255) DEFAULT ''::character varying NOT NULL, 
  CONSTRAINT phpbb_bots_pkey PRIMARY KEY (bot_id), 
  CONSTRAINT phpbb_bots_user_id_check CHECK (user_id >= 0), 
  CONSTRAINT phpbb_bots_bot_active_check CHECK (bot_active >= 0), 
  CONSTRAINT phpbb_bots_bot_id_check CHECK (bot_id >= 0)
);
CREATE INDEX phpbb_bots_bot_active ON phpbb_bots (bot_active);

COPY phpbb_bots (bot_id, bot_active, bot_name, user_id, bot_agent, bot_ip) FROM stdin;
1	1	AdsBot [Google]	3	AdsBot-Google	
2	1	Alexa [Bot]	4	ia_archiver	
3	1	Alta Vista [Bot]	5	Scooter/	
4	1	Ask Jeeves [Bot]	6	Ask Jeeves	
5	1	Baidu [Spider]	7	Baiduspider	
6	1	Bing [Bot]	8	bingbot/	
7	1	Exabot [Bot]	9	Exabot	
8	1	FAST Enterprise [Crawler]	10	FAST Enterprise Crawler	
9	1	FAST WebCrawler [Crawler]	11	FAST-WebCrawler/	
10	1	Francis [Bot]	12	http://www.neomo.de/	
11	1	Gigabot [Bot]	13	Gigabot/	
12	1	Google Adsense [Bot]	14	Mediapartners-Google	
13	1	Google Desktop	15	Google Desktop	
14	1	Google Feedfetcher	16	Feedfetcher-Google	
15	1	Google [Bot]	17	Googlebot	
16	1	Heise IT-Markt [Crawler]	18	heise-IT-Markt-Crawler	
17	1	Heritrix [Crawler]	19	heritrix/1.	
18	1	IBM Research [Bot]	20	ibm.com/cs/crawler	
19	1	ICCrawler - ICjobs	21	ICCrawler - ICjobs	
20	1	ichiro [Crawler]	22	ichiro/	
21	1	Majestic-12 [Bot]	23	MJ12bot/	
22	1	Metager [Bot]	24	MetagerBot/	
23	1	MSN NewsBlogs	25	msnbot-NewsBlogs/	
24	1	MSN [Bot]	26	msnbot/	
25	1	MSNbot Media	27	msnbot-media/	
26	1	Nutch [Bot]	28	http://lucene.apache.org/nutch/	
27	1	Online link [Validator]	29	online link validator	
28	1	psbot [Picsearch]	30	psbot/0	
29	1	Sensis [Crawler]	31	Sensis Web Crawler	
30	1	SEO Crawler	32	SEO search Crawler/	
31	1	Seoma [Crawler]	33	Seoma [SEO Crawler]	
32	1	SEOSearch [Crawler]	34	SEOsearch/	
33	1	Snappy [Bot]	35	Snappy/1.1 ( http://www.urltrends.com/ )	
34	1	Steeler [Crawler]	36	http://www.tkl.iis.u-tokyo.ac.jp/~crawler/	
35	1	Telekom [Bot]	37	crawleradmin.t-info@telekom.de	
36	1	TurnitinBot [Bot]	38	TurnitinBot/	
37	1	Voyager [Bot]	39	voyager/	
38	1	W3 [Sitesearch]	40	W3 SiteSearch Crawler	
39	1	W3C [Linkcheck]	41	W3C-checklink/	
40	1	W3C [Validator]	42	W3C_Validator	
41	1	YaCy [Bot]	43	yacybot	
42	1	Yahoo MMCrawler [Bot]	44	Yahoo-MMCrawler/	
43	1	Yahoo Slurp [Bot]	45	Yahoo! DE Slurp	
44	1	Yahoo [Bot]	46	Yahoo! Slurp	
45	1	YahooSeeker [Bot]	47	YahooSeeker/	
\.
SELECT SETVAL('phpbb_bots_seq',(select case when max(bot_id)>0 then max(bot_id)+1 else 1 end FROM phpbb_bots));
-- Table: phpbb_migrations
DROP TABLE phpbb_migrations;
CREATE TABLE phpbb_migrations(
  migration_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  migration_depends_on varchar(8000) DEFAULT ''::character varying NOT NULL, 
  migration_schema_done int2 DEFAULT 0::smallint NOT NULL, 
  migration_data_done int2 DEFAULT 0::smallint NOT NULL, 
  migration_data_state varchar(8000) DEFAULT ''::character varying NOT NULL, 
  migration_start_time int4 DEFAULT 0 NOT NULL, 
  migration_end_time int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_migrations_pkey PRIMARY KEY (migration_name), 
  CONSTRAINT phpbb_migrations_migration_end_time_check CHECK (migration_end_time >= 0), 
  CONSTRAINT phpbb_migrations_migration_start_time_check CHECK (migration_start_time >= 0), 
  CONSTRAINT phpbb_migrations_migration_data_done_check CHECK (migration_data_done >= 0), 
  CONSTRAINT phpbb_migrations_migration_schema_done_check CHECK (migration_schema_done >= 0)
);
COPY phpbb_migrations (migration_name, migration_depends_on, migration_schema_done, migration_data_done, migration_data_state, migration_start_time, migration_end_time) FROM stdin;
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc2	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc2	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc3	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc2\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc1	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc2	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc2\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8_rc1	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_pl1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc3	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc2\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc3	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc2\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc3\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc4\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5	a:1:{i:0;s:52:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1part2\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc2	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc3	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc2\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4_rc1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_pl1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc4	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc3\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc1	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6\";}	1	1		1414661783	1414661783
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc4	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc3\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc2	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc3\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc2	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\local_url_bbcode	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3_rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc2	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1_rc1	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0	a:0:{}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1part2	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc4\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2	a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\bot_update	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc6\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_icq_cleanup	a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_icq\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\notifications_use_full_name	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc3\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\alpha3	a:4:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha2\";i:1;s:42:\"\\phpbb\\db\\migration\\data\\v310\\avatar_types\";i:2;s:39:\"\\phpbb\\db\\migration\\data\\v310\\passwords\";i:3;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_website	a:2:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist\";i:1;s:54:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_icq_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\live_searches_config	a:0:{}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_types	a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\passwords	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\postgres_fulltext_drop	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_location_cleanup	a:1:{i:0;s:51:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_location\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\dev	a:5:{i:0;s:40:\"\\phpbb\\db\\migration\\data\\v310\\extensions\";i:1;s:45:\"\\phpbb\\db\\migration\\data\\v310\\style_update_p2\";i:2;s:41:\"\\phpbb\\db\\migration\\data\\v310\\timezone_p2\";i:3;s:52:\"\\phpbb\\db\\migration\\data\\v310\\reported_posts_display\";i:4;s:46:\"\\phpbb\\db\\migration\\data\\v310\\migrations_table\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\config_db_text	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\acp_prune_users_module	a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\namespaces	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\timezone_p2	a:1:{i:0;s:38:\"\\phpbb\\db\\migration\\data\\v310\\timezone\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth2	a:1:{i:0;s:49:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_field_validation_length	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc3\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\topic_sort_username	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\acp_style_components_module	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_googleplus	a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_twitter	a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\beta3	a:6:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta2\";i:1;s:50:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth2\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\board_contact_name\";i:3;s:44:\"\\phpbb\\db\\migration\\data\\v310\\jquery_update2\";i:4;s:50:\"\\phpbb\\db\\migration\\data\\v310\\live_searches_config\";i:5;s:49:\"\\phpbb\\db\\migration\\data\\v310\\prune_shadow_topics\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth	a:0:{}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\style_update_p2	a:1:{i:0;s:45:\"\\phpbb\\db\\migration\\data\\v310\\style_update_p1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\avatars	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\beta1	a:7:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha3\";i:1;s:42:\"\\phpbb\\db\\migration\\data\\v310\\passwords_p2\";i:2;s:52:\"\\phpbb\\db\\migration\\data\\v310\\postgres_fulltext_drop\";i:3;s:63:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_change_load_settings\";i:4;s:51:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_location\";i:5;s:54:\"\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert2\";i:6;s:48:\"\\phpbb\\db\\migration\\data\\v310\\ucp_popuppm_module\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\contact_admin_acp_module	a:0:{}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\ucp_popuppm_module	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\mysql_fulltext_drop	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_facebook	a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\contact_admin_form	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v310\\config_db_text\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\alpha2	a:2:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha1\";i:1;s:51:\"\\phpbb\\db\\migration\\data\\v310\\notifications_cron_p2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\extensions	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\migrations_table	a:0:{}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_interests	a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\style_update_p1	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rc5	a:3:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc4\";i:1;s:66:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_field_validation_length\";i:2;s:53:\"\\phpbb\\db\\migration\\data\\v310\\remove_acp_styles_cache\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert	a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha3\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p2	a:1:{i:0;s:50:\"\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo_cleanup	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\allow_cdn	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\jquery_update\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rc6	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc5\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rc3	a:5:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc2\";i:1;s:45:\"\\phpbb\\db\\migration\\data\\v310\\captcha_plugins\";i:2;s:53:\"\\phpbb\\db\\migration\\data\\v310\\rename_too_long_indexes\";i:3;s:41:\"\\phpbb\\db\\migration\\data\\v310\\search_type\";i:4;s:49:\"\\phpbb\\db\\migration\\data\\v310\\topic_sort_username\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\softdelete_p1	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\softdelete_p2	a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v310\\softdelete_p1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_website_cleanup	a:1:{i:0;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_website\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\reset_missing_captcha_plugin	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\passwords_p2	a:1:{i:0;s:39:\"\\phpbb\\db\\migration\\data\\v310\\passwords\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm_cleanup	a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert2	a:1:{i:0;s:53:\"\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\remove_acp_styles_cache	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc4\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\notification_options_reconvert	a:1:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v310\\notifications_schema_fix\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_cleanup	a:2:{i:0;s:52:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_interests\";i:1;s:53:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_occupation\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\prune_shadow_topics	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\beta2	a:3:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta1\";i:1;s:52:\"\\phpbb\\db\\migration\\data\\v310\\acp_prune_users_module\";i:2;s:59:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_location_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\mod_rewrite	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\notifications_schema_fix	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\notifications\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_change_load_settings	a:1:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_aol_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist	a:1:{i:0;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rename_too_long_indexes	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\search_type	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\beta4	a:3:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta3\";i:1;s:69:\"\\phpbb\\db\\migration\\data\\v310\\extensions_version_check_force_unstable\";i:2;s:58:\"\\phpbb\\db\\migration\\data\\v310\\reset_missing_captcha_plugin\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rc4	a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc3\";i:1;s:57:\"\\phpbb\\db\\migration\\data\\v310\\notifications_use_full_name\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rc1	a:9:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta4\";i:1;s:54:\"\\phpbb\\db\\migration\\data\\v310\\contact_admin_acp_module\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\contact_admin_form\";i:3;s:50:\"\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p2\";i:4;s:51:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_facebook\";i:5;s:53:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_googleplus\";i:6;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_skype\";i:7;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_twitter\";i:8;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_youtube\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\reported_posts_display	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_aol	a:1:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\jquery_update	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\teampage	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_aol_cleanup	a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_aol\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_youtube	a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\boardindex	a:0:{}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p1	a:1:{i:0;s:42:\"\\phpbb\\db\\migration\\data\\v310\\passwords_p2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\timezone	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\softdelete_mcp_modules	a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v310\\softdelete_p2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\forgot_password	a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_icq	a:1:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_location	a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";i:1;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\rc2	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc1\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field	a:1:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\board_contact_name	a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\notifications_cron	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\notifications\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_occupation	a:1:{i:0;s:52:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_interests\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\alpha1	a:18:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v30x\\local_url_bbcode\";i:1;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12\";i:2;s:57:\"\\phpbb\\db\\migration\\data\\v310\\acp_style_components_module\";i:3;s:39:\"\\phpbb\\db\\migration\\data\\v310\\allow_cdn\";i:4;s:49:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth\";i:5;s:37:\"\\phpbb\\db\\migration\\data\\v310\\avatars\";i:6;s:40:\"\\phpbb\\db\\migration\\data\\v310\\boardindex\";i:7;s:44:\"\\phpbb\\db\\migration\\data\\v310\\config_db_text\";i:8;s:45:\"\\phpbb\\db\\migration\\data\\v310\\forgot_password\";i:9;s:41:\"\\phpbb\\db\\migration\\data\\v310\\mod_rewrite\";i:10;s:49:\"\\phpbb\\db\\migration\\data\\v310\\mysql_fulltext_drop\";i:11;s:40:\"\\phpbb\\db\\migration\\data\\v310\\namespaces\";i:12;s:48:\"\\phpbb\\db\\migration\\data\\v310\\notifications_cron\";i:13;s:60:\"\\phpbb\\db\\migration\\data\\v310\\notification_options_reconvert\";i:14;s:38:\"\\phpbb\\db\\migration\\data\\v310\\plupload\";i:15;s:51:\"\\phpbb\\db\\migration\\data\\v310\\signature_module_auth\";i:16;s:52:\"\\phpbb\\db\\migration\\data\\v310\\softdelete_mcp_modules\";i:17;s:38:\"\\phpbb\\db\\migration\\data\\v310\\teampage\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo	a:1:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\avatar_types	a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v310\\avatars\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\notifications_cron_p2	a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\notifications_cron\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm	a:1:{i:0;s:58:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_website_cleanup\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\profilefield_skype	a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\jquery_update2	a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\jquery_update\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\notifications	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\gold	a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc6\";i:1;s:40:\"\\phpbb\\db\\migration\\data\\v310\\bot_update\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\captcha_plugins	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc2\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\signature_module_auth	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\extensions_version_check_force_unstable	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\\phpbb\\db\\migration\\data\\v310\\plupload	a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}	1	1		1414661784	1414661784
\.
-- Table: phpbb_groups
DROP TABLE phpbb_groups;
DROP SEQUENCE phpbb_groups_seq;
CREATE SEQUENCE phpbb_groups_seq;
CREATE TABLE phpbb_groups(
  group_id int4 DEFAULT nextval('phpbb_groups_seq'::regclass) NOT NULL, 
  group_type int2 DEFAULT 1::smallint NOT NULL, 
  group_founder_manage int2 DEFAULT 0::smallint NOT NULL, 
  group_skip_auth int2 DEFAULT 0::smallint NOT NULL, 
  group_name varchar_ci DEFAULT ''::character varying NOT NULL, 
  group_desc varchar(4000) DEFAULT ''::character varying NOT NULL, 
  group_desc_bitfield varchar(255) DEFAULT ''::character varying NOT NULL, 
  group_desc_options int4 DEFAULT 7 NOT NULL, 
  group_desc_uid varchar(8) DEFAULT ''::character varying NOT NULL, 
  group_display int2 DEFAULT 0::smallint NOT NULL, 
  group_avatar varchar(255) DEFAULT ''::character varying NOT NULL, 
  group_avatar_type varchar(255) DEFAULT ''::character varying NOT NULL, 
  group_avatar_width int2 DEFAULT 0::smallint NOT NULL, 
  group_avatar_height int2 DEFAULT 0::smallint NOT NULL, 
  group_rank int4 DEFAULT 0 NOT NULL, 
  group_colour varchar(6) DEFAULT ''::character varying NOT NULL, 
  group_sig_chars int4 DEFAULT 0 NOT NULL, 
  group_receive_pm int2 DEFAULT 0::smallint NOT NULL, 
  group_message_limit int4 DEFAULT 0 NOT NULL, 
  group_legend int4 DEFAULT 0 NOT NULL, 
  group_max_recipients int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_groups_pkey PRIMARY KEY (group_id), 
  CONSTRAINT phpbb_groups_group_max_recipients_check CHECK (group_max_recipients >= 0), 
  CONSTRAINT phpbb_groups_group_legend_check CHECK (group_legend >= 0), 
  CONSTRAINT phpbb_groups_group_message_limit_check CHECK (group_message_limit >= 0), 
  CONSTRAINT phpbb_groups_group_receive_pm_check CHECK (group_receive_pm >= 0), 
  CONSTRAINT phpbb_groups_group_sig_chars_check CHECK (group_sig_chars >= 0), 
  CONSTRAINT phpbb_groups_group_rank_check CHECK (group_rank >= 0), 
  CONSTRAINT phpbb_groups_group_avatar_height_check CHECK (group_avatar_height >= 0), 
  CONSTRAINT phpbb_groups_group_avatar_width_check CHECK (group_avatar_width >= 0), 
  CONSTRAINT phpbb_groups_group_display_check CHECK (group_display >= 0), 
  CONSTRAINT phpbb_groups_group_desc_options_check CHECK (group_desc_options >= 0), 
  CONSTRAINT phpbb_groups_group_skip_auth_check CHECK (group_skip_auth >= 0), 
  CONSTRAINT phpbb_groups_group_founder_manage_check CHECK (group_founder_manage >= 0), 
  CONSTRAINT phpbb_groups_group_id_check CHECK (group_id >= 0)
);
CREATE INDEX phpbb_groups_group_legend_name ON phpbb_groups (group_legend, group_name);

COPY phpbb_groups (group_id, group_type, group_founder_manage, group_skip_auth, group_name, group_desc, group_desc_bitfield, group_desc_options, group_desc_uid, group_display, group_avatar, group_avatar_type, group_avatar_width, group_avatar_height, group_rank, group_colour, group_sig_chars, group_receive_pm, group_message_limit, group_legend, group_max_recipients) FROM stdin;
1	3	0	0	GUESTS			7		0			0	0	0		0	0	0	0	5
2	3	0	0	REGISTERED			7		0			0	0	0		0	0	0	0	5
3	3	0	0	REGISTERED_COPPA			7		0			0	0	0		0	0	0	0	5
4	3	0	0	GLOBAL_MODERATORS			7		0			0	0	0	00AA00	0	0	0	2	0
5	3	1	0	ADMINISTRATORS			7		0			0	0	0	AA0000	0	0	0	1	0
6	3	0	0	BOTS			7		0			0	0	0	9E8DA7	0	0	0	0	5
7	3	0	0	NEWLY_REGISTERED			7		0			0	0	0		0	0	0	0	5
\.
SELECT SETVAL('phpbb_groups_seq',(select case when max(group_id)>0 then max(group_id)+1 else 1 end FROM phpbb_groups));
-- Table: phpbb_topics
DROP TABLE phpbb_topics;
DROP SEQUENCE phpbb_topics_seq;
CREATE SEQUENCE phpbb_topics_seq;
CREATE TABLE phpbb_topics(
  topic_id int4 DEFAULT nextval('phpbb_topics_seq'::regclass) NOT NULL, 
  forum_id int4 DEFAULT 0 NOT NULL, 
  icon_id int4 DEFAULT 0 NOT NULL, 
  topic_attachment int2 DEFAULT 0::smallint NOT NULL, 
  topic_reported int2 DEFAULT 0::smallint NOT NULL, 
  topic_title varchar(255) DEFAULT ''::character varying NOT NULL, 
  topic_poster int4 DEFAULT 0 NOT NULL, 
  topic_time int4 DEFAULT 0 NOT NULL, 
  topic_time_limit int4 DEFAULT 0 NOT NULL, 
  topic_views int4 DEFAULT 0 NOT NULL, 
  topic_status int2 DEFAULT 0::smallint NOT NULL, 
  topic_type int2 DEFAULT 0::smallint NOT NULL, 
  topic_first_post_id int4 DEFAULT 0 NOT NULL, 
  topic_first_poster_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  topic_first_poster_colour varchar(6) DEFAULT ''::character varying NOT NULL, 
  topic_last_post_id int4 DEFAULT 0 NOT NULL, 
  topic_last_poster_id int4 DEFAULT 0 NOT NULL, 
  topic_last_poster_name varchar(255) DEFAULT ''::character varying NOT NULL, 
  topic_last_poster_colour varchar(6) DEFAULT ''::character varying NOT NULL, 
  topic_last_post_subject varchar(255) DEFAULT ''::character varying NOT NULL, 
  topic_last_post_time int4 DEFAULT 0 NOT NULL, 
  topic_last_view_time int4 DEFAULT 0 NOT NULL, 
  topic_moved_id int4 DEFAULT 0 NOT NULL, 
  topic_bumped int2 DEFAULT 0::smallint NOT NULL, 
  topic_bumper int4 DEFAULT 0 NOT NULL, 
  poll_title varchar(255) DEFAULT ''::character varying NOT NULL, 
  poll_start int4 DEFAULT 0 NOT NULL, 
  poll_length int4 DEFAULT 0 NOT NULL, 
  poll_max_options int2 DEFAULT 1::smallint NOT NULL, 
  poll_last_vote int4 DEFAULT 0 NOT NULL, 
  poll_vote_change int2 DEFAULT 0::smallint NOT NULL, 
  topic_visibility int2 DEFAULT 0::smallint NOT NULL, 
  topic_delete_time int4 DEFAULT 0 NOT NULL, 
  topic_delete_reason varchar(255) DEFAULT ''::character varying NOT NULL, 
  topic_delete_user int4 DEFAULT 0 NOT NULL, 
  topic_posts_approved int4 DEFAULT 0 NOT NULL, 
  topic_posts_unapproved int4 DEFAULT 0 NOT NULL, 
  topic_posts_softdeleted int4 DEFAULT 0 NOT NULL, 
  CONSTRAINT phpbb_topics_pkey PRIMARY KEY (topic_id), 
  CONSTRAINT phpbb_topics_topic_posts_softdeleted_check CHECK (topic_posts_softdeleted >= 0), 
  CONSTRAINT phpbb_topics_topic_posts_unapproved_check CHECK (topic_posts_unapproved >= 0), 
  CONSTRAINT phpbb_topics_topic_posts_approved_check CHECK (topic_posts_approved >= 0), 
  CONSTRAINT phpbb_topics_topic_delete_user_check CHECK (topic_delete_user >= 0), 
  CONSTRAINT phpbb_topics_topic_delete_time_check CHECK (topic_delete_time >= 0), 
  CONSTRAINT phpbb_topics_poll_vote_change_check CHECK (poll_vote_change >= 0), 
  CONSTRAINT phpbb_topics_poll_last_vote_check CHECK (poll_last_vote >= 0), 
  CONSTRAINT phpbb_topics_poll_length_check CHECK (poll_length >= 0), 
  CONSTRAINT phpbb_topics_poll_start_check CHECK (poll_start >= 0), 
  CONSTRAINT phpbb_topics_topic_bumper_check CHECK (topic_bumper >= 0), 
  CONSTRAINT phpbb_topics_topic_bumped_check CHECK (topic_bumped >= 0), 
  CONSTRAINT phpbb_topics_topic_moved_id_check CHECK (topic_moved_id >= 0), 
  CONSTRAINT phpbb_topics_topic_last_view_time_check CHECK (topic_last_view_time >= 0), 
  CONSTRAINT phpbb_topics_topic_last_post_time_check CHECK (topic_last_post_time >= 0), 
  CONSTRAINT phpbb_topics_topic_last_poster_id_check CHECK (topic_last_poster_id >= 0), 
  CONSTRAINT phpbb_topics_topic_last_post_id_check CHECK (topic_last_post_id >= 0), 
  CONSTRAINT phpbb_topics_topic_first_post_id_check CHECK (topic_first_post_id >= 0), 
  CONSTRAINT phpbb_topics_topic_views_check CHECK (topic_views >= 0), 
  CONSTRAINT phpbb_topics_topic_time_limit_check CHECK (topic_time_limit >= 0), 
  CONSTRAINT phpbb_topics_topic_time_check CHECK (topic_time >= 0), 
  CONSTRAINT phpbb_topics_topic_poster_check CHECK (topic_poster >= 0), 
  CONSTRAINT phpbb_topics_topic_reported_check CHECK (topic_reported >= 0), 
  CONSTRAINT phpbb_topics_topic_attachment_check CHECK (topic_attachment >= 0), 
  CONSTRAINT phpbb_topics_icon_id_check CHECK (icon_id >= 0), 
  CONSTRAINT phpbb_topics_forum_id_check CHECK (forum_id >= 0), 
  CONSTRAINT phpbb_topics_topic_id_check CHECK (topic_id >= 0)
);
CREATE INDEX phpbb_topics_fid_time_moved ON phpbb_topics (forum_id, topic_last_post_time, topic_moved_id);
CREATE INDEX phpbb_topics_forum_id ON phpbb_topics (forum_id);
CREATE INDEX phpbb_topics_forum_id_type ON phpbb_topics (forum_id, topic_type);
CREATE INDEX phpbb_topics_forum_vis_last ON phpbb_topics (forum_id, topic_last_post_id, topic_visibility);
CREATE INDEX phpbb_topics_last_post_time ON phpbb_topics (topic_last_post_time);
CREATE INDEX phpbb_topics_topic_visibility ON phpbb_topics (topic_visibility);

COPY phpbb_topics (topic_id, forum_id, icon_id, topic_attachment, topic_reported, topic_title, topic_poster, topic_time, topic_time_limit, topic_views, topic_status, topic_type, topic_first_post_id, topic_first_poster_name, topic_first_poster_colour, topic_last_post_id, topic_last_poster_id, topic_last_poster_name, topic_last_poster_colour, topic_last_post_subject, topic_last_post_time, topic_last_view_time, topic_moved_id, topic_bumped, topic_bumper, poll_title, poll_start, poll_length, poll_max_options, poll_last_vote, poll_vote_change, topic_visibility, topic_delete_time, topic_delete_reason, topic_delete_user, topic_posts_approved, topic_posts_unapproved, topic_posts_softdeleted) FROM stdin;
1	2	0	0	0	Welcome to phpBB3	2	1414661761	0	0	0	0	1	myleftstudio	AA0000	1	2	myleftstudio	AA0000	Welcome to phpBB3	1414661761	972086460	0	0	0		0	0	1	0	0	1	0		0	1	0	0
\.
SELECT SETVAL('phpbb_topics_seq',(select case when max(topic_id)>0 then max(topic_id)+1 else 1 end FROM phpbb_topics));
-- Table: phpbb_acl_options
DROP TABLE phpbb_acl_options;
DROP SEQUENCE phpbb_acl_options_seq;
CREATE SEQUENCE phpbb_acl_options_seq;
CREATE TABLE phpbb_acl_options(
  auth_option_id int4 DEFAULT nextval('phpbb_acl_options_seq'::regclass) NOT NULL, 
  auth_option varchar(50) DEFAULT ''::character varying NOT NULL, 
  is_global int2 DEFAULT 0::smallint NOT NULL, 
  is_local int2 DEFAULT 0::smallint NOT NULL, 
  founder_only int2 DEFAULT 0::smallint NOT NULL, 
  CONSTRAINT phpbb_acl_options_pkey PRIMARY KEY (auth_option_id), 
  CONSTRAINT phpbb_acl_options_founder_only_check CHECK (founder_only >= 0), 
  CONSTRAINT phpbb_acl_options_is_local_check CHECK (is_local >= 0), 
  CONSTRAINT phpbb_acl_options_is_global_check CHECK (is_global >= 0), 
  CONSTRAINT phpbb_acl_options_auth_option_id_check CHECK (auth_option_id >= 0)
);
CREATE UNIQUE INDEX phpbb_acl_options_auth_option ON phpbb_acl_options (auth_option);

COPY phpbb_acl_options (auth_option_id, auth_option, is_global, is_local, founder_only) FROM stdin;
1	f_	0	1	0
2	f_announce	0	1	0
3	f_attach	0	1	0
4	f_bbcode	0	1	0
5	f_bump	0	1	0
6	f_delete	0	1	0
7	f_download	0	1	0
8	f_edit	0	1	0
9	f_email	0	1	0
10	f_flash	0	1	0
11	f_icons	0	1	0
12	f_ignoreflood	0	1	0
13	f_img	0	1	0
14	f_list	0	1	0
15	f_noapprove	0	1	0
16	f_poll	0	1	0
17	f_post	0	1	0
18	f_postcount	0	1	0
19	f_print	0	1	0
20	f_read	0	1	0
21	f_reply	0	1	0
22	f_report	0	1	0
23	f_search	0	1	0
24	f_sigs	0	1	0
25	f_smilies	0	1	0
26	f_sticky	0	1	0
27	f_subscribe	0	1	0
28	f_user_lock	0	1	0
29	f_vote	0	1	0
30	f_votechg	0	1	0
31	f_softdelete	0	1	0
32	m_	1	1	0
33	m_approve	1	1	0
34	m_chgposter	1	1	0
35	m_delete	1	1	0
36	m_edit	1	1	0
37	m_info	1	1	0
38	m_lock	1	1	0
39	m_merge	1	1	0
40	m_move	1	1	0
41	m_report	1	1	0
42	m_split	1	1	0
43	m_softdelete	1	1	0
44	m_ban	1	0	0
45	m_warn	1	0	0
46	a_	1	0	0
47	a_aauth	1	0	0
48	a_attach	1	0	0
49	a_authgroups	1	0	0
50	a_authusers	1	0	0
51	a_backup	1	0	0
52	a_ban	1	0	0
53	a_bbcode	1	0	0
54	a_board	1	0	0
55	a_bots	1	0	0
56	a_clearlogs	1	0	0
57	a_email	1	0	0
58	a_extensions	1	0	0
59	a_fauth	1	0	0
60	a_forum	1	0	0
61	a_forumadd	1	0	0
62	a_forumdel	1	0	0
63	a_group	1	0	0
64	a_groupadd	1	0	0
65	a_groupdel	1	0	0
66	a_icons	1	0	0
67	a_jabber	1	0	0
68	a_language	1	0	0
69	a_mauth	1	0	0
70	a_modules	1	0	0
71	a_names	1	0	0
72	a_phpinfo	1	0	0
73	a_profile	1	0	0
74	a_prune	1	0	0
75	a_ranks	1	0	0
76	a_reasons	1	0	0
77	a_roles	1	0	0
78	a_search	1	0	0
79	a_server	1	0	0
80	a_styles	1	0	0
81	a_switchperm	1	0	0
82	a_uauth	1	0	0
83	a_user	1	0	0
84	a_userdel	1	0	0
85	a_viewauth	1	0	0
86	a_viewlogs	1	0	0
87	a_words	1	0	0
88	u_	1	0	0
89	u_attach	1	0	0
90	u_chgavatar	1	0	0
91	u_chgcensors	1	0	0
92	u_chgemail	1	0	0
93	u_chggrp	1	0	0
94	u_chgname	1	0	0
95	u_chgpasswd	1	0	0
96	u_chgprofileinfo	1	0	0
97	u_download	1	0	0
98	u_hideonline	1	0	0
99	u_ignoreflood	1	0	0
100	u_masspm	1	0	0
101	u_masspm_group	1	0	0
102	u_pm_attach	1	0	0
103	u_pm_bbcode	1	0	0
104	u_pm_delete	1	0	0
105	u_pm_download	1	0	0
106	u_pm_edit	1	0	0
107	u_pm_emailpm	1	0	0
108	u_pm_flash	1	0	0
109	u_pm_forward	1	0	0
110	u_pm_img	1	0	0
111	u_pm_printpm	1	0	0
112	u_pm_smilies	1	0	0
113	u_readpm	1	0	0
114	u_savedrafts	1	0	0
115	u_search	1	0	0
116	u_sendemail	1	0	0
117	u_sendim	1	0	0
118	u_sendpm	1	0	0
119	u_sig	1	0	0
120	u_viewonline	1	0	0
121	u_viewprofile	1	0	0
\.
SELECT SETVAL('phpbb_acl_options_seq',(select case when max(auth_option_id)>0 then max(auth_option_id)+1 else 1 end FROM phpbb_acl_options));
COMMIT;
